const test=require('node:test'),assert=require('node:assert/strict'),C=require('../2/conveyor-core.js');
const belt=(key,a,b)=>({nodeKey:key,kind:'conveyor',points:[a,b],costWood:5});
test('an eastern reversed join stops real iron, reversing the paid belt restores warehouse delivery',()=>{
 const links=[belt(1,{x:100,y:340},{x:300,y:340})];
 for(let x=300;x<1100;x+=200)links.push(belt(links.length+1,{x,y:340},{x:x+200,y:340}));
 const wrong=belt(6,{x:1300,y:340},{x:1100,y:340});links.push(wrong);
 let item={key:7,type:'iron',count:1,x:1200,y:340,beltId:6};
 for(let i=0;i<300;i++)item={...item,...C.step(links,[],item,1/30)};
 assert.equal(item.x,1300);assert.equal(item.blocked,true);assert.equal(C.deliveryStatus(links,[],item),'blocked');
 const price=wrong.costWood;assert.equal(C.reverse(wrong),true);assert.equal(wrong.nodeKey,6);assert.equal(wrong.costWood,price);
 assert.equal(item.x,1300,'repair does not teleport the ore');
 assert.equal(C.deliveryStatus(links,[],item),'warehouse');
 for(let i=0;i<1000&&!item.arrived;i++)item={...item,...C.step(links,[],item,1/30)};
 assert.equal(item.arrived,true);assert.equal(item.key,7);assert.equal(item.count,1);assert.equal(item.type,'iron');
});
test('route preview keeps the selected belt at a crossing, matching live preferred-belt motion',()=>{
 const home=belt(1,{x:100,y:340},{x:500,y:340}),dead=belt(2,{x:300,y:200},{x:300,y:480}),p={x:300,y:340,beltId:2};
 assert.equal(C.deliveryStatus([home,dead],[],p),'blocked');
 assert.equal(C.deliveryStatusLegacy([home,dead],[],p),'blocked');
 assert.equal(C.deliveryStatus([home,dead],[],{...p,beltId:1}),'warehouse');
 assert.equal(C.deliveryStatusLegacy([home,dead],[],{...p,beltId:1}),'warehouse');
});
test('reversal normalizes legacy orientation once and survives a save round trip',()=>{
 const old={nodeKey:4,type:'wood',costWood:3,points:[{x:500,y:340},{x:100,y:340}]},original=C.oriented(old).map(p=>({...p}));
 assert.equal(C.reverse(old),true);assert.equal(old.kind,'conveyor');assert.deepEqual(C.oriented(old),original.slice().reverse());
 const loaded=JSON.parse(JSON.stringify(old));assert.deepEqual(C.oriented(loaded),old.points);C.reverse(loaded);assert.deepEqual(loaded.points,original);
 assert.equal(C.reverse(null),false);assert.equal(C.reverse({points:[]}),false);
});
