const test=require('node:test');
const assert=require('node:assert/strict');
const C=require('../2/outpost-core.js');
const clone=value=>JSON.parse(JSON.stringify(value));
const near=(actual,expected,epsilon=1e-7)=>assert.ok(Math.abs(actual-expected)<epsilon,`${actual} != ${expected}`);
const length=lane=>C.WORLD.entryX-C.WORLD.turnX+Math.hypot(C.WORLD.turnX-C.WORLD.home.x,C.WORLD[lane]-C.WORLD.home.y);
function active(wave=1){const s=C.fresh();s.wave=wave;assert.equal(C.start(s),true);return s;}
function winRound(s){
 C.tick(s,0);const events=[];
 for(let i=0;i<C.plan(s.wave).duration*4;i++){for(const enemy of s.enemies)if(enemy.alive)C.hit(s,enemy.key,1000,'arch');events.push(...C.tick(s,.25));}
 assert.equal(events.length,1);assert.equal(events[0].type,'settle');return events[0].result;
}
function compareProgress(a,b){
 assert.equal(a.phase,b.phase);near(a.elapsed,b.elapsed);assert.equal(a.boxes,b.boxes);assert.equal(a.spawned,b.spawned);assert.equal(a.kills,b.kills);assert.equal(a.escaped,b.escaped);
 assert.equal(a.enemies.length,b.enemies.length);
 for(let i=0;i<a.enemies.length;i++){const x=a.enemies[i],y=b.enemies[i];assert.equal(x.key,y.key);assert.equal(x.alive,y.alive);assert.equal(x.atGate,y.atGate);for(const key of ['hp','travel','x','y','slowUntil','gateTime'])near(x[key],y[key]);}
 assert.deepEqual(a.result,b.result);
}

test('outpost is a standalone browser UMD module with a plain JSON fresh state',()=>{
 const fs=require('node:fs'),vm=require('node:vm'),scope={};vm.runInNewContext(fs.readFileSync(require.resolve('../2/outpost-core.js'),'utf8'),scope);
 assert.equal(typeof scope.OutpostCore.tick,'function');assert.deepEqual(clone(C.fresh()),C.fresh());
 assert.deepEqual(C.WORLD,{width:960,height:540,home:{x:100,y:340},entryX:925,turnX:190,upper:185,lower:435});
 assert.equal(C.fresh().phase,'prep');assert.equal(C.fresh().boxes,3);assert.equal(C.fresh().result,null);
});
test('the three authored plans expose their real spawn times and distinct lanes',()=>{
 for(const [wave,times,lanes,hp,speed] of [
  [1,[0,6,12],['upper','upper','upper'],14,22],
  [2,[0,5,10,15],['lower','lower','lower','lower'],18,24],
  [3,[0,0,1.5,1.5,3,3],['upper','lower','upper','lower','upper','lower'],22,25]
 ]){const p=C.plan(wave);assert.equal(p.duration,50);assert.equal(p.wave,wave);assert.deepEqual(p.spawns.map(e=>e.at),times);assert.deepEqual(p.spawns.map(e=>e.lane),lanes);assert.ok(p.spawns.every(e=>e.kind==='rat'&&e.hp===hp&&e.speed===speed));assert.equal(p.counts.upper+p.counts.lower,p.spawns.length);}
 const p=C.plan(1);p.spawns[0].hp=999;assert.equal(C.plan(1).spawns[0].hp,14);
});
test('materials pay for each successive person and batch quotes match individual hiring',()=>{
 assert.deepEqual(C.recipe('woodcutter',0),{wood:6,stone:0,gold:0});
 assert.deepEqual(C.recipe('miner',2),{wood:16,stone:8,gold:0});
 assert.deepEqual(C.recipe('arch',3),{wood:30,stone:15,gold:0});
 assert.deepEqual(C.recipe('sword',4),{wood:30,stone:24,gold:0});
 for(const id of ['woodcutter','miner','arch','sword']){const sum={wood:0,stone:0,gold:0};for(let i=7;i<17;i++){const p=C.recipe(id,i);for(const k of Object.keys(sum))sum[k]+=p[k];}assert.deepEqual(C.recipe(id,7,10),sum);}
 assert.deepEqual(C.recipe('arch',3,0),{wood:0,stone:0,gold:0});assert.equal(C.recipe('darkgod',0),null);
});
test('worker cost growth bounds self-acceleration and combat does not inherit training multipliers',()=>{
 const interval=C.stats('woodcutter').interval;
 for(const owned of [1,10,100,1000]){const yieldPerSecond=owned/interval,marginal=C.recipe('woodcutter',owned).wood;assert.ok(marginal/yieldPerSecond>=20);assert.ok(C.recipe('woodcutter',owned+1).wood>marginal);}
 assert.deepEqual(C.stats('woodcutter'),{damage:0,interval:5,range:0});assert.deepEqual(C.stats('miner'),{damage:0,interval:6,range:0});
 assert.deepEqual(C.stats('arch'),{damage:5,interval:1.3,range:90});assert.deepEqual(C.stats('sword'),{damage:3,interval:1.2,range:28});assert.equal(C.stats('darkgod'),null);
 const stats=C.stats('arch');stats.damage=1e9;assert.equal(C.stats('arch').damage,5);
});
test('spawning follows elapsed seconds and new enemies do not receive time from before their spawn',()=>{
 const s=active();assert.deepEqual(C.tick(s,5.9),[]);assert.equal(s.spawned,1);near(s.enemies[0].travel,5.9*22);
 C.tick(s,.1);assert.equal(s.spawned,2);near(s.enemies[0].travel,6*22);near(s.enemies[1].travel,0);
 C.tick(s,.5);near(s.enemies[1].travel,11);assert.equal(s.enemies[1].y,C.WORLD.upper);
});
test('wave 2 uses the lower road and wave 3 alternates roads without moving allies',()=>{
 const lower=active(2);C.tick(lower,5);assert.equal(lower.enemies.length,2);assert.ok(lower.enemies.every(e=>e.lane==='lower'&&e.y===C.WORLD.lower));
 const both=active(3);C.tick(both,1.5);assert.deepEqual(both.enemies.map(e=>e.lane),['upper','lower','upper','lower']);near(both.enemies[2].travel,0);near(both.enemies[3].travel,0);C.tick(both,1.5);assert.equal(both.enemies.length,6);assert.equal('allies' in both,false);
});
test('rats interpolate around their lane corner and spend a full attackable second at the gate',()=>{
 const s=active(),turnTime=(C.WORLD.entryX-C.WORLD.turnX)/22;C.tick(s,turnTime);const e=s.enemies[0];near(e.x,C.WORLD.turnX);near(e.y,C.WORLD.upper);
 C.tick(s,.5);assert.ok(e.x<C.WORLD.turnX&&e.x>C.WORLD.home.x);assert.ok(e.y>C.WORLD.upper&&e.y<C.WORLD.home.y);
 C.tick(s,length('upper')/22-s.elapsed);assert.equal(e.atGate,true);assert.equal(e.alive,true);near(e.gateTime,0);near(e.x,C.WORLD.home.x);near(e.y,C.WORLD.home.y);assert.equal(s.boxes,3);
 C.tick(s,.999);assert.equal(e.alive,true);assert.equal(s.boxes,3);C.tick(s,.001);assert.equal(e.alive,false);assert.equal(s.boxes,2);assert.equal(s.escaped,1);
});
test('killing a rat during its gate animation rescues that box',()=>{
 const s=active();C.tick(s,length('upper')/22+.5);const e=s.enemies[0];assert.equal(e.atGate,true);assert.deepEqual(C.hit(s,e.key,100,'arch'),{applied:14,killed:true});
 C.tick(s,.6);assert.equal(s.boxes,3);assert.equal(s.kills,1);assert.equal(s.escaped,0);assert.deepEqual(C.hit(s,e.key,100,'arch'),{applied:0,killed:false});
});
test('movement, spawning, turning and gate time agree across different tick partitions',()=>{
 const a=active(3),b=active(3);C.tick(a,41.75);for(let i=0;i<167;i++)C.tick(b,.25);compareProgress(a,b);
});
test('a sword slow lasts 1.5 real seconds, with exact movement across its expiry',()=>{
 const a=active(),b=active();C.tick(a,1);C.tick(b,1);C.hit(a,1,1,'sword');C.hit(b,1,1,'sword');
 C.tick(a,2);for(let i=0;i<8;i++)C.tick(b,.25);near(a.enemies[0].slowUntil,2.5);near(a.enemies[0].travel,22+1.5*22*.35+.5*22);compareProgress(a,b);
});
test('invalid time and damage cannot advance a round or poison saved numbers',()=>{
 const s=active();C.tick(s,0);const before=clone(s);for(const dt of [-1,NaN,Infinity,-Infinity])assert.deepEqual(C.tick(s,dt),[]);assert.deepEqual(s,before);
 for(const amount of [-10,0,NaN,Infinity])assert.deepEqual(C.hit(s,1,amount,'sword'),{applied:0,killed:false});assert.deepEqual(s,before);
 assert.equal(C.target(s,{x:NaN,y:0},100),null);assert.equal(C.target(s,{x:0,y:0},Infinity),null);
});
test('the last crate ends defence immediately without counting unresolved raiders as breakthroughs',()=>{
 const s=active(3);C.tick(s,3);assert.equal(s.phase,'active');assert.equal(s.result,null);assert.equal(C.start(s),false);
 let events=[];for(let i=0;i<500&&s.phase==='active';i++)events.push(...C.tick(s,.1));assert.equal(events.length,1);assert.deepEqual(events[0].result,{wave:3,win:false,boxes:0,kills:0,escaped:3,gold:0,first:false,reason:'crates'});assert.ok(s.elapsed>20&&s.elapsed<40);
 const saved=C.migrate(clone(s));near(saved.elapsed,s.elapsed);assert.deepEqual(C.tick(s,500),[]);assert.deepEqual(C.tick(saved,1),[]);
});
test('timeout fails with remaining enemies instead of inventing breakthroughs',()=>{
 const s=active();C.tick(s,0);C.hit(s,1,100,'arch');C.tick(s,6);C.hit(s,2,100,'arch');
 const events=C.tick(s,44);assert.equal(events.length,1);assert.deepEqual(events[0].result,{wave:1,win:false,boxes:3,kills:2,escaped:0,gold:0,first:false,reason:'timeout'});assert.equal(s.enemies.filter(e=>e.alive).length,1);
});
test('all nine first wins pay once and the terminal result requires an explicit replay',()=>{
 const s=active();let total=0;
 for(let wave=1;wave<=C.MAX_WAVE;wave++){assert.equal(s.wave,wave);const result=winRound(s);assert.equal(result.first,true);assert.equal(result.gold,30+wave*8);total+=result.gold;if(wave<C.MAX_WAVE)assert.equal(C.start(s),true);}
 assert.equal(total,630);assert.equal(s.completed,true);assert.equal(s.completedAtRound,9);assert.equal(C.start(s),false);assert.equal(C.start(s,{replay:true}),true);assert.equal(s.wave,9);
 const repeat=winRound(s);assert.equal(repeat.gold,18);assert.equal(repeat.first,false);assert.equal(repeat.chiefDefeated,true);assert.deepEqual(s.claimedFirst,[1,2,3,4,5,6,7,8,9]);assert.equal(s.cleared,9);assert.equal(s.round,10);assert.equal(s.completedAtRound,9);
});
test('a failed wave restarts itself with three boxes and keeps enemy keys unique across rounds',()=>{
 const s=active(2);C.tick(s,50);const lastKey=Math.max(...s.enemies.map(e=>e.key));assert.equal(s.result.win,false);assert.equal(C.start(s),true);assert.equal(s.wave,2);assert.equal(s.boxes,3);assert.equal(s.kills,0);assert.equal(s.escaped,0);C.tick(s,0);assert.ok(s.enemies[0].key>lastKey);
});
test('an active JSON save resumes the same spawn timing, slow, targets and eventual result',()=>{
 const a=active(3);C.tick(a,9.75);C.hit(a,a.enemies[0].key,2,'sword');const b=C.migrate(clone(a));compareProgress(a,b);
 for(let i=0;i<161;i++){C.tick(a,.25);C.tick(b,.25);}compareProgress(a,b);assert.equal(a.phase,'result');
});
test('saving during the gate animation retains the remaining rescue window',()=>{
 const a=active();C.tick(a,length('upper')/22+.4);const b=C.migrate(clone(a));compareProgress(a,b);C.tick(a,.59);C.tick(b,.59);assert.equal(b.enemies[0].alive,true);C.tick(a,.01);C.tick(b,.01);compareProgress(a,b);assert.equal(b.enemies[0].alive,false);
});
test('a saved result cannot settle again and migration repairs duplicate first-reward records',()=>{
 const s=active();winRound(s);const raw=clone(s);raw.claimedFirst=[1,1,999,'2'];raw.result.gold=Infinity;const restored=C.migrate(raw);
 assert.deepEqual(restored.claimedFirst,[1]);assert.equal(restored.result.gold,38);assert.deepEqual(C.tick(restored,1),[]);assert.equal(restored.result.wave,1);
 raw.phase='active';assert.equal(C.migrate(raw).phase,'result');assert.deepEqual(C.tick(C.migrate(raw),50),[]);
 const corrupt=C.migrate({...C.fresh(),cleared:2,claimedFirst:[]});assert.deepEqual(corrupt.claimedFirst,[1,2]);
});
test('migration rejects nonfinite data and duplicate enemy keys without changing its input',()=>{
 const raw={...C.fresh(),phase:'active',elapsed:Infinity,boxes:Infinity,nextKey:-1,wave:99,round:NaN,enemies:[{key:4,kind:'rat',lane:'upper',hp:Infinity,travel:Infinity,slowUntil:Infinity,alive:true},{key:4,kind:'rat',lane:'lower',hp:10,travel:10,alive:true},{key:5,kind:'other',lane:'upper',hp:10,alive:true}]};
 const before={...raw,enemies:raw.enemies.map(e=>({...e}))},s=C.migrate(raw);assert.deepEqual(raw,before);assert.equal(s.wave,9);assert.equal(s.elapsed,0);assert.equal(s.enemies.length,1);assert.equal(s.nextKey,5);assert.ok(s.enemies.every(e=>[e.hp,e.maxHp,e.x,e.y,e.travel,e.slowUntil,e.gateTime].every(Number.isFinite)));assert.doesNotThrow(()=>JSON.stringify(s));
 assert.deepEqual(C.migrate({version:2}),C.fresh());
});
test('each hit stays attached to its enemy key and cannot transfer to a replacement target',()=>{
 const s=active();C.tick(s,6);const first=C.target(s,{x:500,y:185},1000);assert.equal(first.key,1);assert.deepEqual(C.hit(s,first.key,100,'arch'),{applied:14,killed:true});
 const second=C.target(s,{x:500,y:185},1000);assert.equal(second.key,2);const hp=second.hp;assert.deepEqual(C.hit(s,first.key,5,'arch'),{applied:0,killed:false});assert.equal(second.hp,hp);assert.equal(s.kills,1);
});
test('target prefers the shortest remaining road, then distance, within the exact passed range',()=>{
 const s=active(3);C.tick(s,8);const [upper,lower,other]=s.enemies;upper.travel=100;lower.travel=200;other.travel=250;
 assert.equal(C.target(s,{x:500,y:310},2000).key,other.key);
 upper.travel=length('upper')-200;lower.travel=length('lower')-200;other.alive=false;upper.x=200;upper.y=185;lower.x=260;lower.y=435;
 assert.equal(C.target(s,{x:260,y:435},1000).key,lower.key);
 upper.x=lower.x=500;upper.y=185;lower.y=435;assert.equal(C.target(s,{x:500,y:310},113),null);
 upper.x=500;upper.y=310;assert.equal(C.target(s,{x:500,y:310},0).key,upper.key);
});

test('midgame and finale use authored composition and arrival windows rather than exponentiating rat health',()=>{
 const counts=[3,4,6,10,14,18,22,28,37];
 for(let wave=1;wave<=C.MAX_WAVE;wave++){
  const p=C.plan(wave);assert.equal(p.spawns.length,counts[wave-1]);assert.equal(p.chapter,Math.ceil(wave/3));
  assert.ok(p.spawns.every((e,i)=>e.spawnIndex===i&&e.at>=0&&(!i||e.at>=p.spawns[i-1].at)));
  for(const e of p.spawns)assert.ok(e.at+length(e.lane)/e.speed+1<p.duration||wave<=3,'Each later spawn can reach home before its own timeout');
 }
 assert.ok(C.plan(4).kinds.includes('scout'));assert.ok(C.plan(5).kinds.includes('guard'));assert.equal(C.plan(9).spawns.filter(e=>e.kind==='chief').length,1);
 const normal=C.plan(9).spawns.filter(e=>e.kind==='rat');assert.ok(normal.every(e=>e.hp===26));assert.notEqual(C.plan(4).pattern,C.plan(5).pattern);
 const p=C.plan(9);p.spawns[0].armor=500;assert.equal(C.plan(9).spawns[0].armor,2);
});
test('a saved three-wave prototype continues to chapter two without resetting people or repaying old rewards',()=>{
 const old={...C.fresh(),phase:'result',wave:3,cleared:3,round:4,claimedFirst:[1,2,3],elapsed:50,result:{wave:3,win:true,boxes:1,kills:4,escaped:2,gold:50,first:true}};
 delete old.completed;delete old.completedAtRound;delete old.journey;
 const state=C.migrate(old);assert.equal(state.completed,false);assert.equal(state.cleared,3);assert.deepEqual(C.tick(state,100),[]);assert.equal(C.nextRequirement(state),'workshop');
 assert.equal(C.start(state),true);assert.equal(state.wave,4);assert.deepEqual(state.claimedFirst,[1,2,3]);assert.equal(state.round,5);
 assert.equal(C.nextRequirement({...C.fresh(),wave:7}),'gate');assert.equal(C.nextRequirement({...C.fresh(),wave:9}),'beacon');assert.equal(C.nextRequirement(C.fresh()),null);
});
test('mixed-kind JSON saves recover each authored speed, armor, radius and health without accepting modified definitions',()=>{
 const a=active(9);C.tick(a,16);const chief=a.enemies.find(e=>e.kind==='chief'),guard=a.enemies.find(e=>e.kind==='guard'),scout=a.enemies.find(e=>e.kind==='scout');
 C.hit(a,chief.key,32,'arch');C.hit(a,guard.key,3,'sword');C.hit(a,scout.key,1,'sword');
 const raw=clone(a);for(const e of raw.enemies){e.speed=999;e.armor=999;e.r=999;e.maxHp=999;}
 const b=C.migrate(raw);compareProgress(a,b);
 for(const enemy of b.enemies){const expected=C.plan(9).spawns[enemy.spawnIndex];assert.equal(enemy.speed,expected.speed);assert.equal(enemy.armor,expected.armor);assert.equal(enemy.r,expected.r);assert.equal(enemy.maxHp,expected.hp);}
 C.tick(a,17.25);for(let i=0;i<69;i++)C.tick(b,.25);compareProgress(a,b);
});
test('armor changes the value of a swordsman without making clicks or arrows do zero damage',()=>{
 const s=active(5);C.tick(s,0);const guard=s.enemies.find(e=>e.kind==='guard');assert.equal(guard.armor,2);
 assert.equal(C.hit(s,guard.key,5,'arch').applied,3);assert.equal(C.hit(s,guard.key,4,'manual').applied,2);assert.equal(C.hit(s,guard.key,3,'sword').applied,3);assert.equal(guard.slowUntil,1.5);
 assert.equal(C.hit(s,guard.key,1,'arch').applied,0);assert.ok(guard.hp>0);
});
test('the constructed gate extends a real rescue window and that window survives a reload',()=>{
 const a=active();C.tick(a,length('upper')/22+1.4,{gateBuilt:true});const enemy=a.enemies[0];assert.equal(a.gateSeconds,2.5);assert.equal(enemy.alive,true);near(enemy.gateTime,1.4);
 const b=C.migrate(clone(a));assert.equal(b.gateSeconds,2.5);assert.equal(b.enemies[0].alive,true);C.tick(a,1);C.tick(b,1);compareProgress(a,b);assert.equal(b.enemies[0].alive,true);C.hit(b,enemy.key,100,'manual');C.tick(b,.2);assert.equal(b.boxes,3);
 C.tick(a,.1);assert.equal(a.enemies[0].alive,false);assert.equal(a.boxes,2);
 const old=active();C.tick(old,length('upper')/22+.4);const raw=clone(old);delete raw.gateSeconds;assert.equal(C.migrate(raw).gateSeconds,1);
});
test('the final captain must actually be defeated even if all three food crates were otherwise protected',()=>{
 const s=active(9);C.tick(s,0);const events=[];
 for(let i=0;i<C.plan(9).duration*4;i++){
  for(const e of s.enemies)if(e.alive&&e.kind!=='chief')C.hit(s,e.key,1000,'sword');events.push(...C.tick(s,.25,{gateBuilt:true}));
 }
 assert.equal(events.length,1);assert.equal(s.result.boxes,2);assert.equal(s.result.chiefDefeated,false);assert.equal(s.result.win,false);assert.equal(s.result.gold,0);assert.equal(s.result.reason,'captain');assert.equal(s.completed,false);assert.equal(s.claimedFirst.includes(9),false);
 assert.equal(C.start(s),true);assert.equal(s.wave,9);const result=winRound(s);assert.equal(result.win,true);assert.equal(result.chiefDefeated,true);assert.equal(s.completed,true);assert.equal(C.start(C.migrate(clone(s))),false);
});
test('workshop tools have two bounded tiers, and victory totals retain actual bounded journey statistics',()=>{
 assert.equal(C.stats('woodcutter',{tools:{wood:1}}).interval,2.5);assert.equal(C.stats('woodcutter',{tools:{wood:2}}).interval,1.5);assert.equal(C.stats('miner',{tools:{stone:1}}).interval,3);assert.equal(C.stats('miner',{tools:{stone:2}}).interval,2);
 assert.equal(C.stats('woodcutter',{tools:{wood:5000}}).interval,1.5);assert.equal(C.stats('miner',{tools:{stone:-10}}).interval,6);assert.equal(C.stats('woodcutter',{tools:{wood:NaN}}).interval,5);assert.equal(C.stats('arch',{tools:{wood:5000,stone:5000}}).damage,5);
 const raw={...C.fresh(),journey:{seconds:123.4,handWood:55,handStone:12,crewWood:902,crewStone:500,unknown:999}};assert.deepEqual(C.migrate(raw).journey,{seconds:123.4,handWood:55,handStone:12,crewWood:902,crewStone:500,handFood:0,crewFood:0});
 raw.journey={seconds:Infinity,handWood:-30,handStone:1e100,crewWood:NaN,crewStone:'200'};assert.deepEqual(C.migrate(raw).journey,{seconds:0,handWood:0,handStone:1e12,crewWood:0,crewStone:0,handFood:0,crewFood:0});
});
function modelDefence(wave,archers,swords){
 const {Battle}=require('../2/army-sim.js'),state=active(wave),battle=new Battle();
 battle.fixedWorld=true;battle.stationary=true;battle.bounds(960,540,{x:10000,y:10000,r:0,alive:false});battle.outpostState=state;battle.roundToken=state.round;battle.enemies=state.enemies;
 battle.sync([{id:'arch',count:archers,ranged:true,...C.stats('arch'),anim:{impact:680}},{id:'sword',count:swords,ranged:false,...C.stats('sword'),anim:{impact:240}}]);
 const counts={arch:[0,0],sword:[0,0]};
 for(const p of battle.soldiers){const lane=p.index%2,index=counts[p.id][lane]++;p.x=p.id==='arch'?534+index%5*29:700+index%4*29;p.y=C.WORLD[lane?'lower':'upper']+(p.id==='arch'?35+Math.floor(index/5)*25:15+Math.floor(index/4)*25);}
 const before=battle.soldiers.map(p=>[p.x,p.y]);
 for(let i=0;i<C.plan(wave).duration*30;i++){
  C.tick(state,1/30,{gateBuilt:wave>=7});battle.enemies=state.phase==='active'?state.enemies:[];
  for(const event of battle.step(1/30,{x:0,y:0,hp:1,max:1}))if(event.kind==='damage')C.hit(state,event.targetKey,event.amount,event.p.id);
 }
 assert.deepEqual(battle.soldiers.map(p=>[p.x,p.y]),before);return state;
}
test('the authored final crowd rewards a materially grown stationary army using real delayed individual hits',()=>{
 const introductoryArmy=modelDefence(9,4,0),developedArmy=modelDefence(9,22,8);
 assert.equal(introductoryArmy.result.win,false);assert.equal(introductoryArmy.completed,false);
 assert.equal(developedArmy.result.win,true);assert.equal(developedArmy.result.chiefDefeated,true);assert.equal(developedArmy.completed,true);assert.ok(developedArmy.result.kills>=35);
 // Prepared diagnostic formations, not a claim about a person's playthrough or placement UI.
});
test('the intended end-game crew and authored construction budget stay finite and outside exponential upgrade chains',()=>{
 const totals={wood:0,stone:0};for(const [id,count]of [['woodcutter',5],['miner',5],['arch',20],['sword',8]]){const quote=C.recipe(id,0,count);totals.wood+=quote.wood;totals.stone+=quote.stone;}
 // Two tool tiers for both professions, the gate and final beacon are quoted by the camp.
 totals.wood+=45+30+100+70+100+220;totals.stone+=20+35+60+100+60+160;
 assert.deepEqual(totals,{wood:2315,stone:1341});assert.ok(totals.wood<2500&&totals.stone<1500);
 assert.ok(5/C.stats('woodcutter',{tools:{wood:2}}).interval>3);assert.equal(5/C.stats('miner',{tools:{stone:2}}).interval,2.5);
});

test('perfect elimination settles on the next tick without waiting out the deadline or duplicating its saved reward',()=>{
 const state=active();C.tick(state,12);for(const enemy of state.enemies)C.hit(state,enemy.key,1000,'manual');
 assert.equal(state.phase,'active');assert.equal(state.result,null);assert.equal(state.kills,3);
 const events=C.tick(state,.1);assert.equal(events.length,1);assert.equal(state.phase,'result');assert.equal(state.result.win,true);assert.equal(state.result.gold,38);near(state.elapsed,12);
 const saved=C.migrate(clone(state));near(saved.elapsed,12);assert.deepEqual(C.tick(saved,100),[]);assert.deepEqual(saved.result,state.result);assert.deepEqual(saved.claimedFirst,[1]);
 assert.equal(C.start(saved),true);assert.equal(saved.wave,2);assert.equal(saved.elapsed,0);
});
test('the next-tick final victory keeps its real early-clear time and explicit replay still has no first-clear payout',()=>{
 const state=active(9);C.tick(state,16);for(const enemy of state.enemies)C.hit(state,enemy.key,1000,'sword');assert.equal(state.phase,'active');
 const events=C.tick(state,.05);assert.equal(events.length,1);assert.equal(state.completed,true);assert.equal(state.result.chiefDefeated,true);near(state.elapsed,16);
 const saved=C.migrate(clone(state));near(saved.elapsed,16);assert.equal(C.start(saved),false);assert.deepEqual(C.tick(saved,100),[]);assert.equal(C.start(saved,{replay:true}),true);
 const repeat=winRound(saved);assert.equal(repeat.first,false);assert.equal(repeat.gold,18);assert.equal(saved.completedAtRound,1);
});

test('effective attack range follows each enemy body radius while default targeting stays exact',()=>{
 const s=active();C.tick(s,0);const e=s.enemies[0];e.r=25;const edge={x:e.x+125,y:e.y};assert.equal(C.target(s,edge,100),null);assert.equal(C.target(s,edge,100,{includeEnemyRadius:true}),e);assert.equal(C.target(s,{x:edge.x+.01,y:edge.y},100,{includeEnemyRadius:true}),null);e.r=10;assert.equal(C.target(s,{x:e.x+111,y:e.y},100,{includeEnemyRadius:true}),null);
});

test('thin supplies fails on its second breakthrough and restores the frozen result without paying again',()=>{
 const s=C.fresh();s.heat=C.heat({conditions:['thin']});C.start(s);assert.equal(s.boxes,2);
 let events=[];for(let i=0;i<600&&s.phase==='active';i++)events.push(...C.tick(s,.1));
 assert.equal(events.length,1);assert.equal(s.result.reason,'crates');assert.equal(s.result.escaped,2);assert.equal(s.result.gold,0);assert.equal(s.enemies.filter(e=>e.alive).length,1);
 const restored=C.migrate(clone(s));assert.deepEqual(restored.result,s.result);assert.deepEqual(C.tick(restored,1000),[]);assert.equal(C.hit(restored,restored.enemies.find(e=>e.alive).key,1000,'arch').applied,0);
});
test('a legacy active save with zero crates settles once immediately and cannot harvest extra kills',()=>{
 const s=active(3);C.tick(s,4);s.boxes=0;
 const restored=C.migrate(clone(s)),keys=restored.enemies.length;
 assert.equal(C.tick(restored,0)[0].result.reason,'crates');assert.equal(restored.enemies.length,keys);assert.equal(restored.result.gold,0);assert.deepEqual(C.tick(restored,1000),[]);
});
