const test=require('node:test'),assert=require('node:assert/strict'),Supply=require('../2/supply-core.js');
test('outpost resources are physical count-one objects even at an identical source position',()=>{
 const s=Supply.fresh(960,540);Supply.individualize(s);for(let i=0;i<120;i++)Supply.drop(s,'wood',1,300,350,1);assert.equal(s.drops.length,120);assert.ok(s.drops.every(d=>d.count===1&&d.source===1));assert.equal(new Set(s.drops.map(d=>d.key)).size,120);
 const first=s.drops[0];assert.deepEqual(Supply.deliver(s,first),{type:'wood',count:1});assert.equal(s.inventory.wood,1);assert.equal(s.drops.length,119);
});
test('legacy bundles split into separate items and retain worker provenance and exact total through save',()=>{
 const s=Supply.fresh(960,540);s.drops=[{key:20,type:'wood',count:32,x:300,y:360,worker:true,source:1},{key:21,type:'stone',count:17,x:400,y:400,source:2}];Supply.individualize(s);assert.equal(s.drops.length,49);assert.ok(s.drops.every(d=>d.count===1));assert.equal(s.drops.filter(d=>d.worker).length,32);const out=Supply.migrate(JSON.parse(JSON.stringify(s)));assert.equal(out.drops.length,49);assert.equal(new Set(out.drops.map(d=>d.key)).size,49);assert.equal(out.inventory.wood,0);
});
test('oversized legacy saves preserve reserve without crediting inventory or exposing bulk draggable items',()=>{
 const s=Supply.fresh(960,540);s.drops=[{key:1,type:'wood',count:Supply.MAX_LOOSE+7,x:200,y:350,source:1}];Supply.individualize(s);assert.equal(s.drops.length,Supply.MAX_LOOSE);assert.equal(s.legacyLoose[0].count,7);assert.ok(s.drops.every(d=>d.count===1));Supply.deliver(s,s.drops[0]);Supply.unpackLegacy(s);assert.equal(s.inventory.wood,1);assert.equal(s.drops.length,Supply.MAX_LOOSE);assert.equal(s.legacyLoose[0].count,6);const out=Supply.migrate(JSON.parse(JSON.stringify(s)));assert.equal(out.drops.length+out.legacyLoose.reduce((n,d)=>n+d.count,0)+out.inventory.wood,Supply.MAX_LOOSE+7);
});
test('a full physical-item budget rejects new production without merging into existing items',()=>{
 const s=Supply.fresh(960,540);Supply.individualize(s);Supply.drop(s,'wood',Supply.MAX_LOOSE,200,300,1);assert.equal(Supply.drop(s,'wood',1,200,300,1),null);assert.equal(s.drops.length,Supply.MAX_LOOSE);assert.ok(s.drops.every(d=>d.count===1));
});
