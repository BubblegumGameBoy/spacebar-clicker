const test=require('node:test'),assert=require('node:assert/strict');
const C=require('../2/outpost-core.js'),F=require('../2/field-core.js'),D=require('../2/campaign-core.js'),E=require('../2/expedition-core.js');
const copy=x=>JSON.parse(JSON.stringify(x));
test('thirty authored raids have ten distinct bosses and ability-led districts, without exponential normal stats',()=>{
 assert.equal(C.MAX_WAVE,30);const bosses=[];
 for(let w=1;w<=30;w++){const p=C.plan(w);assert.ok(p.spawns.length>0);assert.equal(p.district,D.chapter(w).name);assert.equal(p.chapter,Math.ceil(w/3));assert.equal(p.boss!==null,w%3===0);
  if(p.boss){bosses.push(p.boss);assert.equal(p.spawns.filter(e=>e.kind===p.boss).length,1);assert.ok(C.has({kind:p.boss},'boss'));}
  for(const e of p.spawns){assert.equal(e.entryX,F.hole(e.holeId).x);if(w>3)assert.ok(e.at+C.lengthOf(e)/e.speed+(C.ENEMIES[e.kind].sling?.seconds||2.5)<p.duration,w+' '+e.kind);if(w>=10&&e.kind==='rat')assert.equal(e.hp,26);}
 }
 assert.equal(new Set(bosses).size,10);assert.ok(C.has({kind:'nightwing'},'fly'));assert.ok(C.has({kind:'elder'},'heal'));assert.ok(C.has({kind:'deeproot'},'burrow'));assert.equal(C.ENEMIES.oozemother.split.count,4);assert.equal(C.ENEMIES.siegeking.split.count,6);
});
test('roads and burrows appear from the next actual raid before starting; only encountered trails remain solid',()=>{
 const s=C.fresh();let p=C.plan(1),r=F.routes(p,s);assert.ok(r[0].isNew);assert.equal(r[1].entryX,0);assert.deepEqual(F.visibleHoles(p,s).map(h=>h.id),['north']);
 C.start(s);assert.equal(s.routeSeen,1);assert.ok(!F.routes(C.planFor(s),s)[0].isNew);
 s.phase='result';s.result={wave:1,win:true};p=C.plan(2);assert.ok(F.routes(p,s)[1].isNew);assert.deepEqual(F.visibleHoles(p,s).map(h=>h.id),['north','south']);
 s.routeSeen=3;s.cleared=3;p=C.plan(4);r=F.routes(p,s);assert.equal(r[0].knownX,925);assert.equal(r[0].targetX,1450);assert.deepEqual(r[0].previewPoints,[{x:1450,y:185},{x:925,y:185}]);assert.equal(r[1].isNew,false);
 s.routeSeen=6;s.cleared=6;r=F.routes(C.plan(7),s);assert.equal(r[0].isNew,false);assert.equal(r[1].isNew,true);
});
test('each district boss escaping ends the raid with crates left; an actual kill allows a win',()=>{
 for(let wave=3;wave<=30;wave+=3)for(const killBoss of [false,true]){const s=C.fresh();s.wave=wave;C.start(s);const boss=C.planFor(s).boss;
  for(let i=0;i<10000&&s.phase==='active';i++){C.tick(s,.1,{gateBuilt:true});C.reveal(s,s.enemies.map(e=>({x:e.x,y:e.y,alive:true})));for(const e of s.enemies)if(e.alive&&(killBoss||e.kind!==boss))C.hit(s,e.key,10000,'arch');}
  assert.equal(s.result.win,killBoss,wave+' '+boss);if(!killBoss){assert.equal(s.result.reason,'captain');assert.equal(s.result.boxes,2);assert.equal(s.result.gold,0);}const saved=C.migrate(copy(s));assert.deepEqual(saved.result,s.result);assert.equal(saved.completed,wave===30&&killBoss);
 }
});
test('old active plans keep exact enemies and origins; old completion continues at ten without duplicate payment',()=>{
 for(const version of [1,2,3,4]){const s=C.fresh();s.planVersion=version;s.phase='active';s.wave=6;s.round=6;C.tick(s,8);const raw=copy(s),back=C.migrate(raw);assert.equal(back.planVersion,version);assert.deepEqual(back.enemies,s.enemies);assert.deepEqual(raw,copy(s));}
 const old={...C.fresh(),planVersion:4,routeSeen:0,wave:9,cleared:9,phase:'result',round:9,completed:true,claimedFirst:[1,2,3,4,5,6,7,8,9],result:{wave:9,win:true,boxes:3,kills:37,escaped:0,gold:102,first:true,chiefDefeated:true}};
 const s={outpost:C.migrate(old),owned:{},pending:{},gold:482};E.ensure(s);assert.equal(s.outpost.completed,false);assert.equal(s.expedition.awaitingReady,true);assert.equal(s.gold,482);assert.ok(C.start(s.outpost));assert.equal(s.outpost.wave,10);assert.equal(s.outpost.planVersion,C.PLAN_VERSION);assert.equal(s.gold,482);
});
test('all ten district checkpoints stop the raid clock and retry keeps the discovered world',()=>{
 const S={outpost:C.fresh(),owned:{},pending:{}};const e=E.ensure(S);
 for(let wave=3;wave<30;wave+=3){S.outpost={...C.fresh(),phase:'result',wave,round:wave,cleared:wave,result:{wave,win:true}};assert.equal(E.record(S,{wave,win:true,kills:C.plan(wave).potential}),true);assert.equal(e.awaitingReady,true);e.awaitingReady=false;}
 S.outpost={...C.fresh(),phase:'result',wave:26,cleared:25,routeSeen:26,round:26,result:{wave:26,win:false,boxes:0}};assert.equal(E.retryQuote(S).startWave,25);assert.ok(E.retry(S));assert.equal(S.outpost.routeSeen,26);assert.equal(S.outpost.wave,25);
});
test('a castle is built by paid camp projects, not granted by wave completion',()=>{
 assert.equal(D.stronghold({cleared:30}).stage,0);assert.equal(D.stronghold({tools:{stone:1}}).name,'職人の拠点');assert.equal(D.stronghold({gate:true}).name,'街道の砦');assert.equal(D.stronghold({gate:true,beacon:true}).name,'灯火の城');
});

test('startup before the outpost exists cannot consume the initial Ready gate',()=>{const S={owned:{},pending:{}};E.ensure(S);assert.equal(S.expedition.roadsVersion,undefined);S.outpost=C.fresh();E.ensure(S);assert.equal(S.expedition.awaitingReady,true);assert.equal(S.outpost.prepRemaining,240);});
