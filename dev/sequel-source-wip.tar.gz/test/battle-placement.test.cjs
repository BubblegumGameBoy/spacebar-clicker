const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const Supply=require('../2/supply-core.js'),Army=require('../2/army-sim.js');
const source=fs.readFileSync(require.resolve('../2/battle-control.js'),'utf8');
function control(factory,width=1100,bodies=[],wave=1){
 const sim=new Army.Battle(),boss=Math.min(340,240*1.025**(wave-1));
 sim.bounds(width,500,{x:width-55-boss*.4,y:500-70-boss*.22,r:boss*.28});sim.soldiers=bodies;
 const scope={window:{},performance,S:{pending:{}},UNITS:[],ArmyView:{sim,camera:{scale:width===640?.609:1},bodyHeight:()=>54},SupplyFactory:{state:factory,nearby:(p,type)=>factory.nodes.find(n=>n.type===type&&n.stock>0&&Math.hypot(n.x-p.x,n.y-p.y)<64)}};
 vm.createContext(scope);vm.runInContext(source,scope);scope.window.BattleControl.resize(width,500);return scope.window.BattleControl;
}
const archer={u:{id:'arch',ranged:true},r:10};
test('first archer always has a legal visible suggestion across varied mobile and desktop maps',()=>{
 for(const width of [640,1100])for(let seed=0;seed<200;seed++){
  const c=control(Supply.fresh(width,500,seed),width),spots=c.spots(archer);
  assert.ok(spots.length,`no suggestion for ${width}px map, seed ${seed}`);
  for(const spot of spots)assert.ok(c.valid(spot,archer));
 }
});
test('a real review save with crowded old suggestions still guides the next archer',()=>{
 const fixture=require('./fixtures/crowded-placement.json'),c=control(fixture.factory,fixture.width,fixture.units,fixture.wave),spots=c.spots(archer);
 assert.ok(spots.length>0,'purchased archer must not be stranded without a placement guide');
 for(const point of spots)assert.ok(c.valid(point,archer));
});
