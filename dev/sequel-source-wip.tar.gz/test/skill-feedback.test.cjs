const test=require('node:test'),assert=require('node:assert/strict'),Skills=require('../2/harvest-skill-core.js');
const state=(inv={wood:0,stone:0},skills={})=>({harvestSkills:skills,factory:{inventory:inv},camp:{links:[],platforms:[]}});
test('learning feedback tiers: tier 3 is a milestone, tier 6 masters the branch, others are ordinary',()=>{
 for(const branch of Skills.branches)for(let tier=1;tier<=6;tier++)assert.equal(Skills.rank(branch+tier).kind,tier===6?'mastery':tier===3?'milestone':'skill');
 assert.deepEqual(Skills.rank('hand3'),{id:'hand3',branch:'hand',tier:3,kind:'milestone'});for(const bad of ['carry0','carry7','x1',null])assert.equal(Skills.rank(bad),null);});
test('next goal is the next tier of the same branch with the remaining materials and progress',()=>{
 const s=state({wood:1,stone:0},{carry:1});const g=Skills.nextGoal(s,'carry');assert.equal(g.id,'carry2');assert.deepEqual(g.missing,{wood:29,stone:0});assert.ok(Math.abs(g.progress-1/30)<1e-9);
 const both=Skills.nextGoal(state({wood:120,stone:10},{carry:3}),'carry');assert.equal(both.id,'carry4');assert.equal(both.progress,10/40,'progress is the scarcer material');
 assert.equal(Skills.nextGoal(state({},{carry:6}),'carry'),null);assert.equal(Skills.nextGoal(state(),'nope'),null);});
test('feedback helpers never change costs or effects',()=>{const s=state({wood:100,stone:100});const before=JSON.stringify(s),costs=JSON.stringify(Skills.costs);Skills.nextGoal(s,'carry');Skills.rank('carry1');Skills.readyNotice(null,{now:0,ready:Skills.available(s)});assert.equal(JSON.stringify(s),before);assert.equal(JSON.stringify(Skills.costs),costs);});
test('newly ready detects only skills that were not ready before',()=>{assert.deepEqual(Skills.newlyReady(['carry1'],['carry1','storage1']),['storage1']);assert.deepEqual(Skills.newlyReady([{id:'carry1'}],[{id:'carry1'}]),[]);assert.deepEqual(Skills.newlyReady(null,['hand1']),['hand1']);});
test('ready notice: silent on load, waits 180 ms after the pickup, held while dragging or raiding, once per 4 s',()=>{
 let r=Skills.readyNotice(null,{now:1000,ready:['carry1']});assert.equal(r.play,false,'existing readiness at load is not announced');
 r=Skills.readyNotice(r.memo,{now:1100,ready:['carry1','storage1'],lastPickupAt:1050});assert.equal(r.play,false);assert.equal(r.waitUntil,1230);
 r=Skills.readyNotice(r.memo,{now:1240,ready:['carry1','storage1'],lastPickupAt:1050});assert.equal(r.play,true);
 r=Skills.readyNotice(r.memo,{now:1300,ready:['carry1','storage1']});assert.equal(r.play,false,'same set is not re-announced');
 r=Skills.readyNotice(r.memo,{now:3000,ready:['carry1','storage1','hand1'],lastPickupAt:2700});assert.equal(r.play,false);assert.equal(r.waitUntil,5240,'within 4 s of the last notice it is postponed');assert.equal(r.memo.pending,true,'and kept, not dropped');
 r=Skills.readyNotice(r.memo,{now:5000,ready:['carry1','storage1','hand1']});assert.equal(r.play,false);
 r=Skills.readyNotice(r.memo,{now:5240,ready:['carry1','storage1','hand1']});assert.equal(r.play,true,'the postponed notice sounds once the 4 s have passed');
 r=Skills.readyNotice(r.memo,{now:9300,ready:['carry1','storage1','hand1','route1'],dragging:true});assert.equal(r.play,false);assert.equal(r.memo.pending,true,'kept while dragging');
 r=Skills.readyNotice(r.memo,{now:9400,ready:['carry1','storage1','hand1','route1'],raid:true});assert.equal(r.play,false);assert.equal(r.memo.pending,true,'kept during a raid');
 r=Skills.readyNotice(r.memo,{now:9500,ready:['carry1','storage1','hand1','route1']});assert.equal(r.play,true,'released after the drag/raid');
 r=Skills.readyNotice(r.memo,{now:20000,ready:[]});r=Skills.readyNotice(r.memo,{now:20100,ready:['carry1']});assert.equal(r.play,true,'a skill becoming ready again counts');});
test('a chime that could not sound stays pending with the previous notice time',()=>{const m=Skills.readyNoticeFailed({ids:['a'],pending:false,lastNotice:5000},1000);assert.equal(m.pending,true);assert.equal(m.lastNotice,1000);const r=Skills.readyNotice(m,{now:5100,ready:['a']});assert.equal(r.play,true);});
test('ready notice drops a pending chime when nothing is ready any more',()=>{let r=Skills.readyNotice(null,{now:0,ready:[]});r=Skills.readyNotice(r.memo,{now:10,ready:['carry1'],dragging:true});assert.equal(r.memo.pending,true);r=Skills.readyNotice(r.memo,{now:20,ready:[]});assert.equal(r.play,false);assert.equal(r.memo.pending,false);});
test('hand pickups climb up to +7 semitones spread over the current capacity',()=>{const st=Math.pow(2,1/12);assert.equal(Skills.pickupRate(1,2),1);assert.ok(Math.abs(Skills.pickupRate(2,2)-Math.pow(st,7))<1e-12,'two hands: the second item is +7');
 for(const cap of [2,4,6,16]){let prev=0;for(let n=1;n<=cap;n++){const r=Skills.pickupRate(n,cap);assert.ok(r>prev);prev=r;}assert.ok(Math.abs(prev-Math.pow(st,7))<1e-12,'top of capacity '+cap+' is +7');}
 assert.equal(Skills.pickupRate(9,4),Skills.pickupRate(4,4),'never above +7');assert.equal(Skills.pickupRate(0,4),1);assert.equal(Skills.pickupRate('x',4),1);});
test('a camp:handpickup gets one pickup per new item, 35 ms apart, six at most, then the full knock 35 ms after the last',()=>{
 const two=Skills.pickupSchedule(1,2,2);assert.deepEqual(two.sounds,[{delay:0,rate:Skills.pickupRate(2,2)}]);assert.deepEqual(two.full,{delay:35});
 assert.deepEqual(Skills.pickupSchedule(0,1,4),{sounds:[],full:null},'the first grab stays silent');
 const pile=Skills.pickupSchedule(0,6,6);assert.deepEqual(pile.sounds.map(e=>e.delay),[0,35,70,105,140]);assert.deepEqual(pile.sounds.map(e=>e.rate),[2,3,4,5,6].map(n=>Skills.pickupRate(n,6)));assert.deepEqual(pile.full,{delay:175});
 const many=Skills.pickupSchedule(0,16,16);assert.equal(many.sounds.length,6,'six sounds at most');assert.equal(many.full.delay,210);
 assert.equal(Skills.pickupSchedule(2,3,6).full,null,'not full yet');assert.equal(Skills.pickupSchedule(6,6,6).full,null,'already full is not repeated');});
test('gathering tier 2+ adds quiet extra drops per tap: items-1, at most three',()=>{assert.equal(Skills.harvestExtras(1,2),0);assert.equal(Skills.harvestExtras(2,3),2);assert.equal(Skills.harvestExtras(6,8),3);assert.equal(Skills.harvestExtras(3,1),0);});
test('branch spine: learned segments full, next one filled by material progress',()=>{assert.deepEqual(Skills.spine(state({wood:15},{carry:1}),'carry'),[1,.5,0,0,0,0]);assert.deepEqual(Skills.spine(state({wood:0},{}),'hand'),[0,0,0,0,0,0]);assert.deepEqual(Skills.spine(state({},{carry:6}),'carry'),[1,1,1,1,1,1]);});
test('map taps: select first, learn on a later tap; never during the purchase lock',()=>{const base={id:'carry2',selected:'carry2',selectedAt:1000,ready:true};
 assert.equal(Skills.tapAction({...base,id:'carry3',now:1100}),'select');
 assert.equal(Skills.tapAction({...base,byTap:true,now:1200}),'none','second tap closer than 250 ms is ignored (no double-click buy)');
 assert.equal(Skills.tapAction({...base,byTap:true,now:1250}),'buy');
 assert.equal(Skills.tapAction({...base,byTap:false,now:1300}),'arm','an auto-selected node needs one more deliberate tap');
 assert.equal(Skills.tapAction({...base,pill:true,now:1300}),'buy','the learn pill learns directly');
 assert.equal(Skills.tapAction({...base,byTap:true,pill:true,now:1300,lockUntil:1400}),'none','locked right after a purchase / auto switch');
 assert.equal(Skills.tapAction({...base,byTap:true,now:1300,ready:false}),'none');});
test('field use fires once the new value is first exceeded, per branch',()=>{
 const pend=(id,before,after)=>({id,branch:Skills.rank(id).branch,before:Skills.effects(before),after:Skills.effects(after)});
 const carry=pend('carry1',{},{carry:1});assert.equal(Skills.fieldUse(carry,{held:1}),null);assert.deepEqual(Skills.fieldUse(carry,{held:2}),{branch:'carry',id:'carry1'});
 const hand=pend('hand1',{},{hand:1});assert.equal(Skills.fieldUse(hand,{harvested:0}),null);assert.equal(Skills.fieldUse(hand,{harvested:2}).extraSounds,1);
 const hand6=pend('hand6',{hand:5},{hand:6});assert.equal(Skills.fieldUse(hand6,{harvested:8}).extraSounds,2);const big=pend('hand3',{hand:0},{hand:3});assert.equal(Skills.fieldUse(big,{harvested:4}).extraSounds,3,'never more than three extra drop sounds');
 const storage=pend('storage1',{},{storage:1});assert.equal(Skills.fieldUse(storage,{ground:240}),null);assert.equal(Skills.fieldUse(storage,{ground:241}).branch,'storage');
 const route=pend('route1',{},{route:1});assert.equal(Skills.fieldUse(route,{}),null);assert.equal(Skills.fieldUse(route,{closed:true}).pulse,true);assert.equal(Skills.fieldUse(null,{held:9}),null);});
