const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const Core=require('../2/game-core.js'),Supply=require('../2/supply-core.js');
const IDS=['woodcutter','miner','arch','sword'];
function fixture(){
 const S=Core.fresh(IDS);S.gold=100;S.factory=Supply.fresh(960,540);S.outpost={cleared:0};
 const calls={save:0,units:0,cards:0,audio:[]};
 const scope={S,LANG:'ja',SupplyCore:Supply,ConveyorCore:require('../2/conveyor-core.js'),document:{getElementById:()=>null},ForestAudio:{play:id=>calls.audio.push(id)},save:()=>calls.save++,renderUnits:()=>calls.units++,renderCards:()=>calls.cards++,updateHud(){},ArmyView:{sim:{soldiers:[]}},SupplyFactory:{translate(){}}};scope.window=scope;
 vm.createContext(scope);let code=fs.readFileSync(require.resolve('../2/outpost-camp.js'),'utf8');code=code.replace('return {undoBuild:', 'return {__dispatch:dispatch,undoBuild:');vm.runInContext(code,scope);
 const api=scope.OutpostCamp;api.quote('woodTool');return {S,api,calls};
}
const plain=x=>JSON.parse(JSON.stringify(x));
test('old camps keep materials and receive no free campaign improvements',()=>{
 const s=Core.fresh(IDS);s.factory=Supply.fresh(960,540);s.factory.inventory={wood:23,stone:14};s.camp={version:1,links:[],cargo:[],nextKey:1};
 const out=Core.migrate(s,IDS);assert.deepEqual(out.camp.tools,{wood:0,stone:0});for(const key of ['cart','gate','beacon','endingSeen'])assert.equal(out.camp[key],false);assert.deepEqual(out.factory.inventory,{wood:23,stone:14});
});
test('campaign camp progress and cargo modes survive migration without granting currency',()=>{
 const s=Core.fresh(IDS);s.factory=Supply.fresh(960,540);s.gold=71;s.camp={version:1,links:[],cargo:[{key:2,type:'wood',count:4,from:{x:280,y:308},progress:.4,duration:2,mode:'rail',worker:true,source:1}],nextKey:3,tools:{wood:2,stone:1},gate:true,beacon:true,cart:true,endingSeen:true};
 const out=Core.migrate(s,IDS);assert.deepEqual(out.camp.tools,{wood:2,stone:1});for(const key of ['cart','gate','beacon','endingSeen'])assert.equal(out.camp[key],true);assert.equal(out.gold,71);assert.equal(out.factory.inventory.wood,0);assert.equal(out.camp.cargo[0].progress,.4);assert.equal(out.camp.cargo[0].mode,'rail');
 const bad=Core.migrate({...s,camp:{...s.camp,tools:{wood:Infinity,stone:-5},gate:'true',beacon:1,cart:{},endingSeen:'true'}},IDS);assert.deepEqual(bad.camp.tools,{wood:0,stone:0});for(const key of ['cart','gate','beacon','endingSeen'])assert.equal(bad.camp[key],false);
});
test('project unlocks and insufficient resources are atomic',()=>{
 const {S,api,calls}=fixture();S.factory.inventory={wood:1000,stone:1000};assert.equal(api.canBuild('woodTool'),false);const before=JSON.stringify(S);assert.equal(api.build('woodTool'),false);assert.equal(JSON.stringify(S),before);assert.equal(calls.save,0);
 S.outpost.cleared=3;S.factory.inventory.wood=44;assert.equal(api.quote('woodTool').locked,false);assert.equal(api.build('woodTool'),false);assert.equal(S.factory.inventory.wood,44);assert.equal(api.quote('missing'),null);
});
test('each tool has exactly two authored upgrades, deducts exact material costs and refreshes real workers',()=>{
 const {S,api,calls}=fixture();S.outpost.cleared=3;S.factory.inventory={wood:300,stone:200};assert.deepEqual(plain(api.quote('woodTool').cost),{wood:45,stone:20,gold:0});assert.equal(api.build('woodTool'),true);assert.deepEqual(S.factory.inventory,{wood:255,stone:180});assert.equal(S.camp.tools.wood,1);assert.equal(calls.units,1);assert.equal(calls.cards,1);assert.equal(api.build('woodTool'),false);
 assert.equal(api.build('stoneTool'),true);assert.deepEqual(S.factory.inventory,{wood:225,stone:145});S.outpost.cleared=6;assert.equal(api.build('woodTool'),true);assert.deepEqual(S.factory.inventory,{wood:125,stone:85});assert.equal(S.camp.tools.wood,2);const before=JSON.stringify(S);assert.equal(api.build('woodTool'),false);assert.equal(JSON.stringify(S),before);S.factory.inventory.stone=100;assert.equal(api.build('stoneTool'),true);assert.deepEqual(S.factory.inventory,{wood:55,stone:0});assert.deepEqual(plain(api.tools),{wood:2,stone:2});
});
test('chapter gates allow a tool choice, then require the watch gate and final beacon',()=>{
 const {S,api}=fixture();S.factory.inventory={wood:1000,stone:1000};assert.equal(api.canStartWave(3),true);assert.equal(api.canStartWave(4),false);assert.equal(api.campaignReadyWave,3);S.outpost.cleared=3;assert.equal(api.build('stoneTool'),true);assert.equal(api.canStartWave(4),true);assert.equal(api.canStartWave(6),true);assert.equal(api.canStartWave(7),false);assert.equal(api.campaignReadyWave,6);
 S.outpost.cleared=6;assert.equal(api.nextProject.id,'gate');assert.equal(api.build('gate'),true);assert.equal(api.canStartWave(7),true);assert.equal(api.canStartWave(8),true);assert.equal(api.canStartWave(9),false);assert.equal(api.campaignReadyWave,8);S.outpost.cleared=8;assert.equal(api.nextProject.id,'beacon');assert.equal(api.build('beacon'),true);assert.equal(api.canStartWave(9),true);assert.equal(api.campaignReadyWave,9);
});
test('the conveyor motor costs gold once and changes physical belt speed without vacuuming source materials',()=>{
 const {S,api}=fixture();S.outpost.cleared=3;S.camp.links.push({nodeKey:100,type:'wood',kind:'conveyor',points:[{x:100,y:340},{x:300,y:340}]});const on=Supply.drop(S.factory,'wood',1,250,340,1),off=Supply.drop(S.factory,'wood',1,250,400,1);assert.equal(api.__dispatch(S,1),true);assert.equal(on.x,205);assert.equal(off.x,250);assert.equal(off.y,400);assert.equal(S.factory.inventory.wood,0);
 assert.equal(api.build('cart'),true);assert.equal(S.gold,45);assert.equal(api.build('cart'),false);api.__dispatch(S,1);assert.equal(on.x,148.75);assert.equal(S.factory.inventory.wood,0);api.__dispatch(S,2);assert.equal(S.factory.inventory.wood,1);assert.ok(S.factory.drops.includes(off));
});
test('player-authored rail and cargo paths survive save migration; malformed routes are rejected',()=>{
 const s=Core.fresh(IDS);s.factory=Supply.fresh(960,540);s.factory.nodes[0]={...s.factory.nodes[0],type:'wood',x:280,y:300};const points=[{x:280,y:308},{x:220,y:360},{x:160,y:360},{x:100,y:340}];s.camp={version:1,links:[{nodeKey:1,type:'wood',points,cost:26}],cargo:[{key:1,type:'wood',count:4,from:points[0],progress:.4,duration:3,mode:'rail',path:points}],nextKey:2};
 const saved=JSON.stringify(s),out=Core.migrate(JSON.parse(saved),IDS);assert.deepEqual(out.camp.links[0].points,points);assert.equal(out.camp.links[0].cost,26);assert.deepEqual(out.camp.cargo[0].path,points);assert.equal(out.camp.cargo[0].progress,.4);assert.equal(JSON.stringify(s),saved);
 const bad=Core.migrate({...s,camp:{...s.camp,links:[{nodeKey:1,type:'wood',points:[{x:Infinity,y:10},{x:100,y:340}]}]}},IDS);assert.equal(bad.camp.links.length,0);
 const legacy=Core.migrate({...s,camp:{...s.camp,links:[{nodeKey:1,type:'wood'}]}},IDS);assert.equal(legacy.camp.links.length,1);assert.equal(legacy.camp.links[0].points,undefined);
});
test('physical conveyor links do not need a resource id and preserve paid wood and route through reload',()=>{
 const s=Core.fresh(IDS);s.factory=Supply.fresh(960,540);s.factory.inventory={wood:7,stone:3};const points=[{x:100,y:340},{x:160,y:360},{x:240,y:360}];s.camp={version:1,links:[{kind:'conveyor',nodeKey:1001,type:'wood',points,costWood:4}],cargo:[],nextKey:1};
 const out=Core.migrate(JSON.parse(JSON.stringify(s)),IDS);assert.equal(out.camp.links.length,1);assert.equal(out.camp.links[0].kind,'conveyor');assert.equal(out.camp.links[0].costWood,4);assert.deepEqual(out.camp.links[0].points,points);assert.deepEqual(out.factory.inventory,{wood:7,stone:3});
 const legacy=Core.migrate({...s,camp:{...s.camp,links:[{nodeKey:1001,type:'wood',points}]}},IDS);assert.equal(legacy.camp.links.length,0);
});
test('receiving platforms and physical loose pieces persist without turning into inventory',()=>{
 const s=Core.fresh(IDS);s.factory=Supply.fresh(960,540);s.factory.individualDrops=true;s.factory.drops=[{key:90,type:'wood',count:1,x:390,y:330,worker:true,physical:true,beltId:1001}];s.factory.inventory={wood:7,stone:3};s.camp={version:1,links:[],platforms:[{key:7,x:400,y:330,w:96,h:64,dir:2,costWood:8,costStone:4}],cargo:[],nextKey:1};
 const out=Core.migrate(JSON.parse(JSON.stringify(s)),IDS);assert.deepEqual(out.camp.platforms,s.camp.platforms);assert.deepEqual(out.factory.inventory,{wood:7,stone:3});assert.equal(out.factory.drops.length,1);assert.equal(out.factory.drops[0].physical,true);assert.equal(out.factory.drops[0].beltId,1001);assert.equal(out.factory.drops[0].x,390);
});
