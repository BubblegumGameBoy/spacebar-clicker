const test=require('node:test'),assert=require('node:assert/strict');
const Core=require('../2/outpost-core.js'),{Battle}=require('../2/army-sim.js');
// Prepared formations isolate the final investment choice. This is not an earned playthrough.
function finalDefence(archers,swords,beacon){
 const state=Core.fresh();state.wave=9;Core.start(state);
 const camp={beacon},battle=new Battle();battle.fixedWorld=true;battle.stationary=true;
 battle.bounds(960,540,{x:10000,y:10000,r:0,alive:false});battle.outpostState=state;battle.roundToken=state.round;battle.enemies=state.enemies;
 battle.sync([{id:'arch',count:archers,ranged:true,...Core.stats('arch',camp),anim:{impact:680}},{id:'sword',count:swords,ranged:false,...Core.stats('sword',camp),anim:{impact:240}}]);
 const counts={arch:[0,0],sword:[0,0]};
 for(const p of battle.soldiers){const lane=p.index%2,index=counts[p.id][lane]++;p.x=p.id==='arch'?534+index%5*29:700+index%4*29;p.y=Core.WORLD[lane?'lower':'upper']+(p.id==='arch'?35+Math.floor(index/5)*25:15+Math.floor(index/4)*25);}
 const before=battle.soldiers.map(p=>[p.x,p.y]);
 for(let i=0;i<Core.plan(9).duration*30&&state.phase==='active';i++){
  Core.tick(state,1/30,{gateBuilt:true});battle.enemies=state.phase==='active'?state.enemies:[];
  for(const e of battle.step(1/30,{x:0,y:0,hp:1,max:1}))if(e.kind==='damage')Core.hit(state,e.targetKey,e.amount,e.p.id);
 }
 assert.deepEqual(battle.soldiers.map(p=>[p.x,p.y]),before);
 return state.result;
}
test('the beacon range shown in company stats changes actual delayed individual target reach',()=>{
 const normal=Core.stats('arch',{beacon:false}),lit=Core.stats('arch',{beacon:true});
 assert.equal(normal.range,90);assert.equal(lit.range,110);assert.equal(lit.damage,normal.damage);assert.equal(lit.interval,normal.interval);
 const battle=new Battle();battle.enemies=[];battle.sync([{id:'arch',count:1,ranged:true,...lit}]);const archer=battle.soldiers[0];
 assert.equal(battle.range(archer),110);
 battle.enemies=[{key:1,alive:true,hp:10,x:archer.x+140,y:archer.y,r:13}];battle.outpostState={phase:'active',round:1,enemies:battle.enemies};
 assert.equal(battle.target(archer),null);battle.enemies[0].x=archer.x+130;assert.equal(battle.target(archer)?.key,1);
});
test('a late beacon is a useful alternative to more recruits, while an undersized crew still fails',()=>{
 const baseline=finalDefence(20,6,false),lit=finalDefence(20,6,true),undersized=finalDefence(18,8,true);
 assert.equal(baseline.win,false);assert.equal(lit.win,true);assert.equal(lit.chiefDefeated,true);assert.equal(lit.escaped,0);assert.equal(undersized.win,false);
});
