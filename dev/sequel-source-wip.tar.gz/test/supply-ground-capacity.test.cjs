const test=require('node:test');
const assert=require('node:assert/strict');
const Core=require('../2/supply-core.js');

test('overlapping loose resources remain individual, capped, and reusable after delivery',()=>{
 const s=Core.fresh();Core.individualize(s);
 for(let i=0;i<12;i++)assert.ok(Core.drop(s,'wood',1,200,300,1,12));
 assert.equal(s.drops.length,12);assert.equal(new Set(s.drops.map(d=>d.key)).size,12);
 assert.ok(s.drops.every(d=>d.x===200&&d.y===300&&d.count===1));
 const next=s.next;assert.equal(Core.drop(s,'stone',1,200,300,2,12),null);
 assert.equal(s.next,next);assert.deepEqual(s.inventory,{wood:0,stone:0});
 Core.deliver(s,s.drops[0]);assert.equal(s.inventory.wood,1);
 assert.ok(Core.drop(s,'stone',1,200,300,2,12));
});

test('storage upgrades increase the ground limit without deleting old over-cap saves',()=>{
 const s=Core.fresh();Core.individualize(s);s.compactDrops=true;
 for(let i=0;i<24;i++)assert.ok(Core.drop(s,'wood',1,200,300,1,24));
 const loaded=Core.migrate(JSON.parse(JSON.stringify(s)));
 assert.equal(loaded.compactDrops,true);assert.equal(loaded.drops.length,24);
 assert.equal(Core.drop(loaded,'wood',1,200,300,1,12),null);
 assert.ok(Core.drop(loaded,'wood',1,200,300,1,48));
});

test('legacy reserve respects current capacity and is released only when space is available',()=>{
 const s=Core.fresh();Core.individualize(s);s.legacyLoose=[{type:'stone',count:30,x:200,y:300,source:2}];
 assert.equal(Core.unpackLegacy(s,20,12),12);assert.equal(s.legacyLoose[0].count,18);
 assert.equal(Core.unpackLegacy(s,20,12),0);
 Core.deliver(s,s.drops[0]);assert.equal(Core.unpackLegacy(s,20,12),1);
 assert.equal(s.drops.length,12);assert.equal(s.legacyLoose[0].count,17);
});

test('compact migration preserves authored worker outputs, belts, platforms, and saved carry flags',()=>{
 const conveyor=require('../2/conveyor-core.js');
 const s=Core.fresh();Core.individualize(s);s.nodes=[{key:1,type:'wood',x:200,y:200,stock:180}];
 const add=(x,y,extra={})=>Object.assign(Core.drop(s,'wood',1,x,y,1),extra);
 const manual=add(430,430),worker=add(250,280,{worker:true}),belt=add(300,350),platform=add(450,350),flag=add(600,350,{onConveyor:true}),id=add(650,350,{beltId:7});
 const camp={links:[{kind:'conveyor',nodeKey:2,points:[{x:280,y:350},{x:330,y:350}]}],platforms:[{key:3,x:450,y:350,w:96,h:64,dir:0}]};
 const before=[worker,belt,platform,flag,id].map(d=>({x:d.x,y:d.y}));
 assert.equal(Core.compactManualDrops(s,camp,conveyor),true);
 assert.deepEqual({x:manual.x,y:manual.y},{x:272,y:228});
 assert.deepEqual([worker,belt,platform,flag,id].map(d=>({x:d.x,y:d.y})),before);
 manual.x=410;assert.equal(Core.compactManualDrops(s,camp,conveyor),false);assert.equal(manual.x,410);
 const loaded=Core.migrate(JSON.parse(JSON.stringify(s)));assert.equal(loaded.drops.find(d=>d.key===flag.key).onConveyor,true);
});
