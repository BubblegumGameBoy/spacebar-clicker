const test=require('node:test'),assert=require('node:assert/strict'),C=require('../2/outpost-core.js');
test('first incoming raid has an actual 150-second preparation clock independent of army',()=>{
 const s=C.fresh();assert.equal(s.prepRemaining,150);assert.equal(C.preparationTick(s,149.9),false);assert.ok(s.prepRemaining>.09&&s.prepRemaining<.11);assert.equal(C.preparationTick(s,.1),true);assert.equal(C.start(s),true);assert.equal(s.phase,'active');assert.equal(s.wave,1);
});
test('saved preparation resumes exactly and malformed clocks cannot create infinite preparation',()=>{
 const s=C.fresh();C.preparationTick(s,63);const restored=C.migrate(JSON.parse(JSON.stringify(s)));assert.equal(restored.prepRemaining,87);assert.equal(restored.prepScheduledRound,0);assert.equal(C.preparationTick(restored,86),false);assert.equal(C.preparationTick(restored,1),true);
 const bad=C.migrate({...s,prepRemaining:Infinity,prepScheduledRound:999999});assert.equal(C.preparationTick(bad,1),false);assert.equal(bad.prepRemaining,149);
});
test('victory schedules the next incoming raid; defeat schedules the same raid, without losing progress',()=>{
 for(const win of [true,false]){const s=C.fresh();s.round=1;s.phase='result';s.wave=1;s.result={wave:1,win,boxes:win?3:0,gold:win?38:8};s.prepRemaining=0;s.prepScheduledRound=0;s.cleared=win?1:0;assert.equal(C.preparationTick(s,89),false);assert.equal(s.prepRemaining,1);assert.equal(C.preparationTick(s,1),true);C.start(s);assert.equal(s.wave,win?2:1);assert.equal(s.cleared,win?1:0);}
});
test('later chapters allow 120 seconds to build, and active/final completed states never tick preparation',()=>{
 const s=C.fresh();s.phase='result';s.wave=3;s.round=3;s.result={wave:3,win:true};assert.equal(C.preparationTick(s,30),false);assert.equal(s.prepRemaining,90);C.start(s);const before=s.prepRemaining;assert.equal(C.preparationTick(s,100),false);assert.equal(s.prepRemaining,before);
 s.phase='result';s.completed=true;s.wave=9;s.prepRemaining=0;assert.equal(C.preparationTick(s,10000),false);
});
test('old manual-wave saves receive a finite countdown without free wins or rewards',()=>{
 const raw={...C.fresh(),phase:'result',wave:3,cleared:3,round:3,result:{wave:3,win:true,boxes:2,kills:4,escaped:2,first:true}};delete raw.prepRemaining;delete raw.prepScheduledRound;const s=C.migrate(raw),paid=s.result.gold;C.preparationTick(s,1);assert.equal(s.prepRemaining,119);assert.equal(s.cleared,3);assert.equal(s.result.gold,paid);
});
