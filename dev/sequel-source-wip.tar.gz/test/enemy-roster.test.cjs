// M6: enemy definition table, new kinds' rules, plan versions and save migration.
const test=require('node:test');
const assert=require('node:assert/strict');
const C=require('../2/outpost-core.js');
const clone=v=>JSON.parse(JSON.stringify(v));
const near=(a,b,e=1e-7)=>assert.ok(Math.abs(a-b)<e,`${a} != ${b}`);
const road=lane=>C.WORLD.entryX-C.WORLD.turnX+Math.hypot(C.WORLD.turnX-C.WORLD.home.x,C.WORLD[lane]-C.WORLD.home.y);
// A running round with only the given groups (test waves use the same modifiers M5/M11 will use).
function custom(mix,duration=90){const s=C.fresh();s.wave=5;assert.equal(C.start(s,{modifiers:{mix,replace:true,duration}}),true);C.tick(s,0);return s;}
const one=(kind,lane='upper',extra={})=>({kind,lane,count:1,at:0,gap:0,...extra});

test('the definition table drives plan(): every kind has stats, three-language name/note and an art sheet',()=>{
 for(const kind of C.KINDS){const d=C.ENEMIES[kind];
  for(const key of ['hp','speed','r','height'])assert.ok(d[key]>0,kind+' '+key);assert.ok(d.armor>=0);
  assert.equal(d.name.length,3);assert.equal(d.note.length,3);assert.ok(d.name.every(Boolean)&&d.note.every(Boolean));assert.match(d.art.sheet,/^mob-[a-z]+$/);
  const p=C.plan(5,3,{mix:[one(kind)],replace:true});assert.equal(p.spawns.length,1);const s=p.spawns[0];
  if(kind!=='rat')assert.deepEqual([s.hp,s.speed,s.armor,s.r],[d.hp,d.speed,d.armor,d.r]);
 }
 assert.deepEqual(C.KINDS.slice(0,4),['rat','scout','guard','chief']);
 for(const kind of ['shield','bat','ooze','oozelet','mole','shaman','beetle','swarm','wisp','siegecart','slinger','toad','boar','envoy']){assert.ok(C.KINDS.includes(kind));assert.ok(C.ENEMIES[kind].art.uniform);assert.ok(C.ENEMIES[kind].art.fallback?.sheet==='mob-rat','production sheet keeps a provisional fallback');}
 assert.ok(Object.isFrozen(C.ENEMIES)&&C.KINDS.every(k=>Object.isFrozen(C.ENEMIES[k])));
});

test('plan modifiers add or replace groups, are sanitised and round-trip through the save',()=>{
 const base=C.plan(5),extra=C.plan(5,3,{mix:[{kind:'ooze',lane:'both',count:4,at:2,gap:3}]});
 assert.equal(extra.spawns.length,base.spawns.length+4);assert.deepEqual(extra.spawns.filter(e=>e.kind==='ooze').map(e=>[e.lane,e.at]),[['upper',2],['lower',2],['upper',5],['lower',5]]);
 assert.equal(extra.potential,extra.spawns.length+4*2,'potential counts the oozelets');assert.deepEqual(extra.special,['shield','ooze']);
 const only=C.plan(5,3,{mix:[{kind:'nope',count:3},{kind:'bat',lane:'sideways',count:999,at:-5,gap:1}],replace:true,duration:9999});
 assert.equal(only.duration,180);assert.equal(only.spawns.length,60);assert.ok(only.spawns.every(e=>e.kind==='bat'&&e.at>=0));assert.equal(only.pattern,'custom');
 assert.equal(C.modifiers({mix:[]}),null);
 const s=custom([one('shield')]);const back=C.migrate(clone(s));assert.deepEqual(back.modifiers,s.modifiers);assert.equal(back.enemies[0].kind,'shield');
 // Modifiers belong to one round: a start without them clears them (M11 passes them per wave).
 C.tick(s,200);assert.ok(s.modifiers,'kept for the result view');C.start(s);assert.equal(s.modifiers,undefined);C.tick(s,0);assert.ok(s.enemies.some(e=>e.kind==='guard'),'the authored wave again');
});

test('plan 3 swaps two wave-5 guards for shields and two wave-7 runners for bats; plan 2 and 1 are unchanged',()=>{
 const kinds=(w,v)=>C.plan(w,v).spawns.map(e=>e.kind);
 assert.deepEqual(kinds(5,2).slice(0,4),['guard','guard','guard','guard']);assert.deepEqual(kinds(5,3).slice(0,4),['guard','guard','shield','shield']);
 assert.equal(C.plan(5,2).spawns.length,C.plan(5,3).spawns.length);assert.equal(C.plan(7,2).spawns.length,C.plan(7,3).spawns.length);
 assert.equal(kinds(7,2).filter(k=>k==='bat').length,0);assert.deepEqual(C.plan(7,3).spawns.filter(e=>e.kind==='bat').map(e=>e.lane).sort(),['lower','upper']);
 assert.equal(kinds(7,3).filter(k=>k==='scout').length,kinds(7,2).filter(k=>k==='scout').length-2);
 for(const w of [1,2,3,4,6,8,9])assert.deepEqual(C.plan(w,3).spawns,C.plan(w,2).spawns,'wave '+w);
 assert.equal(C.fresh().planVersion,C.PLAN_VERSION);assert.equal(C.PLAN_VERSION,3);
});

test('old saves: an active plan-2 wave 5 keeps its four guards, missing version reads as plan 1, and the next start uses plan 3',()=>{
 const s={...C.fresh(),planVersion:2,wave:5,phase:'active',round:5};C.tick(s,4);assert.ok(s.enemies.length>=4);
 const raw=clone(s);for(const e of raw.enemies){delete e.shield;}
 const restored=C.migrate(raw);assert.equal(restored.planVersion,2);assert.deepEqual(restored.enemies.map(e=>e.kind),s.enemies.map(e=>e.kind));assert.ok(restored.enemies.slice(0,4).every(e=>e.kind==='guard'));
 assert.equal(restored.escaped,0);assert.equal(restored.boxes,3);for(const [a,b] of restored.enemies.map((e,i)=>[e,s.enemies[i]])){near(a.travel,b.travel);near(a.hp,b.hp);}
 C.tick(restored,100);assert.equal(restored.phase,'result');C.start(restored);assert.equal(restored.planVersion,3);C.tick(restored,2);assert.deepEqual(restored.enemies.map(e=>e.kind).slice(0,4),['guard','guard','shield','shield']);
 const legacy=clone({...C.fresh(),wave:7,phase:'active',round:7});delete legacy.planVersion;assert.equal(C.migrate(legacy).planVersion,1);
 // The four original kinds read back exactly as stored.
 for(const kind of ['rat','scout','guard']){const v2={...C.fresh(),planVersion:2,wave:kind==='guard'?4:kind==='scout'?4:1,phase:'active',round:1};C.tick(v2,6);const back=C.migrate(clone(v2));assert.deepEqual(back.enemies.map(e=>[e.key,e.kind,e.hp,e.maxHp,e.armor]),v2.enemies.map(e=>[e.key,e.kind,e.hp,e.maxHp,e.armor]));}
 const final={...C.fresh(),planVersion:2,wave:9,phase:'active',round:9};C.tick(final,15);const chief=final.enemies.find(e=>e.kind==='chief');assert.ok(chief);const back=C.migrate(clone(final));assert.deepEqual(back.enemies.find(e=>e.kind==='chief').maxHp,240);
 // Unknown kinds in a tampered save are dropped, not crashed on.
 const bad=clone(final);bad.enemies[0].kind='dragon';assert.equal(C.migrate(bad).enemies.some(e=>e.kind==='dragon'),false);
});

test('shield: the shield takes the first three arrows; one sword or ballista blow breaks it',()=>{
 const s=custom([one('shield'),one('shield','lower')]),[a,b]=s.enemies;assert.equal(a.shield,3);
 for(let i=0;i<3;i++){const r=C.hit(s,a.key,5,'arch');assert.equal(r.applied,0);assert.equal(r.blocked,true);}
 assert.equal(a.shield,0);assert.equal(C.hit(s,a.key,5,'arch').applied,4,'armour 1 after the shield is gone');
 const r=C.hit(s,b.key,3,'sword');assert.equal(b.shield,0);assert.equal(r.applied,3);assert.equal(C.hit(s,b.key,5,'manual').applied,4);
 assert.equal(C.target(s,{x:b.x,y:b.y+30},100,{priority:'armor'}).kind,'shield','shields count as armour for the armour-first policy');
});

test('bat: flies straight to the camp; swords and ballistas can neither target nor hurt it',()=>{
 const s=custom([one('bat')]),bat=s.enemies[0],flight=Math.hypot(C.WORLD.entryX-C.WORLD.home.x,C.WORLD.upper-C.WORLD.home.y);
 assert.ok(flight<road('upper'));C.tick(s,10);near(bat.travel,320);const t=320/flight;near(bat.x,C.WORLD.entryX+(C.WORLD.home.x-C.WORLD.entryX)*t);near(bat.y,C.WORLD.upper+(C.WORLD.home.y-C.WORLD.upper)*t);
 const at={x:bat.x,y:bat.y+20};assert.equal(C.target(s,at,50,{role:'sword'}),null);assert.equal(C.target(s,at,200,{role:'ballista'}),null);assert.equal(C.target(s,at,50,{role:'arch'}),bat);
 assert.equal(C.hit(s,bat.key,20,'ballista').applied,0);assert.equal(C.hit(s,bat.key,3,'sword').applied,0);assert.equal(C.hit(s,bat.key,5,'arch').applied,5);
 C.tick(s,(flight-320)/32+1.5);assert.equal(s.escaped,1,'reaches the camp along the shorter flight line');
});

test('ooze: a kill releases two oozelets; the round ends only after they are dead; the save keeps them',()=>{
 const s=custom([one('ooze'),one('rat','lower',{at:30})]),ooze=s.enemies[0];C.tick(s,5);
 const r=C.hit(s,ooze.key,100,'ballista');assert.equal(r.killed,true);assert.equal(r.spawned.length,2);
 const kids=s.enemies.filter(e=>e.parent===ooze.key);assert.equal(kids.length,2);assert.ok(kids.every(k=>k.kind==='oozelet'&&k.hp===8&&k.alive&&Math.abs(k.travel-ooze.travel)<20));
 const saved=C.migrate(clone(s));assert.deepEqual(saved.enemies.filter(e=>e.parent).map(e=>[e.key,e.kind,e.hp,e.parent]),kids.map(e=>[e.key,e.kind,e.hp,e.parent]));
 const forged=clone(s);forged.enemies.push({...clone(kids[0]),key:999});forged.enemies.push({...clone(kids[0]),key:998,kind:'rat'});assert.equal(C.migrate(forged).enemies.filter(e=>e.parent).length,2,'no more pieces than the split count, only its kind');
 const alive=clone(s);alive.enemies[0].alive=true;alive.enemies[0].hp=5;assert.equal(C.migrate(alive).enemies.filter(e=>e.parent).length,0,'a living parent has no pieces');
 C.tick(s,30);for(const e of s.enemies)if(e.alive)C.hit(s,e.key,100,'arch');const events=C.tick(s,1);assert.equal(events[0]?.type,'settle');assert.equal(s.result.kills,4);assert.equal(s.result.win,true);
 assert.equal(s.result.trial,true);assert.equal(s.result.gold,0);assert.equal(s.cleared,0,'a test wave is not wave 5');assert.deepEqual(s.claimedFirst,[]);assert.equal(C.migrate(clone(s)).result.trial,true);
});

test('mole: underground for the middle 40% of the road, surfacing before the bend',()=>{
 const s=custom([one('mole')]),mole=s.enemies[0],L=road('upper');assert.equal(C.burrowed(mole),false);
 C.tick(s,(L*.5)/24);assert.equal(C.burrowed(mole),true);assert.equal(C.target(s,mole,100,{role:'arch'}),null);assert.equal(C.hit(s,mole.key,20,'ballista').applied,0);
 C.tick(s,(L*.25)/24);assert.equal(C.burrowed(mole),false);assert.ok(mole.x>C.WORLD.turnX,'surfaced before the bend');assert.equal(C.target(s,mole,100,{role:'arch'}),mole);assert.equal(C.hit(s,mole.key,5,'arch').applied,4);
});

test('shaman: heals other raiders within 50 by 4 every 2 s; the healer policy picks it first',()=>{
 const s=custom([one('shaman'),one('guard',undefined,{at:0}),one('rat','lower')]);const [shaman,guard,rat]=['shaman','guard','rat'].map(k=>s.enemies.find(e=>e.kind===k));
 C.hit(s,guard.key,20,'sword');C.hit(s,rat.key,10,'sword');C.hit(s,shaman.key,10,'sword');const g=guard.hp,r=rat.hp,h=shaman.hp;
 C.tick(s,2.01);near(guard.hp,Math.min(guard.maxHp,g+4));near(rat.hp,r,1e-9);near(shaman.hp,h);
 C.tick(s,2);near(guard.hp,Math.min(guard.maxHp,g+8));
 const point={x:shaman.x,y:shaman.y+40};assert.equal(C.target(s,point,120,{priority:'healer'}),shaman);assert.notEqual(C.target(s,point,120,{priority:'front'}),shaman);
 const saved=C.migrate(clone(s));near(saved.enemies.find(e=>e.kind==='shaman').healAt,shaman.healAt);
});

test('beetle: its shell deflects arrows from the front; from behind and for piercing blows it is ordinary',()=>{
 const s=custom([one('beetle')]),b=s.enemies[0];C.tick(s,20);
 assert.equal(C.hit(s,b.key,5,'arch',{x:b.x-60,y:b.y+30}).applied,1,'front: armour 2 + shell 2');
 assert.equal(C.hit(s,b.key,5,'arch',{x:b.x+60,y:b.y+30}).applied,3,'behind: armour 2');
 assert.equal(C.hit(s,b.key,5,'arch').applied,1,'unknown source counts as front');
 assert.equal(C.hit(s,b.key,3,'sword',{x:b.x-20,y:b.y}).applied,3);assert.equal(C.hit(s,b.key,20,'ballista',{x:b.x-100,y:b.y}).applied,20);
});

test('swarm: ten mice, each blow fells at most one',()=>{
 const s=custom([one('swarm')]),m=s.enemies[0];assert.equal(m.hp,50);
 assert.equal(C.hit(s,m.key,20,'ballista').applied,5);assert.equal(C.hit(s,m.key,3,'sword').applied,3);assert.equal(C.hit(s,m.key,5,'arch').applied,2,'finishes the wounded mouse only');
 for(let i=0;i<8;i++)assert.equal(C.hit(s,m.key,5,'arch').applied,5);assert.equal(m.alive,false);
});

test('wisp: untargetable until an ally body is close; reveal follows real positions',()=>{
 const s=custom([one('wisp')]),w=s.enemies[0];C.tick(s,5);
 C.reveal(s,[{x:w.x,y:w.y+90,r:10}]);assert.equal(w.seen,false);assert.equal(C.target(s,{x:w.x,y:w.y+90},120,{role:'arch'}),null);
 C.reveal(s,[{x:w.x+5,y:w.y+30,r:10}]);assert.equal(w.seen,true);assert.equal(C.target(s,{x:w.x,y:w.y+90},120,{role:'arch'}),w);
 assert.equal(C.migrate(clone(s)).enemies[0].seen,undefined,'visibility is recomputed, not saved');
});

test('siege cart: armour 3, and three 14-HP rats burst out when it breaks',()=>{
 const s=custom([one('siegecart')]),c=s.enemies[0];C.tick(s,10);assert.equal(C.hit(s,c.key,5,'arch').applied,2);
 const r=C.hit(s,c.key,200,'ballista');assert.equal(r.spawned.length,3);assert.ok(r.spawned.every(e=>e.kind==='rat'&&e.hp===14&&e.parent===c.key));
});

test('slinger: stops mid-road and costs one crate after 8 s of throwing, regardless of the gate',()=>{
 const s=custom([one('slinger')]),sl=s.enemies[0];C.tick(s,230/26+.01,{gateBuilt:true});assert.equal(sl.atGate,true);near(sl.travel,230);assert.ok(sl.x>600,'the station is far from the camp');
 C.tick(s,7.5,{gateBuilt:true});assert.equal(s.boxes,3);C.tick(s,1,{gateBuilt:true});assert.equal(s.boxes,2);assert.equal(sl.alive,false);
});

test('bosses: the toad leaps, the boar ignores sword slows, the envoy flies; none counts as the wave-9 chief',()=>{
 const s=custom([one('toad'),one('boar','lower'),one('envoy',undefined,{at:1})],180),[toad,boar]=s.enemies;
 C.tick(s,6.01);near(toad.travel,6.01*15+70,1e-6);C.hit(s,boar.key,3,'sword');const before=boar.travel;C.tick(s,1);near(boar.travel-before,20,1e-6);
 const envoy=s.enemies.find(e=>e.kind==='envoy');assert.equal(C.target(s,{x:envoy.x,y:envoy.y},40,{role:'sword'}),null);
 const nine=C.fresh();nine.wave=9;nine.cleared=8;nine.claimedFirst=[1,2,3,4,5,6,7,8];C.start(nine,{modifiers:{mix:[one('toad')],replace:true,duration:60}});C.tick(nine,0);C.hit(nine,nine.enemies[0].key,999,'ballista');C.tick(nine,1);
 assert.equal(nine.result.win,false,'no chief, no wave-9 victory');assert.equal(nine.result.trial,true);assert.equal(nine.completed,false);assert.equal(nine.cleared,8);
});

test('every kind can run a whole round in plan(), resolve, settle and migrate without errors',()=>{
 for(const kind of C.KINDS){const s=custom([{kind,lane:'both',count:4,at:0,gap:2}],120);let guard=0;while(s.phase==='active'&&guard++<2000){for(const e of s.enemies)if(e.alive&&C.exposed(e)&&e.travel>100)C.hit(s,e.key,7,'arch',{x:e.x-50,y:e.y});C.tick(s,.25);C.migrate(clone(s));}
  assert.equal(s.phase,'result',kind);assert.ok(s.result.kills+s.result.escaped>=4,kind);assert.equal(C.migrate(clone(s)).result.kills,s.result.kills,kind);}
});

test('the healer target policy is stored with the squad',()=>{
 const E=require('../2/expedition-core.js'),S={outpost:{phase:'prep'},expedition:{version:1,initialized:true,groups:[{key:1,id:'ballista',count:3,active:true,policy:'healer',anchor:{x:700,y:300},positions:[]}],nextKey:2}};
 S.expedition=E.migrate(S.expedition);assert.equal(S.expedition.groups[0].policy,'healer');assert.equal(E.setPolicy(S,1,'armor'),true);assert.equal(E.setPolicy(S,1,'healer'),true);assert.equal(E.setPolicy(S,1,'bogus'),false);assert.equal(S.expedition.groups[0].policy,'healer');
});

test('seen enemy kinds survive the save, other values are dropped',()=>{
 const Core=require('../2/game-core.js'),s=Core.migrate({enemySeen:['shield','bat','shield',3,'<x>','BAT']},['arch']);assert.deepEqual(s.enemySeen,['shield','bat']);assert.deepEqual(Core.migrate({},['arch']).enemySeen,[]);
});

test('review: the player cannot click an unseen wisp or a burrowed mole; pieces never inflate expedition records',()=>{
 const s=custom([one('wisp')]),w=s.enemies[0];C.tick(s,2);assert.equal(C.hit(s,w.key,5,'manual').applied,0);assert.equal(C.target(s,C.WORLD.home,2000,{role:'manual'}),null);
 C.reveal(s,[{x:w.x,y:w.y,r:10}]);assert.equal(C.hit(s,w.key,5,'manual').applied,5);
 const E=require('../2/expedition-core.js'),S={outpost:custom([one('ooze')]),expedition:null};E.ensure(S);const o=S.outpost;C.hit(o,o.enemies[0].key,99,'ballista');for(const e of o.enemies)if(e.alive)C.hit(o,e.key,99,'arch');C.tick(o,1);
 assert.equal(o.result.kills,3);assert.equal(E.record(S,o.result),false,'test waves are not recorded');assert.equal(S.expedition.records.length,0);
 const real={outpost:{...C.fresh(),wave:5,round:5,phase:'result'},expedition:null};E.ensure(real);assert.equal(E.record(real,{wave:5,win:true,kills:99,escaped:0}),true);assert.equal(real.expedition.records[0].bestKills,C.plan(5).potential,'kills are capped at the plan potential');assert.equal(C.plan(5).potential,C.plan(5).spawns.length);
});

test('review: a shaman never revives fallen mice of a swarm; hit outcomes report shield, shell and pack separately',()=>{
 const s=custom([one('swarm'),one('shaman',undefined,{at:0})]),[m]=s.enemies.filter(e=>e.kind==='swarm');C.hit(s,m.key,5,'arch');C.hit(s,m.key,5,'arch');C.hit(s,m.key,2,'arch');assert.equal(m.hp,38);
 C.tick(s,6.1);assert.equal(m.hp,40,'only the wounded mouse heals');
 assert.equal(C.hit(s,m.key,20,'ballista').packCapped,15);
 const b=custom([one('beetle'),one('shield','lower')]);C.tick(b,10);const [beetle,shield]=b.enemies;const r=C.hit(b,beetle.key,5,'arch',{x:beetle.x-50,y:beetle.y});assert.deepEqual([r.applied,r.shellBlocked],[1,2]);assert.equal(C.hit(b,shield.key,5,'manual').shieldBlocked,5);
 const M=require('../tools/combat_metrics.cjs'),ledger=M.createLedger([{id:'arch',index:0,groupKey:1}]),before={...shield,alive:true};ledger.hit({role:'arch',index:0,amount:5,before,outcome:{applied:0,killed:false,blocked:true,shieldBlocked:5},time:1});
 const row=Object.values(ledger.summary().groups)[0];assert.deepEqual([row.shieldBlocked,row.overkill,row.armorBlocked],[5,0,0]);
});
