const test=require('node:test'),assert=require('node:assert/strict'),C=require('../2/outpost-core.js'),E=require('../2/expedition-core.js');
const clone=v=>JSON.parse(JSON.stringify(v));
const planAt=(wave,conditions,seed=0)=>C.plan(wave,C.PLAN_VERSION,C.heatModifiers(wave,{conditions,seed}));
const count=(p,kind,lane)=>p.spawns.filter(e=>e.kind===kind&&(!lane||e.lane===lane)).length;
function save(){return {owned:Object.fromEntries(E.IDS.map(id=>[id,0])),pending:{},pendingRefunds:{},factory:{inventory:{wood:5000,stone:5000,food:500}},camp:{links:[],platforms:[]},tutorial:{version:1,started:true},battle:{width:960,height:540,units:[]},outpost:C.fresh(),gold:0};}
function hire(s,id,p){const g=E.recruit(s,id);assert.ok(g,id);const index=s.owned[id]-s.pending[id];s.pending[id]--;s.battle.units.push([id,index,p.x,p.y,-1,-1]);assert.equal(E.setAnchor(s,id,index,p),true);E.project(s);return g;}
// Settle a real round of `wave` at the save's current threat, killing `kills` (or everything) through the core rules.
function play(s,wave,{win=true}={}){const o=s.outpost;o.phase='prep';o.result=null;o.wave=wave;o.cleared=wave-1;assert.equal(C.start(o),true);let guard=0;
 while(o.phase==='active'&&guard++<4000){C.tick(o,.25,{gateBuilt:true});if(win)for(const e of o.enemies)if(e.alive&&C.exposed(e))C.hit(o,e.key,999,C.has(e,'fly')?'arch':'ballista',{x:e.x-50,y:e.y});}
 if(!win&&o.phase==='active')C.tick(o,999);assert.equal(o.phase,'result');assert.equal(E.record(s,o.result),true);return o.result;}
function completed(){const s=save();E.ensure(s);for(let w=1;w<=9;w++)play(s,w);return s;}

test('threat: level is the sum of known condition points; unknown or forged values are ignored',()=>{
 assert.deepEqual(C.heat(null),{level:0,conditions:[],seed:0});
 const h=C.heat({level:99,conditions:['thin','horde','thin','bogus',7],seed:-3});assert.deepEqual(h,{level:3,conditions:['horde','thin'],seed:0});
 assert.equal(C.heat({conditions:C.HEAT_IDS}).level,Object.values(C.HEAT).reduce((n,c)=>n+c.points,0));
 for(const id of C.HEAT_IDS){const c=C.HEAT[id];assert.ok(c.points>=1&&c.points<=2,id);for(const k of ['name','note','decide'])assert.equal(c[k].length,3,id+'.'+k);}
 assert.equal(C.heatModifiers(5,{conditions:[]}),null,'threat 0 changes nothing');
 assert.deepEqual(planAt(9,[]),C.plan(9));
});

test('plan modifiers: each condition changes who, where or how many — never only HP',()=>{
 const base4=C.plan(4),base9=C.plan(9);
 const T=C.HEAT_TUNE,horde=planAt(9,['horde']);assert.equal(count(horde,'rat'),count(base9,'rat')+Math.floor(count(base9,'rat')/T.hordeEvery[2]));assert.equal(count(horde,'scout'),count(base9,'scout')+Math.floor(count(base9,'scout')/T.hordeEvery[2]));assert.equal(count(planAt(4,['horde']),'scout'),12,'wave 4 has no plain rats: its runners grow ×1.5');assert.equal(count(planAt(3,['horde']),'rat'),9);assert.ok(horde.spawns.filter(e=>e.kind==='rat').every(e=>e.hp===26&&e.armor===0));
 const iron=planAt(4,['ironhide']);assert.ok(iron.spawns.filter(e=>e.kind==='guard').every(e=>e.armor===4));assert.equal(iron.spawns.length,base4.spawns.length);
 assert.ok(planAt(9,['ironhide']).spawns.filter(e=>e.kind==='rat').every(e=>e.armor===1));
 for(const seed of [0,1]){const f=planAt(4,['flank'],seed),lane=f.flank;assert.ok(['upper','lower'].includes(lane));assert.ok(f.spawns.filter(e=>e.kind==='scout').every(e=>e.lane===lane));assert.equal(count(f,'scout'),count(base4,'scout')+3);}
 assert.notEqual(planAt(4,['flank'],0).flank,planAt(4,['flank'],1).flank,'the flank road changes between runs');
 assert.notEqual(planAt(4,['flank'],0).flank,planAt(5,['flank'],0).flank,'and between waves');
 assert.equal(count(planAt(4,['wings']),'bat'),4);assert.equal(count(planAt(9,['wings']),'bat'),6);
 assert.equal(count(planAt(2,['shieldwall']),'shield'),2);assert.ok(planAt(4,['shieldwall']).spawns.filter(e=>e.kind==='shield').every(e=>e.at<=3));
 // Burrow: added moles where the wave has no rats (wave 4), rats of the column turned into moles otherwise (same head count).
 const b4=planAt(4,['burrow']),b9=planAt(9,['burrow']);assert.equal(count(b4,'mole'),T.moles[1]);assert.equal(b4.spawns.length,base4.spawns.length+T.moles[1]);assert.equal(count(b9,'mole'),T.moles[2]);assert.equal(b9.spawns.length,base9.spawns.length);assert.equal(count(b9,'rat'),count(base9,'rat')-T.moles[2]);assert.ok(b9.spawns.filter(e=>e.kind==='mole').every(e=>e.hp===34&&e.armor===1));
 assert.deepEqual(C.modifiers({swap:[{from:'rat',to:'chief',count:2},{from:'rat',to:'mole',count:999}]}).swap,[{from:'rat',to:'mole',count:60}],'no boss swaps, counts bounded');assert.equal(count(planAt(9,['procession']),'shaman'),4);
 const siege3=planAt(3,['siege']),siege4=planAt(4,['siege']);assert.equal(count(siege3,'siegecart'),0);assert.equal(count(siege3,'slinger'),2);assert.equal(count(siege4,'siegecart'),2);assert.equal(siege4.duration,80,'carts need the time to arrive');
 assert.equal(planAt(4,['thin']).boxes,2);assert.equal(base4.boxes,3);
 // Bosses: threat 3+ replaces the wave-9 captain, changing with the run seed; below 3 or before wave 9 nothing changes.
 assert.equal(planAt(9,['ironhide','rush']).boss,'chief');
 assert.deepEqual([0,1,2,3].map(seed=>planAt(9,['thin','horde'],seed).boss),['toad','boar','envoy','toad']);
 assert.equal(count(planAt(9,['thin','horde'],1),'chief'),0);assert.equal(planAt(8,['thin','horde'],1).boss,null);
 // Extra round modifiers (loops, test waves) merge with the threat; a replaced test wave ignores it.
 const s=C.fresh();s.heat=C.heat({conditions:['wings']});const merged=C.roundModifiers(s,4,{mix:[{kind:'ooze',lane:'upper',count:1}]});assert.deepEqual(merged.mix.map(m=>m.kind),['bat','ooze']);
 assert.deepEqual(C.roundModifiers(s,4,{mix:[{kind:'ooze',lane:'upper',count:1}],replace:true}).mix.map(m=>m.kind),['ooze']);
});

test('start applies the run threat, the round survives a save mid-raid, and thin stores starts with 2 crates',()=>{
 const s=C.fresh();s.heat=C.heat({conditions:['thin','ironhide','wings'],seed:4});s.wave=4;s.cleared=3;assert.equal(C.start(s),true);
 assert.equal(s.boxes,2);assert.equal(s.modifiers.boxes,2);assert.equal(s.modifiers.heat,4);C.tick(s,9);
 assert.ok(s.enemies.some(e=>e.kind==='bat'));assert.ok(s.enemies.filter(e=>e.kind==='guard').every(e=>e.armor===4));
 const back=C.migrate(clone(s));assert.deepEqual(back.heat,s.heat);assert.deepEqual(back.modifiers,s.modifiers);assert.equal(back.boxes,2);assert.deepEqual(back.enemies.map(e=>[e.kind,e.armor,e.key]),s.enemies.map(e=>[e.kind,e.armor,e.key]));
 // Crates never grow back past the thin limit through a save.
 const forged=clone(s);forged.boxes=3;assert.equal(C.migrate(forged).boxes,2);
 C.tick(s,999);assert.equal(s.phase,'result');assert.ok(s.result.boxes<=2);
 // Old saves (no heat) read as threat 0.
 const old=clone(C.fresh());delete old.heat;assert.deepEqual(C.migrate(old).heat,{level:0,conditions:[],seed:0});
});

test('rush cuts every preparation by 30 seconds; a replaced boss must be the one defeated',()=>{
 const s=C.fresh();assert.equal(C.preparationSeconds(s),150);s.heat=C.heat({conditions:['rush']});assert.equal(C.preparationSeconds(s),120);s.round=3;s.wave=5;assert.equal(C.preparationSeconds(s),90);s.wave=2;assert.equal(C.preparationSeconds(s),60);
 const n=C.fresh();n.heat=C.heat({conditions:['narrow','horde'],seed:2});n.wave=9;n.cleared=8;n.claimedFirst=[1,2,3,4,5,6,7,8];C.start(n);let guard=0;
 while(n.phase==='active'&&guard++<4000){C.tick(n,.25,{gateBuilt:true});for(const e of n.enemies)if(e.alive&&C.exposed(e)&&e.kind!=='envoy')C.hit(n,e.key,999,'arch');}
 assert.equal(n.result.win,false,'the envoy (boss of seed 2) escaped');assert.equal(n.result.chiefDefeated,false);
 const w=C.fresh();w.heat=C.heat({conditions:['narrow','horde'],seed:2});w.wave=9;w.cleared=8;C.start(w);guard=0;
 while(w.phase==='active'&&guard++<4000){C.tick(w,.25,{gateBuilt:true});for(const e of w.enemies)if(e.alive&&C.exposed(e))C.hit(w,e.key,999,'arch');}
 assert.equal(w.result.win,true);assert.equal(w.result.chiefDefeated,true);assert.equal(w.completed,true);
});

test('expedition save migration: pre-M5 records are threat 0, coins unchanged, completion unlocks threat',()=>{
 const legacy={version:1,initialized:true,groups:[],nextKey:1,coins:5,claimed:37,records:Array.from({length:9},(_,i)=>({wave:i+1,total:C.plan(i+1).potential,bestKills:C.plan(i+1).potential,cleared:true})),trainingBest:5,run:3,settled:[]};
 const e=E.migrate(clone(legacy));assert.equal(e.heatUnlocked,true);assert.deepEqual(e.heatLast,[]);assert.ok(e.records.every(r=>r.heat===undefined));
 const s=save();s.expedition=e;s.outpost.phase='result';s.outpost.result={wave:9,win:true};assert.equal(E.entitlement(s),37,'9×20 points + training 5, ÷5');assert.equal(E.quoteReturn(s).award,0);
 const partial=E.migrate({...clone(legacy),records:legacy.records.slice(0,8)});assert.equal(partial.heatUnlocked,false);
 // Hostile rows: unknown heat, duplicates and inflated kills are bounded; heat rows keep their larger total.
 const hostile=E.migrate({...clone(legacy),heatLast:['rush','nope'],records:[{wave:2,heat:2,total:9,bestKills:999,cleared:true},{wave:2,heat:2,total:1,bestKills:1,cleared:false},{wave:3,heat:-1,total:6,bestKills:6,cleared:true},{wave:4,heat:'x',total:10,bestKills:3}]});
 assert.deepEqual(hostile.heatLast,['rush']);const r2=hostile.records.find(r=>r.wave===2&&r.heat===2);assert.deepEqual(r2,{wave:2,heat:2,total:9,bestKills:9,cleared:true});assert.equal(hostile.records.filter(r=>r.wave===2).length,1);
 assert.equal(E.migrate(clone(hostile)).records.length,hostile.records.length,'round-trips');
});

test('coins: the best record per wave pays (×1+0.5·threat); only the difference is paid, never twice',()=>{
 const s=completed(),base=E.entitlement(s);assert.equal(base,36);assert.equal(E.quoteReturn(s).award,36);
 assert.equal(E.quoteReturn(s,1,['thin','horde']).ready,true);const receipt=E.returnHome(s,1,['thin','horde']);assert.equal(receipt.award,36);assert.equal(receipt.heat,3);
 assert.deepEqual(s.outpost.heat,{level:3,conditions:['horde','thin'],seed:receipt.run});assert.deepEqual(s.expedition.heatLast,['horde','thin']);
 assert.equal(E.beginPreparation(s),true);
 // Threat 3, wave 1 cleared with every kill: 20 points × 2.5 = 50 replaces the threat-0 20 → +30 points → 6 coins.
 play(s,1);const row=s.expedition.records.find(r=>r.wave===1&&r.heat===3);assert.ok(row.cleared);assert.ok(row.total>C.plan(1).potential,'horde total');
 assert.equal(E.entitlement(s),base+6);assert.equal(E.quoteReturn(s).award,6);
 // Same result again at the same threat: no new coins.
 play(s,1);assert.equal(E.quoteReturn(s).award,6);
 const second=E.returnHome(s,1,['thin','horde']);assert.equal(second.award,6);assert.equal(E.quoteReturn(s).reason,'no_result');E.beginPreparation(s);play(s,1);assert.equal(E.quoteReturn(s).award,0,'already claimed');
 // A lower threat cannot lower or re-pay a wave; a loss at a higher threat adds only its kill share.
 assert.equal(E.returnHome(s,1,['rush']).award,0);E.beginPreparation(s);play(s,1);assert.equal(E.quoteReturn(s).award,0);
 assert.equal(E.wavePoints({bestKills:5,total:10,cleared:false,heat:2}),10);
 // Test waves are still never recorded.
 const t=s.outpost;t.phase='prep';t.result=null;C.start(t,{modifiers:{mix:[{kind:'rat',lane:'upper',count:1}],replace:true}});C.tick(t,999);assert.equal(E.record(s,t.result),false);
});

test('threat is locked until a wave-9 clear; the first wave-9 clear at each threat is a milestone',()=>{
 const s=save();E.ensure(s);play(s,1);assert.equal(s.expedition.heatUnlocked,false);const q=E.quoteReturn(s,1,['rush']);assert.equal(q.ready,false);assert.equal(q.reason,'heat_locked');assert.equal(E.returnHome(s,1,['rush']),false);
 assert.equal(E.quoteReturn(s,1,[]).ready,true);
 const done=completed();assert.equal(done.expedition.heatUnlocked,true);assert.equal(done.expedition.milestone.heat,0);
 E.returnHome(done,7,['wings','flank']);E.beginPreparation(done);for(let w=7;w<=9;w++)play(done,w);assert.equal(done.expedition.milestone.heat,2);assert.equal(done.expedition.milestone.token,done.expedition.run+':'+done.outpost.round);
 const token=done.expedition.milestone.token;E.returnHome(done,7,['wings','flank']);E.beginPreparation(done);for(let w=7;w<=9;w++)play(done,w);assert.equal(done.expedition.milestone.token,token,'second clear at the same threat is not a milestone');
});

test('cramped camp seals one squad in use (shown before departure); it stays out for the run; 3 slots',()=>{
 const s=completed();s.expedition.unlocks.ballista=true;const groups=[hire(s,'arch',{x:600,y:250}),hire(s,'arch',{x:600,y:380}),hire(s,'sword',{x:330,y:205}),hire(s,'ballista',{x:700,y:310})];
 assert.equal(E.limit(s,'combat'),4);const run=s.expedition.run,expect=groups[run%4];
 const q=E.quoteReturn(s,1,['narrow']);assert.equal(q.heat.sealed,expect.key,'the picker names the sealed squad');assert.equal(q.heat.sealedId,expect.id);
 const receipt=E.returnHome(s,1,['narrow']);assert.deepEqual(receipt.benched,[expect.key]);assert.equal(s.outpost.heat.sealed,expect.key);assert.equal(E.sealedKey(s),expect.key);
 assert.equal(E.limit(s,'combat'),3);assert.equal(E.limit(s,'production'),4);assert.equal(expect.active,false);assert.equal(E.slotQuote(s,'arch').full,true);
 assert.equal(E.resume(s,expect.key),false,'sealed squad cannot come back');const other=groups.find(g=>g!==expect);assert.equal(E.swap(s,other.key,expect.key),false);
 assert.deepEqual(clone(require('../2/outpost-core.js').migrate(clone(s.outpost)).heat),clone(s.outpost.heat),'seal survives the save');
 // A three-squad crew loses one squad and must fill the free third slot with something else.
 const t=completed();t.expedition.unlocks.ballista=true;const three=[hire(t,'arch',{x:600,y:250}),hire(t,'arch',{x:600,y:380}),hire(t,'ballista',{x:700,y:310})];
 const sealed=three[t.expedition.run%3];E.returnHome(t,1,['narrow']);assert.equal(sealed.active,false);assert.equal(E.resume(t,sealed.key),false);assert.equal(E.slotQuote(t,'sword').full,false);assert.ok(E.recruit(t,'sword'));
 // Without narrow there is no seal; forged seals are dropped.
 assert.equal(C.heat({conditions:['rush'],sealed:5}).sealed,undefined);
 // Rush: the ready button gives 60 s instead of 90.
 const r=completed();E.returnHome(r,1,['rush']);assert.equal(E.beginPreparation(r),true);assert.equal(r.outpost.prepRemaining,60);
});

test('same threat, different enemy counts: best kill-share score survives a larger later loss and reload, without repayment',()=>{
 const s=completed();E.returnHome(s,4,['burrow']);E.beginPreparation(s);play(s,4);
 const earned=E.entitlement(s),row=s.expedition.records.find(r=>r.wave===4&&r.heat===1);
 assert.equal(row.total,13);assert.equal(row.bestKillPoints,10);
 const receipt=E.returnHome(s,4,['horde']);assert.ok(receipt.award>0);const claimed=s.expedition.claimed,coins=s.expedition.coins;
 E.beginPreparation(s);play(s,4,{win:false});
 assert.equal(row.total,14);assert.equal(row.bestKills,13);assert.equal(E.entitlement(s),earned,'a later larger wave never lowers the highest earned score');
 s.expedition=E.migrate(clone(s.expedition));s.outpost=C.migrate(clone(s.outpost));assert.equal(E.entitlement(s),earned,'score survives reload');assert.equal(E.quoteReturn(s).award,0);
 assert.equal(E.returnHome(s,4,['horde']).award,0);assert.equal(s.expedition.claimed,claimed);assert.equal(s.expedition.coins,coins,'same score never pays twice');
 // A prior partial share and a later larger wave also retain the better share, not just full clears.
 assert.equal(E.wavePoints({bestKills:7,total:14,bestKillPoints:8,cleared:false,heat:1}),12);
 const legacy=E.migrate({version:1,initialized:true,groups:[],records:[{wave:4,heat:1,total:13,bestKills:13,cleared:true}]});
 assert.equal(E.wavePoints(legacy.records[0]),30,'pre-fix saves derive the original share');
 assert.equal(E.wavePoints(E.migrate({version:1,initialized:true,groups:[],records:[{wave:4,heat:1,total:14,bestKills:13,cleared:true,bestKillPoints:999}]}).records[0]),30,'new score is bounded on migration');
});
