/* Reload the private, normally earned campaign checkpoint. No grants or clock changes. */
'use strict';
const {chromium}=require('playwright'),fs=require('node:fs'),assert=require('node:assert/strict');
const URL=process.env.GAME_URL||'http://127.0.0.1:4427/preview/?lesson=2',OUT=process.env.QA_OUT||'../earned-v12';
(async()=>{const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||undefined});try{
 const context=await browser.newContext({viewport:{width:1280,height:900},storageState:process.env.QA_RESUME||OUT+'/latest-earned-private.json'}),page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(URL);await page.waitForFunction(()=>window.Outpost?.ready&&!!S.factory);if(await page.locator('#titleBattle').isVisible())await page.click('#titleBattle');
 await page.waitForFunction(()=>S.outpost.completed&&S.outpost.cleared===9);
 const before=await page.evaluate(()=>({gold:S.gold,result:S.outpost.result,journey:S.outpost.journey,people:Object.values(S.owned).reduce((a,b)=>a+b,0),links:S.camp.links.length,loaders:S.camp.loaders.length}));
 assert.equal(before.result.kills,37);assert.equal(before.result.boxes,3);assert.equal(before.result.chiefDefeated,true);
 if(!await page.locator('#campaignEnding.on').isVisible())await page.locator('.campaign-goal-action').click();
 await page.locator('#campaignEnding.on').waitFor();await page.screenshot({path:OUT+'/verified-earned-ending.png'});await page.click('#endingLook');await page.click('#zoomFit');await page.screenshot({path:OUT+'/verified-earned-camp.png'});
 await page.reload();await page.waitForFunction(()=>window.Outpost?.ready&&S.outpost.completed);assert.equal(await page.evaluate(()=>S.gold),before.gold);assert.equal(await page.evaluate(()=>S.outpost.result.kills),37);assert.deepEqual(errors,[]);
 fs.writeFileSync(OUT+'/finish-result.json',JSON.stringify({fixture:false,checks:['earned nine-wave completion survives reload','37 kills, captain defeated, 3 crates','ending and camp can be viewed','reload does not pay victory gold again'],before,errors},null,2));await context.storageState({path:OUT+'/latest-earned-private.json'});console.log('PASS earned ending and reload; gold unchanged');
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
