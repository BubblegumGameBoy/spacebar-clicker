"""Original D-major campaign arrangements, synthesized from authored notes only.
No samples or external music. Signal measurements do not constitute listening review.
"""
from pathlib import Path
import json, re, subprocess, tempfile, wave
import numpy as np

ROOT=Path(__file__).resolve().parent.parent
RATE=44100
CHORDS=[[50,54,57,62],[47,50,54,59],[43,47,50,55],[45,49,52,57],
        [52,55,59,64],[43,47,50,55],[50,54,57,62],[45,49,52,57]]
MOTIF=[[(0,74),(.75,74),(1.5,76),(2,78),(3,76)],[(0,74),(1.5,71),(2.5,69),(3,71)],
       [(0,71),(1,74),(2,79),(3,78)],[(0,76),(1.5,73),(2.5,71),(3,69)],
       [(0,76),(1,79),(2,78),(3,76)],[(0,74),(1.5,71),(2.5,69),(3,67)],
       [(0,74),(1,78),(2,81),(3,78)],[(0,76),(1.5,73),(2.5,69),(3.5,73)]]
HOME=[[(0,74),(2,69),(3,66)],[(0,76),(2.5,74)],[(.5,71),(2,74)],[(0,73),(2,69)],
      [(0,76),(1.5,79),(3,78)],[(.5,74),(2.5,71)],[(0,78),(2,76),(3,74)],[(0,73),(2.5,69)],
      [(0,74),(1.5,76),(3,78)],[(.5,76),(2.5,74)],[(0,79),(2,78),(3,74)],[(0,76),(2,73)],
      [(0,76),(2,74),(3,71)],[(0,71),(2,69)],[(0,74),(2,78)],[(0,76),(1,73),(2,74)]]

def freq(n):return 440*2**((n-69)/12)
def compose(name,bpm,mode):
 beat=60/bpm;duration=64*beat;size=round(duration*RATE);track=np.zeros((size,2));rng=np.random.default_rng(20261021+int(bpm))
 def mix(sig,at,gain,pan=0):
  indices=(np.arange(len(sig))+round(at*RATE))%size
  np.add.at(track[:,0],indices,sig*gain*np.sqrt((1-pan)/2))
  np.add.at(track[:,1],indices,sig*gain*np.sqrt((1+pan)/2))
 def pluck(note,at,length,gain,pan=0):
  t=np.arange(round(length*RATE))/RATE;f=freq(note)
  env=(1-np.exp(-t/.009))*np.exp(-t/(.47 if mode!='home' else .7))*np.minimum(1,np.maximum(0,(length-t)/.06))
  sig=np.sin(2*np.pi*f*t)+.18*np.sin(2*np.pi*2*f*t)*np.exp(-t/.22)+.04*np.sin(2*np.pi*3*f*t)*np.exp(-t/.1)
  mix(sig*env,at,gain,pan)
 def reed(note,at,length,gain,pan=0):
  t=np.arange(round((length+.18)*RATE))/RATE;f=freq(note);phase=2*np.pi*f*t+.045*np.sin(2*np.pi*4.3*t)
  env=np.minimum(1,t/.035)*np.minimum(1,np.maximum(0,(length+.18-t)/.18))
  env*=.82+.18*np.exp(-t/.15)
  sig=np.sin(phase)+.12*np.sin(phase*2)+.035*np.sin(phase*3)
  mix(sig*env,at,gain,pan)
 def drum(at,heavy=False):
  t=np.arange(round(.26*RATE))/RATE;phase=2*np.pi*(54*t+14*.032*(1-np.exp(-t/.032)))
  sig=np.sin(phase)*np.exp(-t*22)*(1-np.exp(-t/.001))
  mix(sig,at,.12 if heavy else .085,0)
 def tick(at,gain=.025,pan=.2):
  t=np.arange(round(.09*RATE))/RATE;noise=rng.normal(0,.25,len(t));noise=np.convolve(noise,np.ones(4)/4,mode='same')
  mix(noise*(1-np.exp(-t/.001))*np.exp(-t*75),at,gain,pan)
 def pad(notes,at,length,gain):
  t=np.arange(round((length+.4)*RATE))/RATE;env=np.minimum(1,t/.32)*np.minimum(1,np.maximum(0,(length+.4-t)/.4))
  for i,n in enumerate(notes):
   f=freq(n);sig=(np.sin(2*np.pi*f*t)+.07*np.sin(2*np.pi*f*2*t))*env
   mix(sig,at,gain,(i-1.5)*.22)
 for bar in range(16):
  chord=CHORDS[bar%8]
  if mode=='home' and bar>=14:chord=CHORDS[0] if bar==15 else CHORDS[3]
  at=bar*4*beat
  pad(chord,at,4*beat,.013 if mode=='raid' else .018 if mode=='final' else .022)
  for step in ([0,2] if mode=='home' else [0,1.5,2,3.5]):pluck(chord[0]-12,at+step*beat,beat*1.7,.075 if mode=='final' else .06,-.06)
  steps=[.5,1.5,2.5,3.5] if mode=='home' else np.arange(0,4,.5)
  for j,step in enumerate(steps):pluck(chord[1+j%3],at+step*beat,beat*1.3,.027 if mode=='home' else .023,(-1 if j%2 else 1)*.35)
  melody=HOME[bar] if mode=='home' else MOTIF[bar%8]
  for j,(step,note) in enumerate(melody):
   if mode=='final' and bar>=8:note+=12 if j%2==0 and note<79 else 0
   end=melody[j+1][0] if j+1<len(melody) else 4
   length=max(.12,(end-step)*beat*.82)
   if mode=='home':pluck(note,at+step*beat,max(.8,length+.5),.095,-.15)
   else:
    reed(note,at+step*beat,length,.042 if mode=='raid' else .048,-.16)
    if mode=='final':reed(note,at+step*beat+.009,length,.014,.24)
  if mode!='home':
   drum(at,mode=='final');drum(at+2*beat,mode=='final')
   for step in [1,3]:
    tick(at+step*beat,.10 if mode=='final' else .065,-.15)
    pluck(38 if mode=='final' else 45,at+step*beat,.2,.02,.05)
   for step in np.arange(.5,4,1):tick(at+step*beat,.035,.25)
   if mode=='final' and bar%4==3:
    for step in [3,3.5,3.75]:pluck(43,at+step*beat,.18,.035,-.1)
 # Circular early reflections preserve the loop and keep the centre clear for SFX.
 track+=np.roll(track,round(.113*RATE),axis=0)[:,::-1]*.075
 track+=np.roll(track,round(.227*RATE),axis=0)[:,::-1]*.035
 track-=track.mean(axis=0);track*=.7/np.max(np.abs(track));pcm=(np.clip(track,-.99,.99)*32767).astype('<i2')
 out=ROOT/'assets/audio'/name;out.parent.mkdir(parents=True,exist_ok=True)
 with tempfile.TemporaryDirectory() as temp:
  wav=Path(temp)/'original.wav'
  with wave.open(str(wav),'wb') as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(RATE);f.writeframes(pcm.tobytes())
  base=['ffmpeg','-hide_banner','-nostats','-y','-i',str(wav)]
  result=subprocess.run(base+['-af','loudnorm=I=-18:TP=-3:LRA=7:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
  measured=json.loads(result.stderr[result.stderr.rfind('{'):result.stderr.rfind('}')+1])
  filt='loudnorm=I=-18:TP=-3:LRA=7:measured_I={input_i}:measured_TP={input_tp}:measured_LRA={input_lra}:measured_thresh={input_thresh}:offset={target_offset}:linear=true'.format(**measured)
  subprocess.run(base+['-af',filt,'-ar',str(RATE),'-c:a','libmp3lame','-b:a','160k',str(out)],check=True,capture_output=True)
  verify=subprocess.run(['ffmpeg','-hide_banner','-nostats','-i',str(out),'-af','loudnorm=print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
  final=json.loads(verify.stderr[verify.stderr.rfind('{'):verify.stderr.rfind('}')+1])
 return {'file':str(out.relative_to(ROOT)),'bpm':bpm,'bars':16,'key':'D major','seconds':round(duration,3),'lufs':float(final['input_i']),'true_peak_db':float(final['input_tp']),'lra':float(final['input_lra']),'authoring':'Original authored pitches and synthesized instruments; not a listening review'}

if __name__=='__main__':
 result=[compose('camp-raid.mp3',104,'raid'),compose('camp-finale.mp3',112,'final'),compose('camp-homecoming.mp3',76,'home')]
 dest=ROOT.parent/'scratch/audio-expert-review/campaign-music.json';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
