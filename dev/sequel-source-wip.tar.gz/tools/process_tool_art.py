"""Crop the M3 tool art (blower 2x1, fence 1x1) to the opaque area (alpha > 48) and save lossless WebP.
Only cropping and format conversion: no drawing, scaling or colour change.
Usage: python3 tools/process_tool_art.py  (reads assets/_incoming, writes assets/tool-*.webp)
       python3 tools/process_tool_art.py hopper  (M4 hopper only: 2x1, half size, lossy WebP q90 / alpha 100 like the M6 enemies)"""
from PIL import Image
import os, json
ROOT = os.path.join(os.path.dirname(__file__), '..', 'assets')

def cell_boxes(im, cols):
    a = im.split()[3].point(lambda v: 255 if v > 48 else 0)
    out = []
    for c in range(cols):
        sx, ex = round(c * im.width / cols), round((c + 1) * im.width / cols)
        b = a.crop((sx, 0, ex, im.height)).getbbox()
        out.append((sx, ex, b))
    return out

def blower():
    im = Image.open(os.path.join(ROOT, '_incoming', 'tool-blower.png')).convert('RGBA')
    cells = cell_boxes(im, 2)
    # One shared rectangle (in cell coordinates) so both frames stay aligned when swapped.
    l = min(b[0] for _, _, b in cells); t = min(b[1] for _, _, b in cells)
    r = max(b[2] for _, _, b in cells); bt = max(b[3] for _, _, b in cells)
    w, h = r - l, bt - t
    atlas = Image.new('RGBA', (w * 2, h), (0, 0, 0, 0))
    for i, (sx, _, _) in enumerate(cells):
        atlas.paste(im.crop((sx + l, t, sx + r, bt)), (i * w, 0))
    atlas.save(os.path.join(ROOT, 'tool-blower.webp'), 'WEBP', lossless=True, quality=100, method=6)
    return {'size': atlas.size, 'cells': [{'cell': i, 'source_x': [sx, ex], 'opaque': [b[0], b[1], b[2] - 1, b[3] - 1]} for i, (sx, ex, b) in enumerate(cells)], 'shared': [l, t, r - 1, bt - 1]}

def fence():
    im = Image.open(os.path.join(ROOT, '_incoming', 'tool-fence.png')).convert('RGBA')
    (_, _, b), = cell_boxes(im, 1)
    crop = im.crop(b)
    crop.save(os.path.join(ROOT, 'tool-fence.webp'), 'WEBP', lossless=True, quality=100, method=6)
    return {'size': crop.size, 'opaque': [b[0], b[1], b[2] - 1, b[3] - 1]}

def hopper():
    # M4 hopper: 2x1 (0 idle, 1 spitting). Shared opaque rectangle so both frames line up; drawn small in game,
    # so half resolution and lossy WebP (quality 90, alpha_quality 100), the same treatment as the M6 enemy art.
    im = Image.open(os.path.join(ROOT, '_incoming', 'tool-hopper.png')).convert('RGBA')
    cells = cell_boxes(im, 2)
    l = min(b[0] for _, _, b in cells); t = min(b[1] for _, _, b in cells)
    r = max(b[2] for _, _, b in cells); bt = max(b[3] for _, _, b in cells)
    w, h = r - l, bt - t
    atlas = Image.new('RGBA', (w * 2, h), (0, 0, 0, 0))
    for i, (sx, _, _) in enumerate(cells):
        atlas.paste(im.crop((sx + l, t, sx + r, bt)), (i * w, 0))
    half = atlas.resize((atlas.width // 2, atlas.height // 2), Image.LANCZOS)
    half.save(os.path.join(ROOT, 'tool-hopper.webp'), 'WEBP', quality=90, alpha_quality=100, method=6)
    return {'size': half.size, 'cell': [half.width // 2, half.height], 'cells': [{'cell': i, 'source_x': [sx, ex], 'opaque': [b[0], b[1], b[2] - 1, b[3] - 1]} for i, (sx, ex, b) in enumerate(cells)], 'shared': [l, t, r - 1, bt - 1]}

if __name__ == '__main__':
    import sys
    if sys.argv[1:] == ['hopper']:
        print(json.dumps({'hopper': hopper()}))
        print('tool-hopper.webp', os.path.getsize(os.path.join(ROOT, 'tool-hopper.webp')), 'bytes')
        raise SystemExit
    print(json.dumps({'blower': blower(), 'fence': fence()}))
    for f in ('tool-blower.webp', 'tool-fence.webp'):
        print(f, os.path.getsize(os.path.join(ROOT, f)), 'bytes')
