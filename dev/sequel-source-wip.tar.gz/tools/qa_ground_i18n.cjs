/* M3 prepared test (three languages, PC mouse and CDP touch): blower/fence cards, the conveyor lock,
   the placement panel, status notes and the board selection card read in the chosen language.
   Prepared state: 20 wood is set once with evaluate() so each language reaches the tools quickly;
   every other step is a visible input. */
'use strict';
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const URL=(process.env.GAME_URL||'http://127.0.0.1:4422/preview/')+'?lab=1',OUT=process.env.QA_OUT||'/tmp/qa-ground-i18n';fs.mkdirSync(OUT,{recursive:true});
const kana=/[ぁ-んァ-ヶ]/,han=/[一-鿿]/;
async function run(browser,lang,mode){
 const touch=mode==='touch',ctx=await browser.newContext(touch?{viewport:{width:390,height:844},hasTouch:true,isMobile:true,deviceScaleFactor:2}:{viewport:{width:1280,height:900}}),page=await ctx.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
 const cdp=touch?await ctx.newCDPSession(page):null,touchEvent=(type,p)=>cdp.send('Input.dispatchTouchEvent',{type,touchPoints:p?[p]:[]});
 const screen=p=>page.evaluate(p=>{const r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return{x:r.left+p.x*z,y:r.top+p.y*z};},p);
 const tap=async(q,hold=60)=>{if(touch){await touchEvent('touchStart',q);await page.waitForTimeout(hold);await touchEvent('touchEnd');}else await page.mouse.click(q.x,q.y);await page.waitForTimeout(200);};
 const press=async sel=>{const el=page.locator(sel).first();await el.scrollIntoViewIfNeeded();const b=await el.boundingBox();await tap({x:b.x+b.width/2,y:b.y+b.height/2});};
 const drag=async(a,z)=>{if(touch){await touchEvent('touchStart',a);for(let i=1;i<=10;i++){await touchEvent('touchMove',{x:a.x+(z.x-a.x)*i/10,y:a.y+(z.y-a.y)*i/10});await page.waitForTimeout(16);}await touchEvent('touchEnd');}else{await page.mouse.move(a.x,a.y);await page.mouse.down();await page.mouse.move(z.x,z.y,{steps:10});await page.mouse.up();}await page.waitForTimeout(200);};
 const texts={};const shot=n=>page.screenshot({path:path.join(OUT,lang+'-'+mode+'-'+n+'.png')});
 try{
  await page.goto(URL);await page.waitForTimeout(1000);await press('.ts-lang[data-lang="'+lang+'"]');if(await page.locator('#titleBattle').isVisible())await press('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);await page.waitForTimeout(500);
  await page.evaluate(()=>{S.factory.inventory.wood=20;SupplyFactory.translate();});
  texts.cards=await page.evaluate(()=>[...document.querySelectorAll('.equipment-card')].map(c=>c.innerText.replace(/\s+/g,' ').trim()));await page.locator('.equipment-card').first().scrollIntoViewIfNeeded();await shot('cards');
  await press('[data-equipment="blower"]');await page.locator('#field').scrollIntoViewIfNeeded();const q=await screen({x:420,y:330});if(!touch)await page.mouse.move(q.x,q.y);await page.waitForTimeout(200);
  texts.blowerMode=await page.evaluate(()=>[document.querySelector('.placement-current')?.textContent,document.querySelector('#railEditor b')?.textContent,document.querySelector('[data-rail-action="rotate"]')?.textContent].join(' | '));await shot('blower-mode');
  await tap(q);texts.blowerPlaced=await page.evaluate(()=>document.getElementById('campDeliveryNote')?.textContent);
  await press('[data-equipment="fence"]');texts.fenceMode=await page.evaluate(()=>[document.querySelector('.placement-current')?.textContent,document.querySelector('.placement-hint')?.textContent,document.querySelector('#railEditor b')?.textContent].join(' | '));
  await page.locator('#field').scrollIntoViewIfNeeded();await drag(await screen({x:560,y:470}),await screen({x:650,y:470}));texts.fencePlaced=await page.evaluate(()=>document.getElementById('campDeliveryNote')?.textContent);
  const b=await screen({x:420,y:330});if(touch){await touchEvent('touchStart',b);await page.waitForTimeout(650);await touchEvent('touchEnd');await page.waitForTimeout(200);}else{await page.mouse.click(b.x,b.y,{button:'right'});await page.waitForTimeout(200);}
  texts.card=await page.evaluate(()=>document.getElementById('beltActions')?.innerText.replace(/\s+/g,' ').trim());await shot('blower-card');assert.equal(await page.evaluate(()=>OutpostCamp.selection?.kind),'blower');
  await page.keyboard.press('Escape').catch(()=>{});texts.lesson=await page.evaluate(()=>document.getElementById('onboardingGuide')?.innerText.replace(/\s+/g,' ').slice(0,160));
  const all=Object.values(texts).flat().join(' ');
  if(lang==='en')assert.ok(!kana.test(all)&&!han.test(all),'English text has no Japanese/Chinese: '+all.match(/[ぁ-んァ-ヶ一-鿿]+/g));
  if(lang==='zh')assert.ok(!kana.test(all)&&han.test(all),'Chinese text has no kana: '+all.match(/[ぁ-んァ-ヶ]+/g));
  if(lang==='ja')assert.ok(kana.test(all));
  assert.match(texts.cards.join(' '),lang==='ja'?/章1クリアで解放/:lang==='en'?/Unlocks after Chapter 1/:/第1章通关后解锁/);
  assert.deepEqual(errors,[]);return {lang,mode,status:'passed',texts};
 }catch(e){await shot('FAIL').catch(()=>{});return {lang,mode,status:'failed',message:e.stack,texts,errors};}finally{await ctx.close();}
}
(async()=>{const browser=await chromium.launch();const results=[];try{for(const lang of ['ja','en','zh'])for(const mode of ['pc','touch'])results.push(await run(browser,lang,mode));}finally{await browser.close();}
 fs.writeFileSync(path.join(OUT,'result.json'),JSON.stringify({fixture:'Prepared: 20 wood via evaluate, then visible inputs; touch is CDP touch',results},null,2));console.log(JSON.stringify(results.map(r=>({lang:r.lang,mode:r.mode,status:r.status,message:r.message?.slice(0,300),texts:r.texts})),null,1));if(results.some(r=>r.status!=='passed'))process.exitCode=1;})();
