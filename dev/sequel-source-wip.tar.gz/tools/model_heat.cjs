/* M5 threat trials, fixed dt (1/30 s). Prepared, not a playthrough: the crew is the recorded completion crew of the earned
   nine-wave run (preview/media/sequel-progression-checks.json: arch 3/3 + ballista 3 [armour] at Wave4, arch 6/6 + ballista 3 at Wave9,
   positions from its final save), with the finished camp's gate (2.5 s) and beacon (archer range 110). No player assistance.
   Usage: node tools/model_heat.cjs [out.json]   QA_SEEDS=n repeats each trial with n cooldown seeds. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),C=require('../2/outpost-core.js'),{Battle}=require('../2/army-sim.js'),{createLedger}=require('./combat_metrics.cjs');
const ROLE={arch:{damage:5,interval:1.3,range:110,ranged:true,impact:680},sword:{damage:3,interval:1.2,range:28,ranged:false,impact:240},ballista:{damage:20,interval:6,range:160,minRange:60,ranged:true,impact:650}};
function formation(anchor,key,count){return Array.from({length:count},(_,m)=>m?{x:anchor.x+Math.cos(m*2.399963+key*.17)*23*Math.sqrt(m),y:anchor.y+Math.sin(m*2.399963+key*.17)*23*Math.sqrt(m)}:{...anchor});}
// Anchors of the earned completion save (keys 2,3,4), plus a few alternatives used by the "changed crew" rows.
const AT={archUp:{x:643,y:250},archLow:{x:620,y:360},ballista:{x:620,y:400},homeUpper:{x:200,y:250},homeLower:{x:200,y:400},home:{x:160,y:330},upperSword:{x:330,y:205},lowerSword:{x:330,y:415},forwardUpper:{x:780,y:225},forwardLower:{x:780,y:395},ballistaMid:{x:700,y:310},bendUpper:{x:250,y:215},bendLower:{x:250,y:405}};
const A=(at,count,policy)=>({id:'arch',at,count,policy}),Sw=(at,count,policy)=>({id:'sword',at,count,policy}),B=(at,count,policy='armor')=>({id:'ballista',at,count,policy});
const COMPLETION={4:[A('archUp',3),A('archLow',3),B('ballista',3)],9:[A('archUp',6),A('archLow',6),B('ballista',3)]};
function trial({wave,heat,groups,seed=1,gate=true,dt:step=1/30,assist=0}){
 const state=C.fresh();state.wave=wave;state.cleared=wave-1;state.claimedFirst=Array.from({length:wave-1},(_,i)=>i+1);state.heat=C.heat(heat);C.start(state);
 const sim=new Battle();sim.fixedWorld=true;sim.stationary=true;sim.bounds(960,540,{x:10000,y:10000,r:0,alive:false});sim.outpostState=state;sim.roundToken=state.round;sim.enemies=state.enemies;
 const actors=[],indices={};let key=2;
 for(const g of groups){const pts=formation(AT[g.at]||g.at,key,g.count);for(const p of pts){const index=indices[g.id]=(indices[g.id]??-1)+1;actors.push({id:g.id,index,groupKey:key,policy:g.policy||'front',x:p.x,y:p.y});}key++;}
 const ids=[...new Set(actors.map(a=>a.id))];
 sim.sync(ids.map(id=>({id,count:actors.filter(a=>a.id===id).length,ranged:ROLE[id].ranged,damage:ROLE[id].damage,interval:ROLE[id].interval,range:ROLE[id].range,minRange:ROLE[id].minRange||0,anim:{impact:ROLE[id].impact}})));
 for(const p of sim.soldiers){const a=actors.find(a=>a.id===p.id&&a.index===p.index);Object.assign(p,{x:a.x,y:a.y,policy:a.policy,enterAt:-1});}
 sim.encounter(seed);const ledger=createLedger(actors);let steps=0,rng=seed*9301+49297,pressAt=assist?1/assist:Infinity,selected=null,combo=0,manual=0;
 // jitter: frame steps drawn in [1/60, 0.1] s like a loaded browser (army-view caps each step at 0.1). assist: Space presses per second,
 // the same rule as Outpost.manual (keeps the chosen enemy until it dies, else the exposed enemy nearest home; 4×(1+min(.25,combo·0.005)), armour applies).
 const next=()=>{if(step!=='jitter')return step;rng=(rng*9301+49297)%233280;return 1/60+(rng/233280)*(0.1-1/60);};
 while(state.phase==='active'&&steps++<30000){const dt=next();C.tick(state,dt,{gateBuilt:gate});
  if(assist&&state.phase==='active'&&state.elapsed>=pressAt){pressAt+=1/assist;const chosen=state.enemies.find(e=>e.alive&&e.key===selected&&C.exposed(e)),enemy=chosen||C.target(state,C.WORLD.home,2000,{role:'manual'});if(enemy){selected=enemy.key;combo++;const amount=4*(1+Math.min(.25,combo*.005)),outcome=C.hit(state,enemy.key,amount,'manual');manual+=outcome.applied;}}C.reveal(state,sim.soldiers);sim.outpostState=state;sim.enemies=state.phase==='active'?state.enemies:[];const events=sim.step(dt,{x:0,y:0,hp:1,max:1});
  for(const event of events){if(event.kind==='release'&&state.phase==='active')ledger.release(event,state.elapsed);if(event.kind!=='damage'||state.phase!=='active'||event.roundToken!==state.round||event.target!==state.enemies.find(e=>e.key===event.targetKey)||!event.target.alive)continue;const before={...event.target},outcome=C.hit(state,event.targetKey,event.amount,event.p.id,{x:event.p.x,y:event.p.y});ledger.hit({role:event.p.id,index:event.p.index,amount:event.amount,before,outcome,time:state.elapsed});}}
 const m=ledger.summary(),through={};for(const e of state.enemies)if(!e.alive&&e.hp>0)through[e.kind]=(through[e.kind]||0)+1;
 return {manual:+manual.toFixed(1),win:state.result.win,boxes:state.result.boxes,startBoxes:C.planFor(state).boxes,kills:state.result.kills,escaped:state.result.escaped,potential:C.planFor(state).potential,boss:C.planFor(state).boss,
  damage:Object.fromEntries(Object.values(m.groups||{}).map(g=>[g.id+'#'+g.groupKey,{applied:+g.applied.toFixed(1),kills:g.kills,armorBlocked:+g.armorBlocked.toFixed(1)}])),through};
}
const crewLabel=groups=>groups.map(g=>g.count+'×'+g.id+'@'+(typeof g.at==='string'?g.at:JSON.stringify(g.at))+(g.policy&&g.policy!=='front'?'['+g.policy+']':'')).join(', ');
// Threat 0, single conditions at threat 1, and threat-3 sets, each on Wave4 and Wave9 with the completion crew.
const SETS={'0':[],'1:horde':['horde'],'1:ironhide':['ironhide'],'1:flank':['flank'],'1:wings':['wings'],'1:shieldwall':['shieldwall'],'1:burrow':['burrow'],'2:thin':['thin'],'2:procession':['procession'],'2:siege':['siege'],'3:ironhide+thin':['ironhide','thin'],'3:wings+procession':['wings','procession'],'3:horde+flank+burrow':['horde','flank','burrow']};
// "Change the crew or placement" answers, tried only where the completion crew loses.
const FIXES={
 ironhide:[[A('archUp',3),A('archLow',3),B('ballista',3,'armor'),Sw('upperSword',3)],'+剣士1隊(上の角)'],
 wings:[[A('archUp',3),A('homeLower',3),B('ballista',3)],'下の弓兵を倉庫寄りへ'],
 procession:[[A('archUp',3),A('archLow',3),B('ballista',3,'healer')],'バリスタ方針=回復役'],
 siege:[[A('forwardUpper',3),A('archLow',3),B('ballistaMid',3)],'弓兵1隊とバリスタを前へ']
};
function run(seeds=1){const rows=[];for(const wave of [4,9])for(const [id,conditions] of Object.entries(SETS)){const groups=COMPLETION[wave],runs=Array.from({length:seeds},(_,i)=>trial({wave,heat:{conditions,seed:wave},groups,seed:i+1}));rows.push({wave,set:id,level:C.heat({conditions}).level,conditions,crew:crewLabel(groups),...runs[0],seeds:runs.map(r=>(r.win?'W':'L')+r.boxes).join(' ')});}
 return rows;}
module.exports={trial,run,AT,COMPLETION,SETS,FIXES,crewLabel,A,Sw,B};
if(require.main===module){const seeds=+process.env.QA_SEEDS||1,rows=run(seeds);for(const r of rows)console.log(('W'+r.wave+' '+r.set).padEnd(28),r.win?'WIN ':'LOSE',r.boxes+'/'+r.startBoxes,'kills',r.kills+'/'+r.potential,'esc',r.escaped,r.seeds,JSON.stringify(r.through),Object.entries(r.damage).map(([k,v])=>k+':'+v.applied).join(' '));
 const file=process.argv[2];if(file){fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,JSON.stringify({kind:'m5-heat-model',seeds,rows},null,1));}}
