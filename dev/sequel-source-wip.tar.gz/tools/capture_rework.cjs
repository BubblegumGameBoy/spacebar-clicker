// Record the actual browser with Chromium screencast + the installed FFmpeg.
// No Playwright browser/encoder downloads, no external requests, no production writes.
const {chromium}=require('playwright');
const {spawn}=require('node:child_process');
const fs=require('node:fs'),path=require('node:path');
const out=path.resolve(process.env.REWORK_MEDIA||'promo-output/rework'),web=process.env.GAME_URL||'http://127.0.0.1:4173/2';
fs.mkdirSync(out,{recursive:true});
async function record(page,name,actions){
 const destination=path.join(out,name+'.mp4');
 const ff=spawn(process.env.FFMPEG||'ffmpeg',['-hide_banner','-loglevel','error','-y','-f','image2pipe','-vcodec','mjpeg','-framerate','20','-i','pipe:0','-an','-c:v','libx264','-preset','veryfast','-crf','24','-vf','scale=in_range=pc:out_range=tv,format=yuv420p','-color_range','tv','-pix_fmt','yuv420p','-movflags','+faststart',destination],{stdio:['pipe','ignore','pipe']});
 let error='',image=await page.screenshot({type:'jpeg',quality:85}),frames=0,draining=false;
 ff.stderr.on('data',b=>error+=b.toString());
 const done=new Promise((resolve,reject)=>{ff.once('error',reject);ff.once('exit',code=>code===0?resolve():reject(Error(error||'ffmpeg exited '+code)));});
 const cdp=await page.context().newCDPSession(page);
 cdp.on('Page.screencastFrame',f=>{image=Buffer.from(f.data,'base64');void cdp.send('Page.screencastFrameAck',{sessionId:f.sessionId}).catch(()=>{});});
 await cdp.send('Page.startScreencast',{format:'jpeg',quality:85,maxWidth:1280,maxHeight:900,everyNthFrame:1});
 const timer=setInterval(()=>{if(draining||!image)return;frames++;if(!ff.stdin.write(image)){draining=true;ff.stdin.once('drain',()=>draining=false);}},50);
 try{await actions();}finally{clearInterval(timer);await cdp.send('Page.stopScreencast');await cdp.detach();ff.stdin.end();await done;}
 if(frames<100)throw Error('Recording too short');
 console.log(JSON.stringify({file:destination,frames,seconds:frames/20}));return {file:name+'.mp4',frames,seconds:frames/20};
}
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true});
 const clips=[];
 try{
  const context=await browser.newContext({viewport:{width:1280,height:900}});
  await context.route('**/*',r=>new URL(r.request().url()).origin===new URL(web).origin?r.continue():r.abort());
  await context.addInitScript(()=>{localStorage.setItem('sbr2_lang','ja');localStorage.setItem('sbr2_intro_done_v1','1');});
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.stack));await page.goto(web+'/?capture&mode=measure&sec=10',{waitUntil:'networkidle'});
  clips.push(await record(page,'measurement-to-result',async()=>{
   await page.waitForTimeout(600);await page.click('#measureStart');await page.locator('.measure-orb.live').waitFor();const start=Date.now();while(Date.now()-start<10100){await page.keyboard.press('Space');await page.waitForTimeout(235);}await page.locator('.measure-total').waitFor();await page.waitForTimeout(1800);
  }));
  await page.click('#resultBattle');
  await page.evaluate(()=>{setBgm(false);setSe(false);S=freshState();S.gold=1e12;S.factory=SupplyCore.fresh();S.factory.inventory={wood:10000,stone:10000};S.hero.vitality=100;S.captainHp=1600;S.bossWave=20;S.clearedBossWave=19;S.owned.sword=12;S.owned.woodcutter=5;S.ulvl.sword=9;spawnBoss(true);renderUnits();renderCards();document.getElementById('panels').scrollTop=0;ArmyView.fit();});await page.waitForTimeout(700);
  clips.push(await record(page,'army-recruit-evolution',async()=>{
   await page.waitForTimeout(1000);await page.click('[data-quantity="10"]');await page.click('[data-recruit="sword"]');await page.waitForTimeout(2800);
   await page.locator('.army-card[data-id="sword"] .upgrade-line').first().click();await page.waitForTimeout(3400);
   for(const total of [100,400,1200,5000]){await page.evaluate(n=>{S.owned.sword=n;renderUnits();renderCards();ArmyView.fit();},total);await page.waitForTimeout(1600);}
   await page.waitForTimeout(1500);
  }));
  await page.evaluate(()=>{Rework.close();S=freshState();S.factory=SupplyCore.fresh(1100,500,19);S.factory.inventory={wood:80,stone:80};S.gold=1e6;S.hero.vitality=20;S.captainHp=400;S.owned.sword=8;S.owned.arch=16;S.owned.healer=3;S.owned.woodcutter=3;S.owned.miner=2;S.owned.porter=3;S.bossWave=8;S.clearedBossWave=7;spawnBoss(true);renderUnits();renderCards();document.getElementById('panels').scrollTop=0;ArmyView.fit();});await page.waitForTimeout(3500);
  clips.push(await record(page,'combat-and-supply',async()=>{
   await page.waitForTimeout(1200);await page.click('#buildRails');
   for(const type of ['wood','stone']){
    const route=await page.evaluate(type=>{const s=S.factory,node=s.nodes.find(n=>n.type===type),r=field.getBoundingClientRect(),z=ArmyView.camera.scale;return {from:{x:r.left+s.depot.x*z,y:r.top+s.depot.y*z},to:{x:r.left+(node.x-node.radius-25)*z,y:r.top+(node.y+12)*z}};},type);
    await page.mouse.move(route.from.x,route.from.y);await page.mouse.down();await page.mouse.move(route.to.x,route.to.y,{steps:18});await page.waitForTimeout(450);await page.mouse.up();await page.waitForTimeout(1800);
   }
   await page.click('#buildRails');await page.waitForTimeout(6500);await page.click('#selectCaptain');
   const destination=await page.evaluate(()=>{const r=field.getBoundingClientRect(),z=ArmyView.camera.scale,h=BattleControl.hero;return {x:r.left+(h.x+110)*z,y:r.top+(h.y-70)*z};});await page.mouse.click(destination.x,destination.y);await page.waitForTimeout(1500);await page.click('#commandMode');await page.waitForTimeout(5000);
  }));
  await page.screenshot({path:path.join(out,'combat-and-supply-desktop.png')});await page.setViewportSize({width:390,height:844});await page.waitForTimeout(1200);await page.screenshot({path:path.join(out,'combat-and-supply-mobile.png')});
  if(errors.length)throw Error(errors.join('\n'));
  fs.writeFileSync(path.join(out,'clips.json'),JSON.stringify({clips,note:'Silent recordings of the actual local game. Army footage uses controlled demo counts; combat/supply uses a prepared demonstration save; no production score submissions.'},null,2));
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
