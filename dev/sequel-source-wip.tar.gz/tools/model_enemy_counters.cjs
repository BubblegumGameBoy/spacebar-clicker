/* M6 prepared fixed-dt trials: one wave of a single new enemy kind, without and with its counter crew.
   Not a playthrough: crews, positions and the wave are chosen here. Real rules: OutpostCore + ArmySim + the same hit order as the game.
   Usage: node tools/model_enemy_counters.cjs [out.json]   (QA_ONLY=kind to run one kind) */
'use strict';
const fs=require('node:fs'),path=require('node:path'),C=require('../2/outpost-core.js'),{Battle}=require('../2/army-sim.js'),{createLedger}=require('./combat_metrics.cjs');
const ROLE={arch:{damage:5,interval:1.3,range:90,ranged:true,impact:680},sword:{damage:3,interval:1.2,range:28,ranged:false,impact:240},ballista:{damage:20,interval:6,range:160,minRange:60,ranged:true,impact:650}};
// Same spiral as ExpeditionCore.formation, so members stand where a placed squad would.
function formation(anchor,key,count){return Array.from({length:count},(_,m)=>m?{x:anchor.x+Math.cos(m*2.399963+key*.17)*23*Math.sqrt(m),y:anchor.y+Math.sin(m*2.399963+key*.17)*23*Math.sqrt(m)}:{...anchor});}
const AT={upperArch:{x:560,y:225},lowerArch:{x:560,y:395},homeUpper:{x:200,y:250},homeLower:{x:200,y:400},home:{x:150,y:300},upperSword:{x:330,y:205},lowerSword:{x:330,y:415},bendUpper:{x:250,y:215},bendLower:{x:250,y:405},ballista:{x:700,y:310},ballistaMid:{x:420,y:310},forwardUpper:{x:760,y:225},forwardLower:{x:760,y:395},farUpper:{x:560,y:262},farLower:{x:560,y:358}};
function trial({groups,mix,duration,wave=5,planVersion,seed=1}){
 const state=C.fresh();state.wave=wave;C.start(state,{modifiers:mix?{mix,replace:true,duration}:null});if(planVersion)state.planVersion=planVersion;
 const sim=new Battle();sim.fixedWorld=true;sim.stationary=true;sim.bounds(960,540,{x:10000,y:10000,r:0,alive:false});sim.outpostState=state;sim.roundToken=state.round;sim.enemies=state.enemies;
 const actors=[],indices={};let key=1;
 for(const g of groups){const pts=formation(AT[g.at]||g.at,key,g.count);for(const p of pts){const index=indices[g.id]=(indices[g.id]??-1)+1;actors.push({id:g.id,index,groupKey:key,policy:g.policy||'front',x:p.x,y:p.y});}key++;}
 const ids=[...new Set(actors.map(a=>a.id))];
 sim.sync(ids.map(id=>({id,count:actors.filter(a=>a.id===id).length,ranged:ROLE[id].ranged,damage:ROLE[id].damage,interval:ROLE[id].interval,range:ROLE[id].range,minRange:ROLE[id].minRange||0,anim:{impact:ROLE[id].impact}})));
 for(const p of sim.soldiers){const a=actors.find(a=>a.id===p.id&&a.index===p.index);Object.assign(p,{x:a.x,y:a.y,policy:a.policy,enterAt:-1});}
 sim.encounter(seed);const ledger=createLedger(actors),dt=1/30;let steps=0,blocked=0,heal=0;
 while(state.phase==='active'&&steps++<20000){C.tick(state,dt,{gateBuilt:false});sim.outpostState=state;sim.enemies=state.phase==='active'?state.enemies:[];const events=sim.step(dt,{x:0,y:0,hp:1,max:1});
  for(const event of events){if(event.kind==='release'&&state.phase==='active')ledger.release(event,state.elapsed);if(event.kind!=='damage'||state.phase!=='active'||event.roundToken!==state.round||event.target!==state.enemies.find(e=>e.key===event.targetKey)||!event.target.alive)continue;const before={...event.target},outcome=C.hit(state,event.targetKey,event.amount,event.p.id,{x:event.p.x,y:event.p.y});if(outcome.blocked)blocked++;ledger.hit({role:event.p.id,index:event.p.index,amount:event.amount,before,outcome,time:state.elapsed});}}
 heal=state.enemies.reduce((n,e)=>n+(e.healed||0),0);const m=ledger.summary();
 return {crew:groups.map(g=>g.count+'×'+g.id+'@'+(typeof g.at==='string'?g.at:JSON.stringify(g.at))+(g.policy&&g.policy!=='front'?'['+g.policy+']':'')).join(', '),win:state.result.win,boxes:state.result.boxes,kills:state.result.kills,escaped:state.result.escaped,elapsed:+state.elapsed.toFixed(2),shieldBlocks:blocked,healed:heal,
  damage:Object.fromEntries(Object.values(m.groups||{}).map(g=>[g.id+'#'+g.groupKey,{applied:+g.applied.toFixed(1),kills:g.kills,releases:g.releases}])),enemies:state.enemies.map(e=>({kind:e.kind,lane:e.lane,hp:+e.hp.toFixed(1),escaped:!e.alive&&e.hp>0}))};
}
const A=(at,count=3,policy)=>({id:'arch',at,count,policy}),S=(at,count=3,policy)=>({id:'sword',at,count,policy}),B=(at,count=3,policy)=>({id:'ballista',at,count,policy});
const both=(kind,count,gap,at=0)=>[{kind,lane:'both',count,at,gap}];
const SCENARIOS={
 shield:{mix:both('shield',10,1.8),why:'Arrows bounce off the shield; one sword or ballista hit breaks it.',without:[A('upperArch'),A('lowerArch')],with:[A('upperArch'),A('lowerArch'),S('upperSword'),S('lowerSword')],withLabel:'+剣士'},
 bat:{mix:both('bat',8,3),why:'Flies straight to the camp; swords and ballistas cannot hit it.',without:[S('homeUpper'),S('homeLower'),B('ballista')],with:[S('homeUpper'),A('homeLower'),B('ballista')],withLabel:'剣士1隊→弓兵'},
 ooze:{mix:both('ooze',8,2.7),why:'Splits into two oozelets on death.',without:[B('ballista'),S('upperSword'),S('lowerSword')],with:[B('ballista'),A('upperArch'),A('lowerArch')],withLabel:'剣士→弓兵'},
 mole:{mix:both('mole',8,3),why:'Untargetable mid-road; surfaces before the bend.',without:[A('upperArch'),A('lowerArch')],with:[A('bendUpper'),A('bendLower')],withLabel:'弓兵を角へ'},
 shaman:{mix:[{kind:'guard',lane:'both',count:6,at:0,gap:2.5},{kind:'shaman',lane:'both',count:6,at:3,gap:2.5}],why:'Heals nearby raiders from the back of the column.',without:[A('upperArch'),A('lowerArch'),B('ballista')],with:[A('upperArch'),A('lowerArch'),B('ballista',3,'healer')],withLabel:'バリスタ方針=回復役'},
 beetle:{mix:both('beetle',8,3.5),duration:90,why:'Slow; deflects arrows from the front.',without:[A('upperArch'),A('lowerArch'),A('farUpper'),A('farLower')],with:[A('upperArch'),A('lowerArch'),B('ballista'),S('upperSword')],withLabel:'弓兵2隊→バリスタ+剣士'},
 swarm:{mix:both('swarm',6,4),why:'A pack of 10: each hit fells one mouse.',without:[B('ballista'),S('upperSword'),S('lowerSword')],with:[B('ballista'),A('upperArch'),A('lowerArch')],withLabel:'剣士→弓兵'},
 wisp:{mix:both('wisp',8,2.5),why:'Only visible close to an ally.',without:[A('farUpper'),A('farLower'),B('ballista')],with:[A('farUpper'),A('farLower'),S('upperSword'),S('lowerSword')],withLabel:'バリスタ→道の剣士'},
 siegecart:{mix:both('siegecart',4,6),duration:90,why:'Armour 3; releases 3 rats when broken.',without:[A('upperArch'),A('lowerArch')],with:[A('upperArch'),A('lowerArch'),B('ballista')],withLabel:'+バリスタ'},
 slinger:{mix:both('slinger',6,3),why:'Stops mid-road and stones the crates.',without:[A('homeUpper'),A('homeLower')],with:[A('homeUpper'),A('homeLower'),B('ballista')],withLabel:'+バリスタ'}
};
function run(only){const out={};for(const [kind,s] of Object.entries(SCENARIOS)){if(only&&kind!==only)continue;const plan=C.plan(5,3,{mix:s.mix,replace:true,duration:s.duration});out[kind]={why:s.why,wave:{count:plan.spawns.length,mix:s.mix,duration:plan.duration},without:trial({groups:s.without,mix:s.mix,duration:s.duration}),with:{label:s.withLabel,...trial({groups:s.with,mix:s.mix,duration:s.duration})}};}return out;}
module.exports={trial,run,SCENARIOS,AT,formation};
if(require.main===module){const out=run(process.env.QA_ONLY);for(const [k,v] of Object.entries(out))console.log(k.padEnd(10),'without:',v.without.win?'WIN ':'LOSE',v.without.boxes,'esc',v.without.escaped,'| with:',v.with.win?'WIN ':'LOSE',v.with.boxes,'esc',v.with.escaped,'|',JSON.stringify(v.without.damage),'=>',JSON.stringify(v.with.damage));const file=process.argv[2];if(file){fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,JSON.stringify({kind:'m6-enemy-counter-trials',note:'Prepared fixed-dt (1/30 s) trials. Crews, positions and single-kind waves are chosen by the tool; not a playthrough.',trials:out},null,1));}}
