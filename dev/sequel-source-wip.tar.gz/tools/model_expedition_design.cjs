/* DESIGN experiment only. Does not alter or represent the live game's combat. */
'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const out='/workspace/scratch/expedition-design';fs.mkdirSync(out,{recursive:true});
const weapons={archer:{damage:5,interval:1.3,range:90,minRange:0,pierce:false},ballista:{damage:20,interval:6,range:160,minRange:60,pierce:true}};
function simulate(loadout,kind){
 const specs={swarm:{hp:8,armor:0,speed:34,count:12,gap:.65},armour:{hp:42,armor:2,speed:19,count:6,gap:2},mixed:{hp:16,armor:0,speed:30,count:8,gap:1.2}};
 const definition=specs[kind],crew=loadout.map(type=>({...weapons[type],cooldown:0})),enemies=[];let kills=0,escaped=0,next=0;
 const dt=.02,home=0,station=250,entry=700;
 for(let time=0;time<65;time+=dt){
  while(next<definition.count&&time+1e-8>=next*definition.gap){const guard=kind==='mixed'&&next%3===0;enemies.push({x:entry,hp:guard?42:definition.hp,armor:guard?2:definition.armor,speed:guard?19:definition.speed,alive:true});next++;}
  for(const soldier of crew){soldier.cooldown=Math.max(0,soldier.cooldown-dt);if(soldier.cooldown>1e-8)continue;const target=enemies.filter(e=>e.alive&&Math.abs(e.x-station)<=soldier.range&&Math.abs(e.x-station)>=soldier.minRange).sort((a,b)=>a.x-b.x)[0];if(!target)continue;target.hp-=Math.max(1,soldier.damage-(soldier.pierce?0:target.armor));soldier.cooldown=soldier.interval;if(target.hp<=0){target.alive=false;kills++;}}
  for(const e of enemies)if(e.alive){e.x-=e.speed*dt;if(e.x<=home){e.alive=false;escaped++;}}
 }
 return {kills,escaped,count:definition.count};
}
const comparisons=['swarm','armour','mixed'].flatMap(kind=>[['archer','archer'],['archer','ballista'],['ballista','ballista']].map(loadout=>({kind,loadout,result:simulate(loadout,kind)})));
// Lifetime entitlement: repeated shallow failures cannot repeatedly mint coins.
function entitlement(records,trainingTiers){let points=0,cleared=0;for(const r of records){const kills=Math.max(0,Math.min(r.total,r.bestKills));points+=Math.floor(10*kills/r.total);if(r.cleared){points+=10;cleared++;}}const training=Math.min(10,2*cleared,trainingTiers);return Math.floor((points+training)/5);}
function payout(total,claimed){return Math.max(0,total-claimed);}
const scenarios=[{name:'idle loss',records:[{total:3,bestKills:0,cleared:false}],training:10,claimed:0},{name:'two rats, then defeat',records:[{total:3,bestKills:2,cleared:false}],training:10,claimed:0},{name:'repeat the same defeat',records:[{total:3,bestKills:2,cleared:false}],training:10,claimed:1},{name:'first wave clear',records:[{total:3,bestKills:3,cleared:true}],training:2,claimed:1},{name:'first two waves clear',records:[{total:3,bestKills:3,cleared:true},{total:4,bestKills:4,cleared:true}],training:4,claimed:4}].map(s=>({...s,entitlement:entitlement(s.records,s.training),award:payout(entitlement(s.records,s.training),s.claimed)}));
assert.equal(scenarios[0].award,0);assert.equal(scenarios[1].award,1);assert.equal(scenarios[2].award,0);assert.ok(scenarios[4].award>0);
const score=(kind,units)=>comparisons.find(q=>q.kind===kind&&q.loadout.join(',')===units).result.kills;
assert.ok(score('swarm','archer,archer')>score('swarm','ballista,ballista'));
assert.ok(score('armour','ballista,ballista')>score('armour','archer,archer'));
for(const q of comparisons)assert.equal(q.result.kills+q.result.escaped,q.result.count);
const result={status:'design experiment, not a playtest',limits:['1D point targets; no bolts, rendering, collision, conveyors or squad spreading','Same number of combat slots; no cost-normalization claim','Supports candidate role separation only; full browser play must verify balance'],weapons,comparisons,prestigeScenarios:scenarios};fs.writeFileSync(out+'/model.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
