/* M3 real play: fresh ?lesson=1 save to the first raid, with visible inputs only (PC mouse 1280x900,
   CDP touch 390x844 — CDP touch is not a real device). No grants, no time acceleration.
   evaluate() only reads state, screen coordinates and the same ground prediction the preview draws
   ("n / 8"), which stands in for the player looking at the preview while choosing a spot.
   Flow: 10 wood -> Both hands -> hire and place a lumberjack (a far spot, right of tree 1)
   -> blower behind its landing point -> watch a log blow home -> 60 s with the blower only
   -> 1-2 guide fences -> 60 s with blower+fences -> 30 wood basket -> 2 archers -> Ready -> first raid. */
'use strict';
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const BASE=process.env.GAME_URL||'http://127.0.0.1:4422/preview/',URL=BASE+(BASE.includes('?')?'&':'?')+'lesson=1',OUT=process.env.QA_OUT||'/tmp/qa-ground-journey';fs.mkdirSync(OUT,{recursive:true});
const MODES=(process.env.QA_MODES||'pc,touch').split(','),SPOT=process.env.QA_SPOT||'tree1-right',WINDOW=Number(process.env.QA_WINDOW||60);
async function run(browser,mode){
 const touch=mode==='touch',ctx=await browser.newContext(touch?{viewport:{width:390,height:844},hasTouch:true,isMobile:true,deviceScaleFactor:2}:{viewport:{width:1280,height:900}}),page=await ctx.newPage(),errors=[],log=[];let serial=0,inputs=0,carries=0;const t0=Date.now(),secs=()=>+((Date.now()-t0)/1000).toFixed(1);
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
 const cdp=touch?await ctx.newCDPSession(page):null,touchEvent=(type,p)=>cdp.send('Input.dispatchTouchEvent',{type,touchPoints:p?[p]:[]});
 const shot=n=>page.screenshot({path:path.join(OUT,mode+'-'+String(++serial).padStart(2,'0')+'-'+n+'.png')});
 const note=(event,more={})=>{const row={t:secs(),event,...more};log.push(row);console.log(mode,JSON.stringify(row));};
 const read=()=>page.evaluate(()=>({wood:S.factory.inventory.wood,stone:S.factory.inventory.stone,ground:S.factory.drops.length,blown:S.tutorial?.blownWood||0,delivered:S.factory.delivered,lesson:document.body.dataset.lesson,blowers:S.camp.blowers.length,fences:S.camp.fences.length,phase:S.outpost.phase,carry:S.harvestSkills.carry}));
 const screen=p=>page.evaluate(p=>{const r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return{x:r.left+p.x*z,y:r.top+p.y*z};},p);
 const tap=async(q,hold=60)=>{inputs++;if(touch){await touchEvent('touchStart',q);await page.waitForTimeout(hold);await touchEvent('touchEnd');}else await page.mouse.click(q.x,q.y);await page.waitForTimeout(120);};
 const press=async sel=>{for(let i=0;;i++){try{const el=page.locator(sel).first();await el.waitFor({state:'visible',timeout:3000});await el.scrollIntoViewIfNeeded({timeout:1000});const b=await el.boundingBox();if(b){await tap({x:b.x+b.width/2,y:b.y+b.height/2});return;}}catch(e){if(i>=5)throw e;}await page.waitForTimeout(150);}};
 const drag=async(a,z,steps=12)=>{inputs++;if(touch){await touchEvent('touchStart',a);for(let i=1;i<=steps;i++){await touchEvent('touchMove',{x:a.x+(z.x-a.x)*i/steps,y:a.y+(z.y-a.y)*i/steps});await page.waitForTimeout(16);}await touchEvent('touchEnd');}else{await page.mouse.move(a.x,a.y);await page.mouse.down();await page.mouse.move(z.x,z.y,{steps});await page.mouse.up();}await page.waitForTimeout(140);};
 const field=()=>page.locator('#field').scrollIntoViewIfNeeded();
 const nodeAt=type=>page.evaluate(type=>{const n=S.factory.nodes.filter(n=>n.type===type&&n.stock>0).sort((a,b)=>a.x-b.x)[0],r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return{x:r.left+n.x*z,y:r.top+(n.y-(type==='wood'?48:24))*z};},type);
 const groundCount=type=>page.evaluate(type=>S.factory.drops.filter(d=>d.type===type&&!d.onConveyor&&!SupplyFactory.isAirborne(d)).length,type);
 const harvest=async(type,n)=>{await field();for(let i=0;i<500;i++){if(await groundCount(type)>=n)return;if(await page.evaluate(()=>S.factory.drops.length>=SupplyFactory.stats.groundCapacity))return;await tap(await nodeAt(type),40);}throw new Error('harvest stuck');};
 const pile=type=>page.evaluate(type=>{const r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale,at=d=>{const b=SupplyFactory.pileBounds(d);return{x:r.left+(b.left+b.right)*.5*z,y:r.top+(b.top+b.bottom)*.5*z};};/* only pieces the player can see and grab (not under a card) */const d=S.factory.drops.filter(d=>d.type===type&&!d.onConveyor&&!SupplyFactory.isAirborne(d)).filter(d=>{const q=at(d),el=document.elementFromPoint(q.x,q.y);return el&&el.closest('#field')&&!el.closest('#campWarehouse,#raidBoard,#cameraTools,#campaignGoal,#beltActions');}).sort((a,b)=>a.x-b.x)[0];return d?at(d):null;},type);
 const deliver=async type=>{await field();for(let i=0;i<80;i++){const p=await pile(type);if(!p)return;await drag(p,await screen({x:100,y:290}));carries++;}};
 const need=async(type,amount)=>{for(let k=0;k<20;k++){const r=await read();const have=r[type];if(have>=amount)return;await harvest(type,Math.min(10,amount-have));await deliver(type);}throw new Error('could not gather '+type);};
 const lesson=()=>page.evaluate(()=>document.body.dataset.lesson);
 const waitLesson=(id,timeout=8000)=>page.waitForFunction(id=>document.body.dataset.lesson===id,id,{timeout}).catch(async()=>{throw new Error('lesson '+(await lesson())+' instead of '+id);});
 const learn=async()=>{await press('#onboardingAction');await page.waitForTimeout(400);await press('[data-harvest-learn]:not([disabled])');await page.keyboard.press('Escape').catch(()=>{});if(touch)await page.evaluate(()=>window.Rework?.close?.());await page.waitForTimeout(300);};
 const placeAlly=async(id,filter)=>{await press('[data-recruit="'+id+'"]');await page.waitForFunction(id=>S.pending[id]>0,id);await field();const spot=await page.evaluate(f=>{const spots=BattleControl.spots();return (f?spots.filter(new Function('p','return '+f)):spots)[0];},filter||null);assert.ok(spot,'placement spot for '+id);await drag(await screen(spot),await screen(spot),2);await page.waitForFunction(id=>!S.pending[id],id,{timeout:5000});return spot;};
 const result={mode};
 // One measured window: the preview's verdict for each of the 8 landing spots (read after placing, from the stored
 // shapes) against what each worker log produced in the window actually did (home / stopped / never moved).
 const measure=async(label,landing,seconds)=>{await deliver('wood');const shape=await page.evaluate(l=>{const out=[],ends=[];for(let i=0;i<8;i++){const p=GroundPhysics.workerDropPoint(l,i),r=SupplyFactory.groundPredict(p);out[p.spot]=SupplyFactory.reachesHome(r);ends[p.spot]=[r.status,Math.round(r.end.x),Math.round(r.end.y)];}const direct=[];for(let i=0;i<8;i++){const p=GroundPhysics.workerDropPoint(l,i),r=GroundPhysics.predict({nodes:S.factory.nodes,home:S.factory.depot,blowers:S.camp.blowers,fences:S.camp.fences},p);direct[p.spot]=[r.status,Math.round(r.end.x),Math.round(r.end.y)];}return {out,ends,direct,nodes:S.factory.nodes.map(n=>[n.x,n.y,n.radius,n.type]),depot:S.factory.depot,blowers:S.camp.blowers.map(b=>[b.x,b.y,b.dir]),fences:S.camp.fences.map(f=>[f.a.x,f.a.y,f.b.x,f.b.y])};},landing),pred=shape.out;/* indexed by landing spot, like d.spot */
  const k0=await page.evaluate(()=>S.factory.next),a0=await read();await page.waitForTimeout(seconds*1000);const a1=await read();
  const out=await page.evaluate(k0=>{const last=new Map();for(const e of SupplyFactory.groundEvents)if(e.worker&&e.key>=k0)last.set(e.key,e);for(const d of S.factory.drops)if(d.worker&&d.key>=k0&&!last.has(d.key)&&Number.isInteger(d.spot))last.set(d.key,{key:d.key,spot:d.spot,result:'stayed'});return [...last.values()];},k0);
  const done=out.filter(e=>Number.isInteger(e.spot)),match=done.filter(e=>(e.result==='home')===pred[e.spot]);
  const row={seconds,devices:{blowers:shape.blowers,fences:shape.fences,nodes:shape.nodes,depot:shape.depot},directEnds:shape.direct,predictedEnds:shape.ends,blown:a1.blown-a0.blown,predicted:pred.filter(Boolean).length+' / 8',logs:done.length,home:done.filter(e=>e.result==='home').length,matchesPreview:match.length+' / '+done.length,mismatches:done.filter(e=>!match.includes(e)).map(e=>({spot:e.spot,predicted:pred[e.spot],actual:e.result,x:e.x,y:e.y})),leftOnGround:a1.ground};note(label,row);return row;};
 try{
  await page.goto(URL);await page.waitForTimeout(1200);await press('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);await page.waitForTimeout(400);
  assert.deepEqual(await page.evaluate(()=>[...document.querySelectorAll('[data-equipment]')].map(b=>[b.dataset.equipment,b.disabled])),[['blower',false],['fence',false],['belt',true],['hopper',true],['platform',true]]);note('catalogue: blower/fence open, conveyor locked');
  await need('wood',10);await waitLesson('carry1');note('gather10 done',{carries});await learn();await waitLesson('worker');note('carry1 learned');
  const cost=await page.evaluate(()=>OutpostCore.recipe('woodcutter',0,1));await need('wood',cost.wood);
  // A far landing point on purpose (right of tree 1, about 265px from the house). The near left spots blow home ~100%.
  const spot=await placeAlly('woodcutter',SPOT==='tree1-right'?'p.x>300&&p.x<380&&p.y>290':SPOT==='tree1-left'?'p.x<260':'true');
  const landing=await page.evaluate(spot=>{const n=SupplyFactory.nearby(spot,'wood');return SupplyFactory.outputForWorker(spot,n);},spot);note('woodcutter placed',{spot,landing});
  await waitLesson('workerDrop');await page.waitForFunction(()=>S.factory.drops.some(d=>d.worker),null,{timeout:12000});await page.waitForTimeout(500);await deliver('wood');await page.waitForFunction(()=>document.body.dataset.lesson==='blower',null,{timeout:15000});note('workerDrop done',{carries});
  await need('wood',4);
  // Blower: the player reads the preview (share of the 8 landing spots that reach the house) while trying spots.
  const plan=await page.evaluate(l=>{let best=null;for(let dx=-10;dx<=110;dx+=6)for(let dy=-70;dy<=70;dy+=6)for(let dir=0;dir<8;dir++){const p={x:Math.round(l.x+dx),y:Math.round(l.y+dy)};if(!OutpostCamp.canPlaceBlower(p))continue;const draft={kind:'blower',...p,dir};let home=0;for(let i=0;i<8;i++){if(SupplyFactory.reachesHome(SupplyFactory.groundPredict(GroundPhysics.workerDropPoint(l,i),draft)))home++;}if(!best||home>best.home)best={...p,dir,home};}return best;},landing);
  note('blower plan from the preview',plan);assert.ok(plan&&plan.home>0,'a blower spot that blows logs home exists');
  await press('[data-equipment="blower"]');await page.waitForTimeout(250);let turns=0;while(await page.evaluate(()=>OutpostCamp.blowerDir)!==plan.dir&&turns<8){await press('[data-rail-action="rotate"]');turns++;}
  await field();await shot('blower-preview');await tap(await screen(plan));await page.waitForTimeout(300);let r=await read();assert.equal(r.blowers,1);await waitLesson('blowerDeliver');note('blower placed',{turns,wood:r.wood});await shot('blower-placed');
  await page.waitForFunction(()=>(S.tutorial?.blownWood||0)>0,null,{timeout:40000});await waitLesson('fence');note('first blown log arrived',{fx:await page.evaluate(()=>OutpostCamp.groundFx)});
  // Six quick presses on the blower body: each must register, and the strong wind must reach its 5 s limit.
  await field();const bq=await screen(plan);const before=await page.evaluate(()=>S.camp.blowers[0].boostUntil||0);for(let i=0;i<6;i++){inputs++;if(touch){await touchEvent('touchStart',bq);await page.waitForTimeout(40);await touchEvent('touchEnd');}else await page.mouse.click(bq.x,bq.y);await page.waitForTimeout(70);}
  const gust=await page.evaluate(()=>{const b=S.camp.blowers[0];return {left:+(b.boostUntil-S.factory.time).toFixed(2),full:b.full===true,step:b.gustStep||0,selection:OutpostCamp.selection};});result.sixTaps=gust;note('six taps on the blower',gust);assert.ok(gust.left>4.5&&gust.full,'six taps reach the 5 s limit');assert.equal(gust.selection,null);await page.waitForTimeout(5200);
  // Window A: blower only. Clear leftovers by hand first so the ground limit does not stop the woodcutter.
  result.blowerOnly=await measure('window blower only',landing,WINDOW);await shot('window-blower-only');
  await deliver('wood');await need('wood',10);
  // Fences: again chosen from the preview, then drawn with a visible drag.
  const fences=[];for(let k=0;k<2;k++){const f=await page.evaluate(({l,h})=>{const share=draft=>{let n=0;for(let i=0;i<8;i++){const r=SupplyFactory.groundPredict(GroundPhysics.workerDropPoint(l,i),draft);if(r&&r.status==='warehouse')n++;}return n;},base=share(null);let best=null;for(let x=120;x<=l.x+40;x+=16)for(let y=l.y-90;y<=l.y+90;y+=16)for(let k=0;k<8;k++)for(const len of [48,72,96]){const a={x,y},b={x:x+Math.cos(k*Math.PI/8)*len,y:y+Math.sin(k*Math.PI/8)*len},d={kind:'fence',a,b};if(!OutpostCamp.canPlaceFence(d))continue;const n=share(d);if(n>base&&(!best||n>best.home||n===best.home&&len<best.len))best={a,b,home:n,len,base};}return best;},{l:landing,h:{x:100,y:340}});
   if(!f)break;fences.push(f);await press('[data-equipment="fence"]');await page.waitForTimeout(250);await field();await drag(await screen(f.a),await screen(f.b),10);await page.waitForTimeout(300);note('fence placed',f);}
  r=await read();result.fences=r.fences;if(r.fences)await page.waitForFunction(()=>document.body.dataset.lesson!=='fence',null,{timeout:8000});await shot('fences');
  result.withFences=await measure('window blower+fences',landing,WINDOW);await shot('window-with-fences');
  // Rest of the lesson: basket, archers, Ready.
  await deliver('wood');await page.waitForTimeout(600);if(await lesson()==='gather30'){await need('wood',30);}await waitLesson('carry2');await learn();await waitLesson('defenders');note('carry2 learned',{carries});
  for(let i=0;i<2;i++){const c=await page.evaluate(()=>OutpostCore.recipe('arch',S.owned.arch||0,1));await need('stone',c.stone);await need('wood',c.wood);await placeAlly('arch','p.y<300');note('archer placed',{n:i+1});}
  await page.waitForFunction(()=>document.body.dataset.lesson==='ready',null,{timeout:5000});result.readyAt=secs();await press('#onboardingAction');note('ready pressed');
  await page.waitForFunction(()=>S.outpost.phase==='active',null,{timeout:120000});result.raidAt=secs();note('first raid started');await shot('first-raid');
  await page.waitForFunction(()=>S.outpost.phase!=='active',null,{timeout:240000}).catch(()=>{});result.raidResult=await page.evaluate(()=>({phase:S.outpost.phase,cleared:S.outpost.cleared,win:S.outpost.result?.win??null}));note('first raid result',result.raidResult);
  r=await read();Object.assign(result,{status:'passed',seconds:secs(),manualCarries:carries,inputs,blowers:r.blowers,fences:r.fences,errors});assert.deepEqual(errors,[]);return result;
 }catch(e){await shot('FAIL').catch(()=>{});return {...result,status:'failed',message:e.stack,errors,log,seconds:secs(),manualCarries:carries};}finally{fs.writeFileSync(path.join(OUT,mode+'-log.json'),JSON.stringify(log,null,1));await ctx.close();}
}
(async()=>{const browser=await chromium.launch();const results=[];try{for(const m of MODES)results.push(await run(browser,m));}finally{await browser.close();}
 fs.writeFileSync(path.join(OUT,'result.json'),JSON.stringify({fixture:'Fresh ?lesson=1 save, visible inputs only; touch is CDP touch, not a real device; spot '+SPOT,results},null,2));console.log(JSON.stringify(results,null,1));if(results.some(r=>r.status!=='passed'))process.exitCode=1;})();
