// Real fresh-save gameplay capture. Reads state to locate objects; never grants resources.
const {chromium}=require('playwright'),fs=require('node:fs'),assert=require('node:assert/strict'),{execFileSync}=require('node:child_process');
const recordVideo=require('./record_browser_clip.cjs'),audio=require('./record_browser_audio.cjs');
const output=process.env.CAPTURE_DIR||'/workspace/scratch',url=process.env.GAME_URL||'http://127.0.0.1:4182/preview/';
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true});let stopAudio,stopVideo;
 try{
  const context=await browser.newContext({viewport:{width:1280,height:900}});await audio.install(context);
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto(url);await page.click('#titleBattle');await page.waitForFunction(()=>SupplyFactory.artReady);await page.waitForTimeout(1200);
  assert.equal(await page.evaluate(()=>ArmyView.sim.soldiers.length),0);
  stopAudio=await audio.start(page);stopVideo=await recordVideo(page,output+'/review4-harvest-silent.mp4');
  async function hitWood(){const q=await page.evaluate(()=>{const n=S.factory.nodes.filter(n=>n.type==='wood').sort((a,b)=>Math.hypot(a.x-S.factory.depot.x,a.y-S.factory.depot.y)-Math.hypot(b.x-S.factory.depot.x,b.y-S.factory.depot.y))[0],r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return {x:r.left+n.x*z,y:r.top+(n.y-30)*z};});await page.mouse.click(q.x,q.y);await page.waitForTimeout(500);}
  async function pickup(){const q=await page.evaluate(()=>{const d=S.factory.drops.find(d=>d.type==='wood');if(!d)throw Error('No real logs');const r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return {x:r.left+d.x*z,y:r.top+d.y*z-12};});await page.mouse.click(q.x,q.y);await page.waitForTimeout(1000);}
  async function hire(){await page.click('[data-recruit="woodcutter"]');await page.waitForTimeout(900);const q=await page.evaluate(()=>{const s=BattleControl.spots()[0],r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;if(!s)throw Error('No visible placement spot');return {x:r.left+s.x*z,y:r.top+s.y*z};});await page.mouse.move(q.x,q.y);await page.waitForTimeout(700);await page.mouse.click(q.x,q.y);await page.waitForTimeout(1200);}
  await page.waitForTimeout(800);await hitWood();await hitWood();await hitWood();await page.waitForTimeout(600);
  await page.screenshot({path:output+'/review4-ground-desktop.png'});await pickup();await hire();
  await page.waitForFunction(()=>S.factory.drops.some(d=>d.worker),null,{timeout:6000});await page.waitForTimeout(3200);
  await page.screenshot({path:output+'/review4-worker-desktop.png'});await pickup();
  while(await page.evaluate(()=>S.factory.inventory.wood)<3)await hitWoodAndPickup();
  await hire();await page.waitForTimeout(4200);
  assert.equal(await page.evaluate(()=>ArmyView.sim.soldiers.length),2);
  await page.screenshot({path:output+'/review4-two-workers.png'});
  const a=await stopAudio(output+'/review4-harvest-audio.webm');stopAudio=null;const v=await stopVideo();stopVideo=null;
  assert.ok(v.seconds>15);const offset=Math.max(0,(v.startedAt-a.startedAt)/1000);
  execFileSync('ffmpeg',['-hide_banner','-loglevel','error','-y','-i',v.file,'-ss',String(offset),'-i',a.file,'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','160k','-shortest','-movflags','+faststart',output+'/review4-harvest-with-audio.mp4']);
  const sounds=await page.evaluate(()=>ForestAudio.stats.sounds);for(const k of ['wood','pickup','hire','place'])assert.ok(sounds.includes(k));
  const materials=await page.evaluate(()=>S.factory.drops.reduce((n,d)=>n+d.count,0));
  await page.setViewportSize({width:390,height:844});await page.waitForTimeout(1500);await page.screenshot({path:output+'/review4-harvest-mobile.png'});
  const overlaps=await page.evaluate(()=>{const z=ArmyView.camera.scale,drops=S.factory.drops,people=ArmyView.sim.soldiers;return drops.flatMap((d,i)=>[
   ...people.filter(p=>Math.abs(d.x-p.x)<42/z+20&&d.y>p.y-60&&d.y-58/z<p.y+8).map(p=>'pile '+i+' / '+p.key),
   ...drops.slice(i+1).filter(q=>Math.abs(d.x-q.x)<84/z&&Math.abs(d.y-q.y)<58/z+8).map(q=>'pile '+i+' / '+q.id)
  ]);});assert.deepEqual(overlaps,[],'responsive pile labels must not cover people or each other');
  assert.ok(await page.evaluate(n=>S.factory.drops.reduce((total,d)=>total+d.count,0)>=n,materials),'responsive layout retains all ground resources');
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);assert.deepEqual(errors,[]);
  const metadata={seconds:v.seconds,video:'actual Chromium screencast, 20 fps',audio:'actual game BGM and Web Audio output, Opus capture encoded as AAC',audioOffsetSeconds:offset,progress:'fresh save: chop 3 logs, collect, place first worker, collect its output, recruit and place second worker',stateGrants:false,errors,sounds};
  fs.writeFileSync(output+'/review4-harvest.json',JSON.stringify(metadata,null,2));console.log(metadata);
  async function hitWoodAndPickup(){await hitWood();await pickup();}
 }finally{if(stopVideo)await stopVideo();if(stopAudio)await stopAudio(output+'/review4-partial-audio.webm');await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
