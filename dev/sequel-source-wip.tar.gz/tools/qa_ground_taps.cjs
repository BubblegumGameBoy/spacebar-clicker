/* M3 review fixes, prepared tests (state set with evaluate, then visible inputs), PC mouse and CDP touch:
   1 a log beside the blower: a tap still gives strong wind, a hold still selects
   5 a blower beside a tree on the zoomed-out phone: the tap is wind, not a harvest
   7 a blower over an ally: the tap is wind, not the ally placement
   4 a log held against the field edge by the wind: no save every second
   2 a dead-end belt under a landing spot is not counted as delivered by the preview */
'use strict';
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const URL=(process.env.GAME_URL||'http://127.0.0.1:4422/preview/')+'?lab=1',OUT=process.env.QA_OUT||'/tmp/qa-ground-taps';fs.mkdirSync(OUT,{recursive:true});
async function fresh(browser,phone){const ctx=await browser.newContext(phone?{viewport:{width:390,height:844},hasTouch:true,isMobile:true,deviceScaleFactor:2}:{viewport:{width:1280,height:900}}),page=await ctx.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(URL);await page.waitForTimeout(1000);if(await page.locator('#titleBattle').isVisible())await page.click('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);await page.waitForTimeout(400);await page.locator('#field').scrollIntoViewIfNeeded();
 const cdp=phone?await ctx.newCDPSession(page):null,screen=p=>page.evaluate(p=>{const r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return{x:r.left+p.x*z,y:r.top+p.y*z};},p);
 const tap=async(p,hold=50)=>{const q=await screen(p);if(phone){await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[q]});await page.waitForTimeout(hold);await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});}else if(hold>400){await page.mouse.click(q.x,q.y,{button:'right'});}else await page.mouse.click(q.x,q.y);await page.waitForTimeout(250);};
 return {ctx,page,errors,tap};}
const state=page=>page.evaluate(()=>({boost:S.camp.blowers[0]?+(S.camp.blowers[0].boostUntil-S.factory.time).toFixed(2):null,selection:OutpostCamp.selection,stock:S.factory.nodes[0].stock,drops:S.factory.drops.length,placement:BattleControl.placement}));
(async()=>{const browser=await chromium.launch(),results=[];try{for(const phone of [false,true]){const mode=phone?'touch':'pc',checks=[];
 let {ctx,page,errors,tap}=await fresh(browser,phone);
 await page.evaluate(()=>{for(const w of ArmyView.sim.soldiers)w.cooldown=1e9;S.factory.drops.length=0;S.camp.blowers.push({key:1,x:420,y:440,dir:4,costWood:4});const d=SupplyCore.drop(S.factory,'wood',1,450,446,1,240);d.physical=true;});
 await tap({x:420,y:440});let r=await state(page);assert.ok(r.boost>2.5,'log beside the blower: tap is strong wind');assert.equal(r.selection,null);
 await tap({x:420,y:440},650);r=await state(page);assert.equal(r.selection?.kind,'blower','hold / right-click selects');checks.push('1 log beside the blower: tap = wind ('+r.boost+'s), hold = selection');await page.keyboard.press('Escape');
 const ok=await page.evaluate(()=>{S.camp.blowers.length=0;S.factory.drops.length=0;const ok=OutpostCamp.canPlaceBlower({x:336,y:290});S.camp.blowers.push({key:2,x:336,y:290,dir:4,costWood:4});return ok;});
 await tap({x:336,y:290});r=await state(page);assert.ok(r.boost>2.5);assert.equal(r.stock,300,'no harvest');assert.equal(r.drops,0);checks.push('5 blower beside a tree (placeable here: '+ok+', same on every zoom): tap = wind, tree untouched');
 await ctx.close();({ctx,page,errors,tap}=await fresh(browser,phone));
 await page.evaluate(()=>{S.factory.inventory.wood=30;});await page.locator('[data-recruit="woodcutter"]').click();await page.waitForFunction(()=>S.pending.woodcutter>0);const spot=await page.evaluate(()=>BattleControl.spots()[0]);await page.locator('#field').scrollIntoViewIfNeeded();await tap(spot);await page.waitForFunction(()=>!S.pending.woodcutter);
 const body=await page.evaluate(()=>{const p=ArmyView.sim.soldiers.find(p=>p.id==='woodcutter');S.camp.blowers.push({key:3,x:Math.round(p.x),y:Math.round(p.y-8),dir:4,costWood:4});return {x:Math.round(p.x),y:Math.round(p.y-8)};});
 await tap(body);r=await state(page);assert.equal(r.placement,false,'ally placement not opened');assert.ok(r.boost>2.5);checks.push('7 blower over an ally: tap = wind, ally placement stays closed');
 await page.evaluate(()=>{for(const w of ArmyView.sim.soldiers)w.cooldown=1e9;S.camp.blowers.length=0;S.factory.drops.length=0;S.camp.blowers.push({key:4,x:880,y:200,dir:0,costWood:4});const d=SupplyCore.drop(S.factory,'wood',1,900,200,1,240);d.physical=true;d.vx=1;window.__sets=0;const o=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){window.__sets++;return o.call(this,k,v);};});
 await page.waitForTimeout(10000);const sets=await page.evaluate(()=>({sets:__sets,d:S.factory.drops.map(d=>[d.x,d.y,d.vx,d.vy])}));assert.ok(sets.sets<=3,'saves in 10 s: '+sets.sets);checks.push('4 log pinned at the field edge: '+sets.sets+' saves in 10 s, at rest '+JSON.stringify(sets.d));
 const share=await page.evaluate(()=>{S.camp.blowers.length=0;S.camp.links.push({nodeKey:9,type:'wood',kind:'conveyor',points:[{x:600,y:470},{x:700,y:470}],costWood:5});S.camp.blowers.push({key:5,x:610,y:410,dir:1,costWood:4});const r=SupplyFactory.groundPredict({x:640,y:440});return {status:r.status,home:SupplyFactory.reachesHome(r)};});
 assert.equal(share.status,'belt');assert.equal(share.home,false);checks.push('2 dead-end belt: preview reaches '+share.status+' but counts as not home');
 assert.deepEqual(errors,[]);results.push({mode,status:'passed',checks});await ctx.close();}}
 catch(e){results.push({status:'failed',message:e.stack});}finally{await browser.close();}
 fs.writeFileSync(path.join(OUT,'result.json'),JSON.stringify({fixture:'Prepared states via evaluate, then visible taps; touch is CDP touch',results},null,2));console.log(JSON.stringify(results,null,1));if(results.some(r=>r.status!=='passed')||results.length<2)process.exitCode=1;})();
