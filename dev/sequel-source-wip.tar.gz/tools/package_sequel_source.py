"""Save editable sequel sources, tests and tools to both matching private-source archives."""
from pathlib import Path
import hashlib
import shutil
import tarfile

root = Path(__file__).resolve().parent.parent
archive = root / 'dev/sequel-source.tar.gz'
files = []
for folder in ('2', 'test', 'tools'):
    for file in sorted((root / folder).rglob('*')):
        if file.is_symlink():
            raise SystemExit(f'Refusing symbolic link: {file}')
        if file.is_file() and '__pycache__' not in file.parts and file.suffix != '.pyc':
            if any(word in file.name.lower() for word in ('private', 'checkpoint', 'storage-state', 'actions.json')):
                raise SystemExit(f'Refusing private QA artifact: {file}')
            files.append(file)
with tarfile.open(archive, 'w:gz') as bundle:
    for file in files:
        bundle.add(file, arcname=file.relative_to(root).as_posix(), recursive=False)
wip = root / 'dev/sequel-source-wip.tar.gz'
shutil.copyfile(archive, wip)
assert archive.read_bytes() == wip.read_bytes()
with tarfile.open(archive) as bundle:
    assert len(bundle.getmembers()) == len(files)
    for member in bundle:
        assert member.isfile()
        assert bundle.extractfile(member).read() == (root / member.name).read_bytes(), member.name
print(f'{len(files)} files verified; both archives match; SHA256 {hashlib.sha256(archive.read_bytes()).hexdigest()}')
