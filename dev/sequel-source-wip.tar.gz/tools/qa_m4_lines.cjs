/* M4 real play, part 2: continue the save earned in qa_m4_journey (Chapter 1 just cleared) with visible inputs.
   Each condition starts from that same save in a fresh browser context, hires a second lumberjack (tree 2), sets up
   its transport, and then measures the time to bring 100 wood home with the same player policy:
     tap tree 1 four times, then carry every loose log that is still on the ground to the house, repeat.
   Conditions:
     hand     - hand carrying only. The lesson's blower and fences are removed first with the board's own
                selection card (right-click / long-press -> Remove): visible inputs, but a deliberate handicap.
     tools    - the lesson's blower + fences as earned (no conveyor, no hopper).
     conveyor - blower + fences, plus two lines built here: a hopper at each lumberjack's landing spot and wooden
                belts (240 max each, joined) to the house. The spots are chosen from the board preview.
   QA_MODE=touch runs the setup with CDP touch (390x844, not a real device) and skips the long measurement.
   evaluate() only reads. Output OUT/lines-<mode>.json and screenshots. */
'use strict';
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const BASE=process.env.GAME_URL||'http://127.0.0.1:4451/preview/',URL=BASE+(BASE.includes('?')?'&':'?')+'lesson=1',OUT=process.env.QA_OUT||'/tmp/qa-m4-lines',SAVE=process.env.QA_SAVE||path.join(OUT,'..','journey','wave3-earned.json');fs.mkdirSync(OUT,{recursive:true});
const MODE=process.env.QA_MODE||'pc',PACE=process.env.QA_PACE||'bot',CONDITIONS=(process.env.QA_CONDITIONS||(MODE==='touch'?'conveyor':'conveyor,tools,hand')).split(','),TARGET=Number(process.env.QA_TARGET||100),LIMIT=Number(process.env.QA_LIMIT||900);
const helpers=require('./qa_m4_helpers.cjs');
async function run(browser,condition){
 const touch=MODE==='touch',ctx=await browser.newContext({...(touch?{viewport:{width:390,height:844},hasTouch:true,isMobile:true,deviceScaleFactor:2}:{viewport:{width:1280,height:900}}),storageState:SAVE});await ctx.addInitScript(helpers.cueCounter);
 const page=await ctx.newPage(),cdp=touch?await ctx.newCDPSession(page):null,h=helpers.make(page,{touch,cdp,out:OUT,tag:MODE+'-'+condition,pace:PACE}),row={condition,mode:MODE};
 const pickRemove=async(kind,p)=>{await h.field();const q=await h.screen(p);if(touch){await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[q]});await page.waitForTimeout(700);await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});}else{await page.mouse.click(q.x,q.y,{button:'right'});}await page.waitForTimeout(250);const sel=await page.evaluate(()=>OutpostCamp.selection);if(!sel||sel.kind!==kind){if(!touch||kind!=='fence')return false;await h.tap(q);if((await page.evaluate(()=>OutpostCamp.selection))?.kind!==kind)return false;}await h.press('[data-pick-action="remove"]');await page.waitForTimeout(200);return true;};
 try{
  await page.goto(URL);await page.waitForTimeout(1200);if(await page.locator('#titleBattle').isVisible())await h.press('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);await page.waitForTimeout(600);
  for(let i=0;i<6&&(await h.read()).paused;i++){await page.keyboard.press('Escape');await page.waitForTimeout(300);}
  row.start=await h.read();assert.ok(row.start.cleared>=3,'the earned save has Chapter 1 cleared');assert.deepEqual(await h.cards(),[['blower',false],['fence',false],['belt',false],['hopper',false],['platform',false]]);
  // Second lumberjack at tree 2 (earned wood), the same in every condition.
  const c=await page.evaluate(()=>OutpostCore.recipe('woodcutter',S.owned.woodcutter||0,1));await h.need('wood',c.wood);if(c.stone)await h.need('stone',c.stone);
  // right of tree 2: about 450 from the house, where M3 noted one blower delivers 0%
  const spot2=await h.placeAlly('woodcutter','p.x>500&&p.y>290');const landing2=await page.evaluate(s=>SupplyFactory.outputForWorker(s,SupplyFactory.nearby(s,'wood')),spot2);
  const landing1=await page.evaluate(()=>{const p=ArmyView.sim.soldiers.filter(p=>p.id==='woodcutter').sort((a,b)=>a.x-b.x)[0];return SupplyFactory.outputForWorker(p,SupplyFactory.nearby(p,'wood'));});
  h.note('second lumberjack',{spot2,landing1,landing2});row.landing={one:landing1,two:landing2};
  if(condition==='hand'){
   for(const b of await page.evaluate(()=>S.camp.blowers.map(b=>({x:b.x,y:b.y}))))assert.ok(await pickRemove('blower',b),'blower removed');
   // A fence beside a tree can sit inside the tree's tap area (a tap there harvests): then try along it, and
   // finally the workshop list (house label -> the fence's remove row), which is the other visible way.
   for(const f of await page.evaluate(()=>S.camp.fences.map(f=>({key:f.key,a:f.a,b:f.b})))){let ok=false;for(const t of [.5,.3,.7,.15,.85]){if(await pickRemove('fence',{x:f.a.x+(f.b.x-f.a.x)*t,y:f.a.y+(f.b.y-f.a.y)*t})){ok=true;break;}}
    if(!ok){await h.press('.camp-house-label');await page.waitForTimeout(300);await h.press('[data-device-remove="fence:'+f.key+'"]');await page.waitForTimeout(200);await page.keyboard.press('Escape');ok=!(await page.evaluate(k=>S.camp.fences.some(f=>f.key===k),f.key));h.note('fence removed from the workshop list',{key:f.key});}assert.ok(ok,'fence removed');}
   const r=await h.read();assert.equal(r.blowers+r.fences,0);h.note('blower and fences removed with the board card');
  }
  if(condition==='conveyor'){
   row.lines=[];
   // Line A: a belt from the house port toward tree 1's landing spot; past 240 the board stops it, so a second belt
   // starts from the end handle. A hopper then sits behind the landing spots with its outlet on the belt tail.
   const plan=(l,joinTo)=>page.evaluate(({l,joinTo})=>{const C=ConveyorCore,P=GroundPhysics.PARAMS,spots=Array.from({length:8},(_,i)=>GroundPhysics.workerDropPoint(l,i));
    let best=null;for(let dx=-30;dx<=50;dx+=4)for(let dy=-40;dy<=40;dy+=4){const h={x:Math.round(l.x+dx),y:Math.round(l.y+dy),dir:4};if(!OutpostCamp.canPlaceHopper(h))continue;const w=GroundPhysics.normalizeWorld({hoppers:[h]});const caught=spots.filter(s=>GroundPhysics.hopperAt(w,s)===0).length;const out=GroundPhysics.hopperOutlet(h);const score=caught*100-Math.hypot(out.x-100,out.y-340)/10;if(!best||score>best.score)best={...h,caught,out:{x:out.x,y:out.y},score};}return best;},{l,joinTo});
   const port={x:162,y:328};
   const lay=async(from,to)=>{await h.press('[data-equipment="belt"]');await page.waitForTimeout(250);await h.field();const before=(await h.read()).links;await h.drag(await h.screen(from),await h.screen(to),18);await page.waitForTimeout(300);const after=await page.evaluate(()=>S.camp.links.map(l=>({key:l.nodeKey,len:Math.round(ConveyorCore.length(l.points)),head:l.points[0],tail:l.points.at(-1)})));if(touch)await page.evaluate(()=>0);return {added:after.length-before,belts:after};};
   const hopperAt=async(p)=>{await h.press('[data-equipment="hopper"]');await page.waitForTimeout(250);let turns=0;while(await page.evaluate(()=>OutpostCamp.hopperDir)!==p.dir&&turns<8){await h.press('[data-rail-action="rotate"]');turns++;}await h.field();await h.tap(await h.screen(p));await page.waitForTimeout(300);return (await h.read()).hoppers;};
   const a=await plan(landing1);h.note('hopper A plan',a);await h.need('wood',30);await h.need('stone',8);
   let b1=await lay(port,a.out);h.note('belt A1',b1);if(b1.belts.at(-1).len>=239.5){const end=b1.belts.at(-1).tail;row.capped=true;await h.shot('belt-capped');const b2=await lay(end,a.out);h.note('belt A2 joined at the end',b2);}
   assert.ok(await hopperAt(a)>=1,'hopper A placed');await h.shot('line-a');
   const share=async l=>page.evaluate(l=>{let n=0;for(let i=0;i<8;i++){if(SupplyFactory.reachesHome(SupplyFactory.groundPredict(GroundPhysics.workerDropPoint(l,i))))n++;}return n;},l);
   row.lines.push({line:'A',hopper:a,predicted:await share(landing1)});
   // Line B: tree 2 (far). A belt starts on line A (snaps onto it) toward tree 2's landing spot; the board stops it at
   // 240, and a second belt continues from its end handle. Then the hopper.
   const b=await plan(landing2);h.note('hopper B plan',b);await h.need('wood',16);await h.need('stone',4);
   const join=await page.evaluate(()=>{const ps=ConveyorCore.oriented(S.camp.links[0]);return ConveyorCore.at(ps,ConveyorCore.length(ps)*.55);});
   let bb=await lay(join,b.out);h.note('belt B',bb);if(bb.belts.at(-1).len>=239.5){const b2=await lay(bb.belts.at(-1).tail,b.out);h.note('belt B2',b2);}
   assert.ok(await hopperAt(b)>=2,'hopper B placed');await h.shot('line-b');row.lines.push({line:'B',hopper:b,predicted:await share(landing2)});
   row.layout=await page.evaluate(()=>({belts:S.camp.links.map(l=>({key:l.nodeKey,len:Math.round(ConveyorCore.length(l.points)),cost:l.costWood})),hoppers:S.camp.hoppers,blowers:S.camp.blowers.length,fences:S.camp.fences.length}));
   h.note('lines built',row.layout);assert.ok(row.layout.belts.every(b=>b.len<=240.5),'every new belt is at most 240');
   // the hand-harvest spots of tree 1 too
   row.handSpots=await page.evaluate(()=>{const n=S.factory.nodes.find(n=>n.type==='wood'&&n.x<300);let k=0;for(let i=0;i<4;i++)if(SupplyFactory.reachesHome(SupplyFactory.groundPredict(GroundPhysics.handDropPoint(n,i))))k++;return k+' / 4';});
  }
  await h.deliver('wood');await h.field();await h.shot('setup');row.setup=await h.read();row.setupAt=h.secs();
  if(touch&&!process.env.QA_MEASURE){Object.assign(row,{status:'passed',errors:h.errors});assert.deepEqual(h.errors,[]);return row;}
  // Measurement: same policy in every condition.
  const w0=(await h.read()).wood,t0=Date.now(),c0={...h.counts};let samples=[];
  while(true){const r=await h.read();const got=r.wood-w0,el=(Date.now()-t0)/1000;if(samples.length===0||el-samples.at(-1).t>=15)samples.push({t:+el.toFixed(1),wood:got,ground:r.ground});if(got>=TARGET)break;if(el>LIMIT)throw new Error('limit: '+got+' wood in '+LIMIT+' s');if(r.phase==='active'){await h.assistRaid();continue;}if(r.paused){await page.keyboard.press('Escape');continue;}
   await h.tapTree(4,await page.evaluate(()=>S.factory.nodes.find(n=>n.type==='wood'&&n.x<300&&n.stock>0)?.key??null));await h.deliver('wood',20);}
  const el=(Date.now()-t0)/1000;row.measure={target:TARGET,seconds:+el.toFixed(1),taps:h.counts.taps-c0.taps,carries:h.counts.carries-c0.carries,inputs:h.counts.inputs-c0.inputs,samples,end:await h.read()};h.note('measured',row.measure);await h.shot('measured');
  Object.assign(row,{status:'passed',errors:h.errors});assert.deepEqual(h.errors,[]);return row;
 }catch(e){await h.shot('FAIL').catch(()=>{});return {...row,status:'failed',message:e.stack,errors:h.errors,log:h.log};}finally{row.log=h.log;await ctx.close();}
}
(async()=>{const browser=await chromium.launch();const results=[];try{for(const c of CONDITIONS)results.push(await run(browser,c));}finally{await browser.close();}
 fs.writeFileSync(path.join(OUT,'lines-'+MODE+'-'+PACE+'.json'),JSON.stringify({fixture:'Save earned by qa_m4_journey (fresh ?lesson=1, visible play to Chapter 1); each condition from that save; '+(MODE==='touch'?'CDP touch (not a real device)':'PC mouse')+', pace '+PACE,results},null,1));
 console.log(JSON.stringify(results.map(r=>({...r,log:undefined})),null,1));if(results.some(r=>r.status!=='passed'))process.exitCode=1;})();
