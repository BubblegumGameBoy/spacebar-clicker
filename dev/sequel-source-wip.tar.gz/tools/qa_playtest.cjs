process.env.GAME_URL ||= (process.env.PLAYTEST_ORIGIN||'http://127.0.0.1:4181')+'/preview/';
require('./qa_forest.cjs');
