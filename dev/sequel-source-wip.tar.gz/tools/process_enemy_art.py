"""M6 enemy art: codex 2x2 sheets (assets/_incoming/mob-<id>.png) -> assets/mob-<id>.webp, read like assets/mob-rat.webp.

Layout of every output: 1536x1024, 2x2 cells of 768x512. TL/TR = walk A/B, BL = attack at the gate, BR = defeated.
Per sheet:
  1. Opaque pieces (alpha > 8, 8-connected) are found on the whole sheet and each piece is given to the cell that holds
     most of its alpha. A piece that really straddles two cells is cut at the cell line instead (reported as 'split').
     This keeps a sling, staff glow or flying chip that crosses the generator's cell line with its own pose.
  2. One scale per sheet (never above 1) so every pose fits its 768x512 cell with a 12 px margin; same scale for all four poses.
  3. Each pose is placed so the bottom of its alpha > 48 box sits on the shared baseline y = 441 (the rat sheet's foot line),
     centred on x = 384 of its cell. The game reads each cell's alpha > 72 box, so a pose's feet are its box bottom.
  4. FLIP lists sheets that face right and must be mirrored (none: all 14 were checked to face left; see 2/ENEMY_ART.md).
  5. The composed 1536x1024 sheet is halved to 768x512 (cells 384x256, baseline 220.5) with Lanczos and saved as lossy WebP
     (quality 90, alpha_quality 100, method 6). In-game sprites are 17-120 px, so full resolution only cost download size.
     The game measures each cell's box from the loaded image and scales by the walk-pose height, so size and feet do not move.
mob-mole-burrow is a single image cropped to its alpha > 48 box and halved the same way.
Usage: python3 tools/process_enemy_art.py [--report out.json]"""
from PIL import Image
import os, sys, json
from collections import deque

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'assets')
SHEETS = ['shield', 'bat', 'ooze', 'oozelet', 'mole', 'shaman', 'beetle', 'swarm', 'wisp', 'siegecart', 'slinger', 'toad', 'boar', 'envoy']
FLIP = set()
CELL_W, CELL_H, BASELINE, MARGIN = 768, 512, 441, 12
OUTPUT_SCALE, QUALITY = 0.5, 90


def save(img, path):
    if OUTPUT_SCALE != 1:
        img = img.resize((round(img.width * OUTPUT_SCALE), round(img.height * OUTPUT_SCALE)), Image.LANCZOS)
    img.save(path, 'WEBP', quality=QUALITY, alpha_quality=100, method=6)
    return img


def pieces(alpha, w, h, threshold=8):
    """8-connected components of alpha > threshold. Returns a label list (0 = empty) and piece count."""
    labels = [0] * (w * h)
    n = 0
    for start in range(w * h):
        if labels[start] or alpha[start] <= threshold:
            continue
        n += 1
        labels[start] = n
        queue = deque([start])
        while queue:
            i = queue.popleft()
            x, y = i % w, i // w
            for dy in (-1, 0, 1):
                yy = y + dy
                if yy < 0 or yy >= h:
                    continue
                for dx in (-1, 0, 1):
                    xx = x + dx
                    if xx < 0 or xx >= w:
                        continue
                    j = yy * w + xx
                    if not labels[j] and alpha[j] > threshold:
                        labels[j] = n
                        queue.append(j)
    return labels, n


def cell_of(x, y, w, h):
    return (1 if x >= w // 2 else 0) + (2 if y >= h // 2 else 0)


def process(name):
    src = Image.open(os.path.join(ROOT, '_incoming', 'mob-%s.png' % name)).convert('RGBA')
    if name in FLIP:
        src = src.transpose(Image.FLIP_LEFT_RIGHT)
    w, h = src.size
    channel = src.getchannel('A')
    alpha = list(channel.get_flattened_data() if hasattr(channel, 'get_flattened_data') else channel.getdata())
    labels, n = pieces(alpha, w, h)
    mass = [[0, 0, 0, 0] for _ in range(n + 1)]
    for i, lab in enumerate(labels):
        if lab:
            mass[lab][cell_of(i % w, i // w, w, h)] += alpha[i]
    owner, split = [None] * (n + 1), []
    for lab in range(1, n + 1):
        total = sum(mass[lab])
        best = max(range(4), key=lambda c: mass[lab][c])
        if total and mass[lab][best] < total * 0.9 and total > 255 * 400:
            owner[lab] = 'cut'
            split.append({'piece': lab, 'alpha_by_cell': mass[lab]})
        else:
            owner[lab] = best
    # Separate the four poses onto their own transparent canvases (full sheet size, so coordinates stay the source's).
    layers = [Image.new('RGBA', (w, h), (0, 0, 0, 0)) for _ in range(4)]
    px = src.load()
    lp = [layer.load() for layer in layers]
    moved = [0, 0, 0, 0]
    for i, lab in enumerate(labels):
        if not lab:
            continue
        x, y = i % w, i // w
        c = owner[lab]
        if c == 'cut':
            c = cell_of(x, y, w, h)
        elif c != cell_of(x, y, w, h):
            moved[c] += 1
        lp[c][x, y] = px[x, y]
    boxes = [layer.getchannel('A').point(lambda v: 255 if v > 48 else 0).getbbox() for layer in layers]
    full = [layer.getbbox() for layer in layers]
    # One scale for the whole sheet: every pose (with its faint glow) must fit a cell above/below the baseline.
    scale = 1.0
    for b, f in zip(boxes, full):
        above = b[3] - f[1]            # from the faint top to the opaque bottom
        below = f[3] - b[3]            # faint pixels under the opaque bottom
        scale = min(scale, (BASELINE - MARGIN) / above, (CELL_H - BASELINE - 2) / max(1, below), (CELL_W - 2 * MARGIN) / (f[2] - f[0]))
    out = Image.new('RGBA', (CELL_W * 2, CELL_H * 2), (0, 0, 0, 0))
    frames = []
    for c, (layer, b, f) in enumerate(zip(layers, boxes, full)):
        crop = layer.crop(f)
        if scale < 1:
            crop = crop.resize((max(1, round(crop.width * scale)), max(1, round(crop.height * scale))), Image.LANCZOS)
        cx = (b[0] + b[2]) / 2
        # Position of the opaque box inside the scaled crop.
        ox = (cx - f[0]) * scale
        oy = (b[3] - f[1]) * scale
        dx = round((c % 2) * CELL_W + CELL_W / 2 - ox)
        dy = round((c // 2) * CELL_H + BASELINE - oy)
        dx = max((c % 2) * CELL_W, min((c % 2) * CELL_W + CELL_W - crop.width, dx))
        dy = max((c // 2) * CELL_H, min((c // 2) * CELL_H + CELL_H - crop.height, dy))
        out.alpha_composite(crop, (dx, dy))
        frames.append({'frame': c, 'source_opaque_box': list(b), 'source_full_box': list(f), 'pixels_reassigned_from_neighbour_cell': moved[c], 'placed_at': [dx, dy], 'size': list(crop.size)})
    path = os.path.join(ROOT, 'mob-%s.webp' % name)
    out = save(out, path)
    # Verify on the file as shipped: the game reads alpha > 72 boxes per cell; each must stay inside its cell and end near the baseline.
    check = []
    shipped = Image.open(path).convert('RGBA')
    cw, ch = shipped.width // 2, shipped.height // 2
    a = shipped.getchannel('A').point(lambda v: 255 if v > 72 else 0)
    for c in range(4):
        sx, sy = (c % 2) * cw, (c // 2) * ch
        bb = a.crop((sx, sy, sx + cw, sy + ch)).getbbox()
        check.append(list(bb))
    return {'sheet': name, 'source_size': [w, h], 'output_size': list(shipped.size), 'flipped': name in FLIP, 'scale': round(scale, 4), 'pieces': n, 'cut_pieces': split, 'frames': frames, 'game_boxes_alpha72': check, 'bytes': os.path.getsize(path)}


def burrow():
    im = Image.open(os.path.join(ROOT, '_incoming', 'mob-mole-burrow.png')).convert('RGBA')
    b = im.getchannel('A').point(lambda v: 255 if v > 48 else 0).getbbox()
    crop = im.crop(b)
    path = os.path.join(ROOT, 'mob-mole-burrow.webp')
    crop = save(crop, path)
    return {'sheet': 'mole-burrow', 'source_size': list(im.size), 'opaque_box': list(b), 'size': list(crop.size), 'bytes': os.path.getsize(path)}


if __name__ == '__main__':
    args = sys.argv[1:]
    if '--report' in args:
        i = args.index('--report')
        args = args[:i] + args[i + 2:]
    only = args
    report = [process(n) for n in SHEETS if not only or n in only]
    if not only or 'mole-burrow' in only:
        report.append(burrow())
    for r in report:
        print(r['sheet'], r.get('scale', ''), r['bytes'], 'cut' if r.get('cut_pieces') else '', r.get('game_boxes_alpha72', r.get('size')))
    if '--report' in sys.argv:
        out = sys.argv[sys.argv.index('--report') + 1]
        with open(out, 'w') as f:
            json.dump(report, f, indent=1)
