/* M6 prepared browser checks (not earned progression): a fresh save is prepared in-page with chosen squads, positions and wave,
   saved, reloaded through the real migration, then the raid is started with the visible "defend now" button and runs in real time
   without player assistance. Contribution uses tools/browser_combat_observer.js (Core.hit applied = enemy HP loss).
   QA_MODE=waves   Wave5/Wave7 (plan 3) with the standard crew, and a revised crew when it loses.
   QA_MODE=species each new kind alone, without/with its counter crew (same crews and positions as model_enemy_counters.cjs).
   QA_MODE=shots   every kind on the field, PC and touch, ja/en/zh: forecast, first-seen card, sprites at in-game size.
   GAME_URL (default http://127.0.0.1:4430/preview/), QA_OUT (output dir). */
'use strict';
const {chromium}=require('playwright'),fs=require('node:fs'),path=require('node:path'),C=require('../2/outpost-core.js'),{SCENARIOS,AT}=require('./model_enemy_counters.cjs');
const URL=process.env.GAME_URL||'http://127.0.0.1:4430/preview/',OUT=process.env.QA_OUT||path.join(__dirname,'..','..','m6-qa'),MODE=process.env.QA_MODE||'waves';fs.mkdirSync(OUT,{recursive:true});
const A=(at,count=3,policy)=>({id:'arch',at,count,policy}),Sw=(at,count=3,policy)=>({id:'sword',at,count,policy}),B=(at,count=3,policy)=>({id:'ballista',at,count,policy});
async function prepare(browser,{wave,groups,modifiers,lang='ja',mobile=false}){
 const context=await browser.newContext({viewport:mobile?{width:390,height:844}:{width:1280,height:900},hasTouch:mobile,isMobile:mobile,deviceScaleFactor:mobile?2:1});
 await context.addInitScript(lang=>{try{if(!localStorage.getItem('m6_prepared'))localStorage.setItem('sbr2_preview_outpost_lang',lang);}catch(e){}},lang);
 const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(URL);if(await page.locator('#titleBattle').isVisible())await page.locator('#titleBattle').click();
 await page.waitForFunction(()=>window.Outpost?.ready&&window.SupplyFactory?.artReady);
 await page.evaluate(({wave,groups,modifiers,AT})=>{
  S.tutorial={version:1,started:true,first10:true,stock30:true,woodDelivered:60,stoneDelivered:0,automaticWood:30,blownWood:0,workerDelivered:true};S.firstWorkerPickup=true;
  const e=S.expedition=ExpeditionCore.migrate({version:1,initialized:true,groups:[],nextKey:1,unlocks:{farmer:true,ballista:true},coins:0,records:[]});
  for(const g of groups){const key=e.nextKey++,anchor=typeof g.at==='string'?AT[g.at]:g.at;e.groups.push({key,id:g.id,count:g.count,tier:[1,3,6,10].indexOf(g.count),active:true,policy:g.policy||'front',pending:0,anchor:{...anchor},positions:[],receipt:null,legacy:false});}
  ExpeditionCore.project(S);ArmyView.reloadFormation();
  const o=OutpostCore.fresh();o.wave=wave;o.cleared=wave-1;o.round=wave-1;o.claimedFirst=Array.from({length:wave-1},(_,i)=>i+1);o.prepRemaining=120;o.prepScheduledRound=o.round;S.outpost=o;S.clearedBossWave=wave-1;
  localStorage.setItem('m6_prepared','1');save();
 },{wave,groups,modifiers,AT});
 const planned=await page.evaluate(()=>ArmyView.sim.soldiers.filter(p=>!p.u.worker).map(p=>[p.id,Math.round(p.x),Math.round(p.y)]));
 await page.reload();if(await page.locator('#titleBattle').isVisible())await page.locator('#titleBattle').click();
 await page.waitForFunction(()=>window.Outpost?.ready&&window.SupplyFactory?.artReady&&ArmyView.sim.soldiers.length>=0);
 if(modifiers)await page.evaluate(m=>Outpost.setNextModifiers(m),modifiers);
 await page.waitForTimeout(400);
 const placed=await page.evaluate(()=>ArmyView.sim.soldiers.filter(p=>!p.u.worker).map(p=>[p.id,Math.round(p.x),Math.round(p.y)]));
 if(JSON.stringify(placed)!==JSON.stringify(planned))throw Error('Prepared positions did not survive the reload: '+JSON.stringify({planned,placed}));
 return {context,page,errors,placed};
}
async function raid(page,timeout){
 await page.addScriptTag({path:path.join(__dirname,'combat_metrics.cjs')});await page.addScriptTag({path:path.join(__dirname,'browser_combat_observer.js')});await page.evaluate(()=>installCombatObserver());
 await page.evaluate(()=>document.querySelectorAll('.enemy-card').forEach(c=>c.remove()));
 await page.locator('#raidStart').click();await page.waitForFunction(()=>S.outpost.phase==='active');
 await page.waitForFunction(()=>S.outpost.phase==='result',null,{timeout,polling:500});
 const snap=await page.evaluate(()=>{const r=window.__combatResearch.snapshot();return {result:r.result,elapsed:r.elapsed,coreApplied:r.coreApplied,observerErrors:r.errors,timesteps:r.timesteps,groups:Object.values(r.metrics.groups).map(g=>({id:g.id,groupKey:g.groupKey,policy:g.policy,count:g.count,releases:g.releases,applied:+g.applied.toFixed(1),kills:g.kills,overkill:+g.overkill.toFixed(1),armorBlocked:+g.armorBlocked.toFixed(1)})),manual:r.metrics.manual.applied,unattributed:r.metrics.unattributed.applied,enemies:r.enemies.map(e=>({kind:e.kind,lane:e.lane,hp:+e.hp.toFixed(1),escaped:e.escaped})),positions:r.positions.filter(p=>p.id!=='woodcutter')};});
 const lost=snap.enemies.reduce((n,e)=>n,0);return snap;
}
const describe=groups=>groups.map(g=>g.count+'×'+g.id+'@'+(typeof g.at==='string'?g.at:JSON.stringify(g.at))+(g.policy?'['+g.policy+']':'')).join(', ');
async function waves(browser){
 const standard=[A('upperArch'),A('lowerArch'),Sw('upperSword'),B('ballista')];
 const revised={5:[A('upperArch'),A('lowerArch'),Sw('upperSword'),B('ballista',3,'armor')],7:[A('upperArch',6),A('lowerArch',6),Sw('upperSword'),B('ballista',3,'armor')]};
 const rows=[];
 for(const wave of [5,7]){for(const [label,groups] of [['standard',standard],['revised',revised[wave]]]){const {context,page,errors}=await prepare(browser,{wave,groups});const plan=await page.evaluate(()=>({version:S.outpost.planVersion,kinds:OutpostCore.plan(S.outpost.wave).kinds,forecast:document.querySelector('#raidBoard .raid-forecast').textContent}));const snap=await raid(page,(C.plan(wave).duration+20)*1000);rows.push({wave,label,crew:describe(groups),plan,...snap,pageErrors:errors});await page.screenshot({path:path.join(OUT,'wave'+wave+'-'+label+'.png')});await context.close();console.log('wave',wave,label,snap.result.win,snap.result.boxes,snap.result.kills,snap.result.escaped);if(label==='standard'&&snap.result.win)break;}}
 return rows;
}
async function species(browser){
 const jobs=[];for(const [kind,s] of Object.entries(SCENARIOS))for(const side of ['without','with'])jobs.push({kind,side,groups:s[side],modifiers:{mix:s.mix,replace:true,...(s.duration?{duration:s.duration}:{})},duration:C.plan(5,3,{mix:s.mix,replace:true,duration:s.duration}).duration});
 const rows=[];for(let i=0;i<jobs.length;i+=5){rows.push(...await Promise.all(jobs.slice(i,i+5).map(async job=>{const {context,page,errors}=await prepare(browser,{wave:5,groups:job.groups,modifiers:job.modifiers});const snap=await raid(page,(job.duration+20)*1000);await context.close();console.log(job.kind,job.side,snap.result.win,snap.result.boxes,snap.result.escaped);return {kind:job.kind,side:job.side,crew:describe(job.groups),...snap,pageErrors:errors};})));}
 return rows;
}
async function shots(browser){
 const kinds=C.KINDS.filter(k=>!['chief'].includes(k)),mix=kinds.map((kind,i)=>({kind,lane:i%2?'lower':'upper',count:1,at:Math.floor(i/2)*1.2,gap:0})),rows=[];
 for(const mobile of (process.env.QA_MOBILE?[process.env.QA_MOBILE==='1']:[false,true]))for(const lang of (process.env.QA_LANG?[process.env.QA_LANG]:['ja','en','zh'])){
  const {context,page,errors}=await prepare(browser,{wave:5,groups:[],modifiers:{mix,replace:true,duration:120},lang,mobile});const tag=lang+'-'+(mobile?'touch':'pc');
  await page.waitForTimeout(600);const card=await page.evaluate(()=>{const c=document.querySelector('.enemy-card');return c?{kind:c.dataset.kind,text:c.innerText}:null;});const forecast=await page.locator('#raidBoard .raid-forecast').textContent();
  await page.screenshot({path:path.join(OUT,tag+'-forecast.png')});
  if(mobile){await page.locator('#raidStart').tap();}else await page.locator('#raidStart').click();
  await page.waitForFunction(()=>S.outpost.phase==='active');await page.waitForTimeout(15500);
  await page.screenshot({path:path.join(OUT,tag+'-field.png')});
  // Identification lineup: the same live enemies, spread along each road and slowed to a crawl (display check only).
  await page.evaluate(()=>{const s=S.outpost;for(const lane of ['upper','lower']){const list=s.enemies.filter(e=>e.alive&&e.lane===lane);const ground=list.filter(e=>!['mole','slinger'].includes(e.kind)),spots=[40,120,300,380,460,540,620,700,760].slice(0,ground.length);ground.forEach((e,i)=>{e.travel=spots[i]??40+i*60;});list.filter(e=>e.kind==='slinger').forEach(e=>{e.travel=230;});list.filter(e=>e.kind==='mole').forEach(e=>{e.travel=180;});list.forEach(e=>{e.speed=1e-3;e.atGate=false;e.gateTime=0;});}
   const reveal=OutpostCore.reveal;OutpostCore.reveal=(state,allies)=>{reveal(state,allies);for(const e of state.enemies)if(e.kind==='wisp')e.seen=true;};});
  await page.waitForTimeout(700);
  const world=await page.evaluate(()=>{const r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return {x:r.left,y:r.top,z};});
  await page.screenshot({path:path.join(OUT,tag+'-lineup-full.png')});
  const lineup=await page.evaluate(()=>S.outpost.enemies.filter(e=>e.alive).map(e=>({kind:e.kind,lane:e.lane,x:Math.round(e.x),y:Math.round(e.y)})));
  for(const lane of ['upper','lower']){const y=lane==='upper'?185:435,clip={x:Math.max(0,world.x+150*world.z),y:Math.max(0,world.y+(y-130)*world.z),width:Math.min(mobile?390:1280,800*world.z),height:160*world.z};await page.screenshot({path:path.join(OUT,tag+'-lineup-'+lane+'.png'),clip});}
  const view=await page.evaluate(()=>{const z=ArmyView.camera.scale,looks=Object.fromEntries(OutpostCore.KINDS.map(k=>[k,(()=>{const L=Outpost.look(k);return L?{uniform:L.uniform,tinted:!!L.art.tinted,ref:L.art.reference}:null;})()]));return {scale:z,looks,enemies:S.outpost.enemies.filter(e=>e.alive).map(e=>({kind:e.kind,x:Math.round(e.x),y:Math.round(e.y),burrowed:OutpostCore.burrowed(e),seen:e.seen===true,screenHeight:+(OutpostCore.ENEMIES[e.kind].height*z).toFixed(1)}))};});
  // Zoomed crop of the field so each sprite can be checked for feet on the road, overflow and facing.
  const box=await page.evaluate(()=>{const r=document.getElementById('battleWorld').getBoundingClientRect();return {x:r.left,y:r.top,width:r.width,height:r.height};});
  await page.screenshot({path:path.join(OUT,tag+'-road.png'),clip:{x:Math.max(0,box.x),y:Math.max(0,box.y),width:Math.min(box.width,mobile?390:1280),height:Math.min(box.height,mobile?844:900)}});
  rows.push({lang,mobile,card,forecast,view,lineup,pageErrors:errors});console.log(tag,errors.length,card?.kind,forecast);await context.close();
 }
 return rows;
}
async function ui(browser){
 const rows=[];for(const mobile of [false,true])for(const lang of ['ja','en','zh']){const tag=lang+'-'+(mobile?'touch':'pc');
  const mods={mix:[{kind:'bat',lane:'both',count:3,at:0,gap:1},{kind:'shaman',lane:'upper',count:1,at:0,gap:0}],replace:true,duration:60};
  const {context,page,errors}=await prepare(browser,{wave:5,groups:[Sw('homeUpper'),B('ballista')],modifiers:mods,lang,mobile});
  const tap=async sel=>{const el=page.locator(sel).first();await el.scrollIntoViewIfNeeded();if(mobile)await el.tap();else await el.click();await page.waitForTimeout(250);};
  await page.evaluate(()=>document.querySelectorAll('.enemy-card').forEach(c=>c.remove()));
  await tap('#expeditionButton');const briefing=await page.locator('.expedition-briefing').innerText();
  const key=await page.evaluate(()=>S.expedition.groups.find(g=>g.id==='ballista').key);await tap('[data-expedition-group="'+key+'"]');
  const buttons=await page.locator('[data-expedition-action="policy"]').allInnerTexts();await tap('[data-expedition-action="policy"][data-expedition-policy="healer"]');
  const policy=await page.evaluate(key=>({group:S.expedition.groups.find(g=>g.key===key).policy,bodies:ArmyView.sim.soldiers.filter(p=>p.id==='ballista').map(p=>p.policy)}),key);
  await page.screenshot({path:path.join(OUT,tag+'-policy.png')});await tap('.expedition-close');
  await page.evaluate(()=>{save();});await page.reload();if(await page.locator('#titleBattle').isVisible())await page.locator('#titleBattle').click();await page.waitForFunction(()=>window.Outpost?.ready);await page.evaluate(m=>Outpost.setNextModifiers(m),mods);const reloaded=await page.evaluate(()=>S.expedition.groups.find(g=>g.id==='ballista').policy);
  await page.evaluate(()=>document.querySelectorAll('.enemy-card').forEach(c=>c.remove()));await tap('#raidStart');await page.waitForFunction(()=>S.outpost.phase==='result',null,{timeout:80000,polling:500});
  await page.waitForSelector('.expedition-result',{timeout:5000}).catch(()=>{});const result=await page.locator('.expedition-result').innerText().catch(()=>'');await page.waitForTimeout(400);const board=await page.locator('#raidBoard .raid-forecast').innerText(),trial=await page.evaluate(()=>S.outpost.result);
  await page.screenshot({path:path.join(OUT,tag+'-result.png')});
  rows.push({lang,mobile,briefing,buttons,policy,reloaded,result,board,outcome:trial,pageErrors:errors});console.log(tag,errors.length,buttons.join('|'),policy.group,reloaded,JSON.stringify(board));await context.close();}
 return rows;
}
(async()=>{const browser=await chromium.launch();try{const out={kind:'m6-enemy-roster-'+MODE,url:URL,at:new Date().toISOString(),note:'Prepared in-page saves (chosen squads/positions/wave), reloaded through migration, raid started with the visible button, real time, no player assistance. Not earned progression.'};
 if(MODE==='waves')out.rows=await waves(browser);if(MODE==='species')out.rows=await species(browser);if(MODE==='shots')out.rows=await shots(browser);if(MODE==='ui')out.rows=await ui(browser);
 fs.writeFileSync(path.join(OUT,'enemy-roster-'+MODE+'.json'),JSON.stringify(out,null,1));}finally{await browser.close();}})().catch(e=>{console.error(e);process.exit(1);});
