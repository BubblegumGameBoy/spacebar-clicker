/* M3 prepared test (not real play): 240 ground items all moving, PC 1280x900, measure frame rate.
   Prepared state: storage skill at the 240-item tier, three blowers, 240 logs with speed; every half second
   resting logs get a new push so all 240 keep moving. Variants: pc, pc-throttle4, phone-throttle4 (CDP CPU throttling x4); a '-empty' suffix measures the same view with no ground items. */
'use strict';
const {chromium}=require('playwright'),fs=require('node:fs'),path=require('node:path');
const URL=(process.env.GAME_URL||'http://127.0.0.1:4422/preview/')+'?lab=1',OUT=process.env.QA_OUT||'/tmp/qa-ground-perf';fs.mkdirSync(OUT,{recursive:true});
(async()=>{const browser=await chromium.launch();const results=[];try{
 for(const variant of (process.env.QA_VARIANTS||'pc,pc-throttle4,phone-throttle4').split(',')){
  const phone=variant.startsWith('phone'),ctx=await browser.newContext(phone?{viewport:{width:390,height:844},hasTouch:true,isMobile:true,deviceScaleFactor:2}:{viewport:{width:1280,height:900}}),page=await ctx.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
  if(variant.includes('throttle')){const cdp=await ctx.newCDPSession(page);await cdp.send('Emulation.setCPUThrottlingRate',{rate:4});}
  await page.goto(URL);await page.waitForTimeout(1200);if(await page.locator('#titleBattle').isVisible())await page.click('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);await page.waitForTimeout(800);
  const setup=await page.evaluate(empty=>{S.harvestSkills.storage=6;if(empty)return {ground:0,capacity:240};S.camp.blowers.push({key:91,x:420,y:330,dir:4,costWood:4},{key:92,x:640,y:260,dir:3,costWood:4},{key:93,x:640,y:450,dir:5,costWood:4});
   S.camp.fences.push({key:91,a:{x:200,y:280},b:{x:300,y:262},costWood:5},{key:92,a:{x:200,y:420},b:{x:300,y:440},costWood:5});
   for(let i=0;i<240;i++){const d=SupplyCore.drop(S.factory,'wood',1,180+(i%24)*30,150+Math.floor(i/24)*36,1,240);if(!d)break;d.physical=true;}return {ground:S.factory.drops.length,capacity:SupplyFactory.stats.groundCapacity};},variant.endsWith('-empty'));
  const m=await page.evaluate(EMPTY=>new Promise(res=>{const frames=[],moving=[];let last=performance.now(),n=0;const t0=last,kick=()=>{while(S.factory.drops.length<240){const k=S.factory.drops.length,d=SupplyCore.drop(S.factory,'wood',1,300+(k*37)%600,160+(k*53)%340,1,240);if(!d)break;d.physical=true;}let i=0;for(const d of S.factory.drops){if(!d.vx&&!d.vy){const a=(d.key*2.399963+n)%6.283;d.vx=Math.cos(a)*240;d.vy=Math.sin(a)*240;}i++;}};if(EMPTY)S.factory.drops.length=0;else kick();
   const f=now=>{frames.push(now-last);last=now;moving.push(S.factory.drops.filter(d=>d.vx||d.vy).length);n++;if(!EMPTY&&n%4===0)kick();if(now-t0<6000)requestAnimationFrame(f);else{frames.shift();const sorted=frames.slice().sort((a,b)=>a-b);res({frames:frames.length,fps:+(1000*frames.length/frames.reduce((a,b)=>a+b,0)).toFixed(1),p95ms:+sorted[Math.floor(sorted.length*.95)].toFixed(1),minMoving:Math.min(...moving.slice(5)),avgMoving:Math.round(moving.reduce((a,b)=>a+b,0)/moving.length),ground:S.factory.drops.length});}};requestAnimationFrame(f);}),variant.endsWith('-empty'));
  await page.screenshot({path:path.join(OUT,variant+'.png')});results.push({variant,setup,...m,errors});await ctx.close();
 }}finally{await browser.close();}
 fs.writeFileSync(path.join(OUT,'result.json'),JSON.stringify({fixture:'Prepared state (?lab=1): 240 logs kept moving by blowers and pushes; headless Chromium',results},null,2));console.log(JSON.stringify(results,null,1));})();
