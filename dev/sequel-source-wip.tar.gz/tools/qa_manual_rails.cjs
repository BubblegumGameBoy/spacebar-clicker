/* M1 board removal, updated for M3 (conveyors unlock at chapter 1; the lesson's tool is now the blower).
   Real play from a fresh ?lesson=1 save (no grants, no time acceleration).
   PC mouse (1280x900) and CDP touch (390x844, not a real device). evaluate() only reads state/coordinates
   and the same ground prediction the placement preview draws.
   Flow: deliver wood -> learn the first skill -> hire and place a lumberjack -> place a deliberately misplaced blower
   -> tap the tree beside it and drag a log past it (must not select) -> tap the blower: strong wind, not selection
   -> hold it (touch) / right-click (PC) to select -> remove it from the card (2 inputs, no workshop dialog)
   -> re-place it behind the landing point -> a log blows home -> a fence is tap-selected and removed.
   Belt removal on the board (the M1 case) is covered with a real older save by qa_m3_legacy_save.cjs. */
'use strict';
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const BASE=process.env.GAME_URL||'http://127.0.0.1:4411/preview/',URL=BASE+(BASE.includes('?')?'&':'?')+'lesson=1',OUT=process.env.QA_OUT||'/tmp/qa-manual-rails';fs.mkdirSync(OUT,{recursive:true});
const MODES=(process.env.QA_MODES||'pc,touch').split(',');
async function run(browser,mode){
 const touch=mode==='touch',ctx=await browser.newContext(touch?{viewport:{width:390,height:844},hasTouch:true,isMobile:true,deviceScaleFactor:2}:{viewport:{width:1280,height:900}}),page=await ctx.newPage(),errors=[],checks=[];let serial=0,inputs=0;
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
 const cdp=touch?await ctx.newCDPSession(page):null,touchEvent=(type,p)=>cdp.send('Input.dispatchTouchEvent',{type,touchPoints:p?[p]:[]});
 const shot=n=>page.screenshot({path:path.join(OUT,mode+'-'+String(++serial).padStart(2,'0')+'-'+n+'.png')});
 const read=()=>page.evaluate(()=>({inventory:{...S.factory.inventory},blowers:S.camp.blowers.map(b=>({...b})),fences:S.camp.fences.map(f=>({...f})),blown:S.tutorial?.blownWood||0,time:S.factory.time,links:S.camp.links.map(l=>({key:l.nodeKey,points:l.points})),selection:OutpostCamp.selection,ground:S.factory.drops.length,delivered:S.factory.delivered,owned:S.owned.woodcutter}));
 const screen=p=>page.evaluate(p=>{const r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return{x:r.left+p.x*z,y:r.top+p.y*z};},p);
 const tap=async(q,hold=60)=>{inputs++;if(touch){await touchEvent('touchStart',q);await page.waitForTimeout(hold);await touchEvent('touchEnd');}else await page.mouse.click(q.x,q.y);await page.waitForTimeout(140);};
 // Panels re-render while opening; retry until the element is attached and has a box.
 const press=async sel=>{for(let i=0;;i++){try{const el=page.locator(sel).first();await el.waitFor({state:'visible',timeout:3000});await el.scrollIntoViewIfNeeded({timeout:1000});const b=await el.boundingBox();if(b){await tap({x:b.x+b.width/2,y:b.y+b.height/2});return;}}catch(e){if(i>=5)throw e;}await page.waitForTimeout(150);}};
 const drag=async(a,z,steps=14)=>{if(touch){await touchEvent('touchStart',a);for(let i=1;i<=steps;i++){await touchEvent('touchMove',{x:a.x+(z.x-a.x)*i/steps,y:a.y+(z.y-a.y)*i/steps});await page.waitForTimeout(16);}await touchEvent('touchEnd');}else{await page.mouse.move(a.x,a.y);await page.mouse.down();await page.mouse.move(z.x,z.y,{steps});await page.mouse.up();}await page.waitForTimeout(150);};
 const field=()=>page.locator('#field').scrollIntoViewIfNeeded();
 const tree=()=>page.evaluate(()=>{const n=S.factory.nodes.find(n=>n.type==='wood'&&n.stock>0),r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return{x:r.left+n.x*z,y:r.top+(n.y-48)*z};});
 const pile=(onBelt=false)=>page.evaluate(onBelt=>{const d=S.factory.drops.find(d=>d.type==='wood'&&!d.worker&&!!d.onConveyor===onBelt&&!SupplyFactory.isAirborne(d));if(!d)return null;const b=SupplyFactory.pileBounds(d),r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return{x:r.left+(b.left+b.right)*.5*z,y:r.top+(b.top+b.bottom)*.5*z};},onBelt);
 const harvest=async n=>{await field();for(let i=0;i<400;i++){if(await page.evaluate(()=>S.factory.drops.filter(d=>d.type==='wood'&&!d.worker&&!d.onConveyor).length)>=n)return;await tap(await tree(),40);}throw new Error('harvest stuck');};
 const deliver=async()=>{await field();for(let i=0;i<60;i++){const p=await pile();if(!p)return;await drag(p,await screen({x:100,y:290}));}};
 try{
  await page.goto(URL);await page.waitForTimeout(1200);await press('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);await page.waitForTimeout(400);
  await harvest(10);await deliver();await press('text=スキルを強化 →');await page.waitForTimeout(400);await press('[data-harvest-learn]:not([disabled])');await page.keyboard.press('Escape');await page.waitForTimeout(300);
  await harvest(6);await deliver();await press('[data-recruit="woodcutter"]');await page.waitForTimeout(400);await field();const spot=(await page.evaluate(()=>BattleControl.spots()))[0];await drag(await screen(spot),await screen(spot),2);assert.equal((await read()).owned,1);
  await harvest(8);await deliver();assert.equal(await page.locator('[data-equipment="belt"]').isDisabled(),true);checks.push('Conveyor card is locked before chapter 1');
  await press('[data-equipment="blower"]');await page.waitForTimeout(300);await field();await tap(await screen({x:250,y:440}));let r=await read();assert.equal(r.blowers.length,1);const wrong=r.blowers[0];await shot('misplaced-blower');checks.push('A blower placed by hand in the wrong place');
  const ground=r.ground;await tap(await tree(),40);await page.waitForTimeout(500);r=await read();assert.equal(r.selection,null);assert.ok(r.ground>ground);checks.push('Tapping the tree still harvests and selects nothing');
  let p=await pile();if(p){await drag(p,await screen({x:wrong.x+30,y:wrong.y-20}));assert.equal((await read()).selection,null);checks.push('Dragging a log next to the blower never selects it');}
  await tap(await screen(wrong));r=await read();assert.equal(r.selection,null);assert.ok(r.blowers[0].boostUntil>r.time,'tap = strong wind');checks.push('Tapping the blower body gives strong wind (until +'+(r.blowers[0].boostUntil-r.time).toFixed(1)+'s), not selection');await page.waitForTimeout(300);
  const before=await read(),t0=Date.now(),start=inputs;const at=await screen(wrong);
  if(touch){inputs++;await touchEvent('touchStart',at);await page.waitForTimeout(650);await touchEvent('touchEnd');await page.waitForTimeout(150);}else{inputs++;await page.mouse.click(at.x,at.y,{button:'right'});await page.waitForTimeout(150);}
  assert.equal((await read()).selection?.kind,'blower');assert.ok(await page.locator('#beltActions').isVisible());const btn=await page.locator('[data-pick-action="remove"]').boundingBox();assert.ok(btn.width>=44&&btn.height>=44);await shot('blower-selected');
  await tap({x:btn.x+btn.width/2,y:btn.y+btn.height/2});const after=await read();
  assert.equal(after.blowers.length,0);assert.equal(after.inventory.wood,before.inventory.wood+2);assert.equal(await page.locator('#campWorkshop.on').count(),0);assert.equal(inputs-start,2);await shot('blower-removed');
  checks.push('Board removal: '+(inputs-start)+' '+(touch?'inputs (hold, tap)':'clicks (right, left)')+', '+((Date.now()-t0)/1000).toFixed(2)+'s, wood '+before.inventory.wood+' -> '+after.inventory.wood+', no workshop dialog');
  const land=await page.evaluate(()=>{const p=ArmyView.sim.soldiers.find(p=>p.id==='woodcutter'),n=S.factory.nodes.filter(n=>n.type==='wood').sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y))[0];return SupplyFactory.outputForWorker(p,n);});
  if(after.inventory.wood<10){await harvest(10-after.inventory.wood);await deliver();}
  const plan=await page.evaluate(l=>{let best=null;for(let dx=-60;dx<=80;dx+=8)for(let dy=-60;dy<=60;dy+=8)for(let dir=0;dir<8;dir++){const p={x:Math.round(l.x+dx),y:Math.round(l.y+dy)};if(!OutpostCamp.canPlaceBlower(p))continue;let home=0;for(let i=0;i<8;i++){const r=SupplyFactory.groundPredict(GroundPhysics.workerDropPoint(l,i),{kind:'blower',...p,dir});if(r&&r.status==='warehouse')home++;}if(!best||home>best.home)best={...p,dir,home};}return best;},land);assert.ok(plan.home>0);
  await press('[data-equipment="blower"]');await page.waitForTimeout(300);for(let i=0;i<8&&await page.evaluate(()=>OutpostCamp.blowerDir)!==plan.dir;i++)await press('[data-rail-action="rotate"]');await field();await tap(await screen(plan));r=await read();assert.equal(r.blowers.length,1);await shot('blower-replaced');
  await page.waitForFunction(b=>(S.tutorial?.blownWood||0)>b,r.blown,{timeout:40000});checks.push('Re-placed blower behind the landing point ('+plan.home+' / 8 in the preview) blows a log home by itself');
  await press('[data-equipment="fence"]');await page.waitForTimeout(300);await field();await drag(await screen({x:560,y:470}),await screen({x:640,y:470}),10);r=await read();assert.equal(r.fences.length,1);
  await tap(await screen({x:600,y:471}));assert.equal((await read()).selection?.kind,'fence');const fb=await page.locator('[data-pick-action="remove"]').boundingBox();await tap({x:fb.x+fb.width/2,y:fb.y+fb.height/2});assert.equal((await read()).fences.length,0);checks.push('A fence is selected with one tap and removed from the card');
  assert.deepEqual(errors,[]);return {mode,status:'passed',checks};
 }catch(e){await shot('FAIL').catch(()=>{});return {mode,status:'failed',message:e.stack,errors,checks};}finally{await ctx.close();}
}
(async()=>{const browser=await chromium.launch();const results=[];try{for(const m of MODES)results.push(await run(browser,m));}finally{await browser.close();}
 fs.writeFileSync(path.join(OUT,'result.json'),JSON.stringify({fixture:'Fresh ?lesson=1 save, visible inputs only; touch is CDP touch, not a real device',results},null,2));console.log(JSON.stringify(results,null,1));if(results.some(r=>r.status!=='passed'))process.exitCode=1;})();
