/* M4 prepared check of the new texts in ja / en / zh, PC (1280x900) and CDP touch (390x844, not a real device).
   Starts from the save earned in qa_m4_journey (Chapter 1 cleared); the language is chosen with the in-game button.
   Reads: the hopper and wooden conveyor cards, the hopper placement bar (hint, price, turn), the hopper's selection
   card, the 240 limit message while drawing a belt, and whether any of these overflow their box. One prepared step:
   wood/stone are not granted; the hopper is paid from earned stock gathered by hand when short. */
'use strict';
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const BASE=process.env.GAME_URL||'http://127.0.0.1:4451/preview/',URL=BASE+(BASE.includes('?')?'&':'?')+'lesson=1',OUT=process.env.QA_OUT||'/tmp/qa-m4-i18n',SAVE=process.env.QA_SAVE;fs.mkdirSync(OUT,{recursive:true});
const helpers=require('./qa_m4_helpers.cjs');
const expect={ja:{hopper:'集積口',belt:'木製コンベア',hint:/出口の向き/,max:/240まで/,remove:/撤去/},en:{hopper:'Hopper',belt:'Wooden conveyor',hint:/turns the outlet/,max:/at most 240/,remove:/Remove/},zh:{hopper:'集料斗',belt:'木制传送带',hint:/转动出口/,max:/最长240/,remove:/拆除/}};
async function run(browser,mode){
 const touch=mode==='touch',ctx=await browser.newContext({...(touch?{viewport:{width:390,height:844},hasTouch:true,isMobile:true,deviceScaleFactor:2}:{viewport:{width:1280,height:900}}),storageState:SAVE});
 const page=await ctx.newPage(),cdp=touch?await ctx.newCDPSession(page):null,h=helpers.make(page,{touch,cdp,out:OUT,tag:mode}),rows=[];
 try{
  await page.goto(URL);await page.waitForTimeout(1000);if(await page.locator('#titleBattle').isVisible())await h.press('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);await page.waitForTimeout(500);
  for(let i=0;i<6&&(await h.read()).paused;i++){await page.keyboard.press('Escape');await page.waitForTimeout(300);}
  await h.need('stone',12);await h.need('wood',30);
  for(const lang of ['ja','en','zh']){
   await h.press('#langBtn');await page.waitForTimeout(300);await h.press('.ts-lang[data-lang="'+lang+'"]');await page.waitForTimeout(300);if(await page.locator('#titleBattle').isVisible())await h.press('#titleBattle');await page.waitForTimeout(400);
   const card=id=>page.evaluate(id=>{const c=document.querySelector('[data-equipment="'+id+'"]').closest('.equipment-card');return {name:c.querySelector('.nm').textContent,text:c.textContent,overflow:[...c.querySelectorAll('*')].some(e=>e.scrollWidth>e.clientWidth+1&&getComputedStyle(e).overflow==='visible'&&e.clientWidth>0)};},id);
   const hopper=await card('hopper'),belt=await card('belt');assert.equal(hopper.name,expect[lang].hopper);assert.equal(belt.name,expect[lang].belt);
   await h.press('[data-equipment="hopper"]');await page.waitForTimeout(300);const bar=await page.evaluate(()=>({hint:document.querySelector('#railEditor b')?.textContent,price:document.querySelector('#railEditor .rail-price')?.textContent,turn:document.querySelector('[data-rail-action="rotate"]')?.textContent,current:document.querySelector('.placement-current')?.textContent}));assert.match(bar.hint,expect[lang].hint);
   await h.field();const spot=await page.evaluate(()=>{for(let x=600;x<900;x+=20)for(let y=200;y<500;y+=20)if(OutpostCamp.canPlaceHopper({x,y}))return {x,y};return null;});await h.shot(lang+'-hopper-bar');await h.tap(await h.screen(spot));await page.waitForTimeout(300);
   const key=await page.evaluate(()=>S.camp.hoppers.at(-1)?.key);await h.field();const q=await h.screen(spot);if(touch){await h.tap(q);}else await page.mouse.click(q.x,q.y,{button:'right'});await page.waitForTimeout(300);
   const pick=await page.evaluate(()=>({sel:OutpostCamp.selection,title:document.querySelector('.belt-actions-title')?.textContent,remove:document.querySelector('[data-pick-action="remove"]')?.textContent,turn:document.querySelector('[data-pick-action="turn"]')?.hidden===false}));assert.equal(pick.sel?.kind,'hopper');assert.match(pick.remove,expect[lang].remove);await h.shot(lang+'-hopper-card');
   await h.press('[data-pick-action="remove"]');await page.waitForTimeout(200);
   // belt drawn past 240 from the house: the bar says why it stops
   await h.press('[data-equipment="belt"]');await page.waitForTimeout(250);await h.field();const a=await h.screen({x:162,y:328}),b=await h.screen({x:700,y:330});let maxText='';
   if(touch){await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[a]});for(let i=1;i<=20;i++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:a.x+(b.x-a.x)*i/20,y:a.y+(b.y-a.y)*i/20}]});await page.waitForTimeout(16);}maxText=await page.evaluate(()=>document.querySelector('#railEditor b')?.textContent+' | '+document.querySelector('#railEditor .rail-price')?.textContent);await h.shot(lang+'-belt-max');await cdp.send('Input.dispatchTouchEvent',{type:'touchCancel',touchPoints:[]});}
   else{await page.mouse.move(a.x,a.y);await page.mouse.down();await page.mouse.move(b.x,b.y,{steps:20});maxText=await page.evaluate(()=>document.querySelector('#railEditor b')?.textContent+' | '+document.querySelector('#railEditor .rail-price')?.textContent);await h.shot(lang+'-belt-max');await page.keyboard.press('Escape');await page.mouse.up();}
   await page.waitForTimeout(200);await page.evaluate(()=>OutpostCamp.cancelRails());await page.waitForTimeout(200);
   assert.match(maxText,expect[lang].max);rows.push({lang,hopperCard:hopper.name,beltCard:belt.name,overflow:hopper.overflow||belt.overflow,bar,pick:{title:pick.title,remove:pick.remove,turn:pick.turn},beltLimit:maxText,removed:key!=null});
  }
  assert.deepEqual(h.errors,[]);return {mode,status:'passed',rows};
 }catch(e){await h.shot('FAIL').catch(()=>{});return {mode,status:'failed',message:e.stack,errors:h.errors,rows};}finally{await ctx.close();}
}
(async()=>{const browser=await chromium.launch();const results=[];try{for(const m of (process.env.QA_MODES||'pc,touch').split(','))results.push(await run(browser,m));}finally{await browser.close();}
 fs.writeFileSync(path.join(OUT,'result.json'),JSON.stringify({fixture:'Save earned by qa_m4_journey; language via the in-game button; touch is CDP touch',results},null,2));console.log(JSON.stringify(results,null,1));if(results.some(r=>r.status!=='passed'))process.exitCode=1;})();
