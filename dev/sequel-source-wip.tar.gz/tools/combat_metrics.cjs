/* Research-only ledger. No game state, currency, timers or targeting are changed. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.CombatMetrics=api;})(globalThis,()=>{
 'use strict';
 const fresh=()=>({releases:0,impacts:0,positiveHits:0,applied:0,armouredApplied:0,requested:0,armorBlocked:0,overkill:0,shieldBlocked:0,shellBlocked:0,packCapped:0,kills:0,choiceSamples:0,policyOpportunities:0,releasesWithBoth:0,targets:{},members:{}});
 function createLedger(actors){const index=new Map(actors.map(a=>[a.id+':'+a.index,{...a}])),groups=new Map();
  for(const a of actors.filter(a=>!a.worker)){const key=String(a.groupKey);if(!groups.has(key))groups.set(key,{groupKey:a.groupKey,id:a.id,policy:a.policy||'front',count:0,...fresh()});groups.get(key).count++;}
  const manual={id:'manual',attempts:0,accepted:0,...fresh()},unknown={id:'unattributed',...fresh()},trace=[];let totalApplied=0,traceOmitted=0;
  const pushTrace=event=>{if(trace.length<10000)trace.push(event);else traceOmitted++;};
  const rowFor=(role,member)=>role==='manual'?manual:groups.get(String(index.get(role+':'+member)?.groupKey))||unknown;
  function memberRow(row,member){const key=String(member??'none');return row.members[key]??=(fresh());}
  function add(row,key,value){row[key]+=value;}
  function release(event,time,choice){const row=rowFor(event.p.id,event.p.index);row.releases++;const m=memberRow(row,event.p.index);m.releases++;if(choice){for(const r of [row,m]){r.choiceSamples++;r.policyOpportunities+=Number(choice.differs);r.releasesWithBoth+=Number(choice.armoured>0&&choice.unarmoured>0);}}const kind=event.target?.kind||'unknown';row.targets[kind]=(row.targets[kind]||0)+1;pushTrace({type:'release',time,groupKey:row.groupKey??row.id,id:event.p.id,index:event.p.index,targetKey:event.targetKey,kind,lane:event.target?.lane,...(choice?{choice}:{})});}
  function hit({role,index:member,amount,before,outcome,time}){if(!before?.alive||!(before.hp>0)||!Number.isFinite(amount)||amount<=0)return false;const row=rowFor(role,member),m=memberRow(row,member),applied=outcome.applied;if(!Number.isFinite(applied)||applied<0||applied>before.hp+1e-7)throw Error('Applied damage must be the actual, HP-bounded core result');const pierce=role==='sword'||role==='ballista',shield=outcome.shieldBlocked||0,shell=outcome.shellBlocked||0,capped=outcome.packCapped||0,mitigated=shield?0:Math.max(0,amount-(pierce?0:before.armor||0)),values={impacts:1,positiveHits:Number(applied>0),applied,armouredApplied:before.armor>0?applied:0,requested:amount,armorBlocked:shield?0:amount-mitigated,shieldBlocked:shield,shellBlocked:shell,packCapped:capped,overkill:Math.max(0,mitigated-shell-capped-applied),kills:Number(outcome.killed===true)};
   if(applied>mitigated+1e-7)throw Error('Applied damage cannot exceed the post-armour amount');
   for(const [k,v] of Object.entries(values)){add(row,k,v);add(m,k,v);}totalApplied+=applied;pushTrace({type:'impact',time,groupKey:row.groupKey??row.id,id:role,index:member,targetKey:before.key,kind:before.kind,lane:before.lane,hpBefore:before.hp,amount,applied,armorBlocked:values.armorBlocked,overkill:values.overkill,killed:outcome.killed===true});return true;
  }
  function manualInput(accepted){manual.attempts++;manual.accepted+=Number(accepted===true);}
  function summary(){const rows=[...groups.values()],attributed=rows.reduce((n,g)=>n+g.applied,0)+manual.applied+unknown.applied;return JSON.parse(JSON.stringify({groups:rows,manual,unattributed:unknown,totalApplied,attributed,balanced:Math.abs(totalApplied-attributed)<1e-7,traceOmitted,traceTruncated:traceOmitted>0,trace}));}
  return {release,hit,manualInput,summary};
 }
 function inspectChoices(Core,state,p,range){const options={includeEnemyRadius:true,minRange:p.u.minRange||0},eligible=state.enemies.filter(e=>e.alive&&Math.hypot(e.x-p.x,e.y-p.y)<=range+(e.r??13)&&Math.hypot(e.x-p.x,e.y-p.y)>=options.minRange),front=Core.target(state,p,range,{...options,priority:'front'}),armor=Core.target(state,p,range,{...options,priority:'armor'});return {armoured:eligible.filter(e=>e.armor>0).length,unarmoured:eligible.filter(e=>!(e.armor>0)).length,frontKey:front?.key??null,armorKey:armor?.key??null,differs:!!front&&!!armor&&front.key!==armor.key};}
 return {createLedger,inspectChoices};
});
