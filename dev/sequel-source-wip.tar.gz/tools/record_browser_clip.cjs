const {spawn}=require('node:child_process');
module.exports=async function recordBrowserClip(page,path){
 const ff=spawn('ffmpeg',['-hide_banner','-loglevel','error','-y','-f','image2pipe','-vcodec','mjpeg','-framerate','20','-i','pipe:0','-an','-c:v','libx264','-preset','veryfast','-crf','22','-pix_fmt','yuv420p','-movflags','+faststart',path],{stdio:['pipe','ignore','pipe']});
 let error='',latest=await page.screenshot({type:'jpeg',quality:90}),backpressure=false,count=0;
 ff.stderr.on('data',b=>error+=b.toString());
 const done=new Promise((resolve,reject)=>{ff.once('error',reject);ff.once('exit',code=>code===0?resolve():reject(Error(error||'Video encoding failed')));});
 const cdp=await page.context().newCDPSession(page);cdp.on('Page.screencastFrame',f=>{latest=Buffer.from(f.data,'base64');void cdp.send('Page.screencastFrameAck',{sessionId:f.sessionId}).catch(()=>{});});await cdp.send('Page.startScreencast',{format:'jpeg',quality:90,maxWidth:1280,maxHeight:900,everyNthFrame:1});
 const startedAt=Date.now(),timer=setInterval(()=>{if(backpressure)return;count++;if(!ff.stdin.write(latest)){backpressure=true;ff.stdin.once('drain',()=>backpressure=false);}},50);
 return async()=>{clearInterval(timer);await cdp.send('Page.stopScreencast');await cdp.detach();ff.stdin.end();await done;return {file:path,seconds:count/20,startedAt,silent:true,source:'actual browser input; no simulated armies or score submissions'};};
};
