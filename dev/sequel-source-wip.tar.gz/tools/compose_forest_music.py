"""Compose an original, quiet, seamless forest loop; no external audio sources."""
from pathlib import Path
import subprocess
import tempfile
import wave
import numpy as np

RATE = 44100
BEAT = 60 / 76
DURATION = 64 * BEAT
SIZE = round(DURATION * RATE)
track = np.zeros((SIZE, 2), dtype=np.float64)
rng = np.random.default_rng(20261020)

def frequency(note):
    return 440 * 2 ** ((note - 69) / 12)

def mix(signal, start, amplitude, pan=0):
    indices = (np.arange(len(signal)) + round(start * RATE)) % SIZE
    left = np.sqrt((1 - pan) / 2)
    right = np.sqrt((1 + pan) / 2)
    np.add.at(track[:, 0], indices, signal * amplitude * left)
    np.add.at(track[:, 1], indices, signal * amplitude * right)

def pluck(note, at, length=2, gain=.1, pan=0):
    t = np.arange(round(length * RATE)) / RATE
    hz = frequency(note)
    envelope = (1 - np.exp(-t / .006)) * np.exp(-t / .58)
    body = (np.sin(2*np.pi*hz*t) + .24*np.sin(2*np.pi*hz*2*t)*np.exp(-t/.24)
            + .065*np.sin(2*np.pi*hz*3*t)*np.exp(-t/.12))
    mix(body * envelope, at, gain, pan)

chords = [[50,57,62,66], [47,54,57,62], [43,50,54,59], [45,52,57,59],
          [52,55,59,62], [43,50,54,59], [50,57,62,66], [45,52,57,64]]
for bar, chord in enumerate(chords):
    start = bar * 8 * BEAT
    length = 8 * BEAT + 1.3
    t = np.arange(round(length * RATE)) / RATE
    envelope = np.minimum(1, t/.9) * np.minimum(1, np.maximum(0, (length-t)/1.3))
    for i, note in enumerate(chord):
        hz = frequency(note)
        signal = (np.sin(2*np.pi*hz*t + .009*np.sin(2*np.pi*.23*t))
                  + .11*np.sin(2*np.pi*2*hz*t)) * envelope
        mix(signal, start, .025, (i-1.5)*.25)
    for step in [0, 4]:
        pluck(chord[0]-12, start+step*BEAT, 3.1, .07, -.05)
    for step in [1, 3, 5, 7]:
        pluck(chord[1+(step//2)%3]+12, start+step*BEAT, 1.5, .036, .25)

melody = [
 [(0,74),(2,69),(3,66)], [(0,76),(2.5,74)],
 [(.5,71),(2,69)], [(0,66),(2,62),(3.25,66)],
 [(0,69),(1.5,71),(3,74)], [(1,71),(3,69)],
 [(0,76),(2,74),(3,69)], [(1,71),(3,69)],
 [(0,74),(1.5,76),(3,78)], [(1,76),(3,74)],
 [(0,71),(2,74),(3,71)], [(1,69),(3,66)],
 [(0,74),(2,69)], [(0,66),(2,69),(3.25,71)],
 [(0,76),(2,74)], [(1,69),(3,64)]
]
for bar, notes in enumerate(melody):
    for beat, note in notes:
        pluck(note, (bar*4+beat)*BEAT, 2.4, .1, -.18)

# A small circular room tail also crosses the loop boundary without a hard cut.
track += np.roll(track, round(.137*RATE), axis=0)[:, ::-1] * .085
track += np.roll(track, round(.251*RATE), axis=0)[:, ::-1] * .04
track -= track.mean(axis=0)
track *= .62 / np.max(np.abs(track))
pcm = np.int16(np.clip(track, -.99, .99) * 32767)
root = Path(__file__).resolve().parent.parent
out = root / 'assets/audio/forest-camp.mp3'
out.parent.mkdir(parents=True, exist_ok=True)
with tempfile.NamedTemporaryFile(suffix='.wav') as temp:
    with wave.open(temp.name, 'wb') as f:
        f.setnchannels(2)
        f.setsampwidth(2)
        f.setframerate(RATE)
        f.writeframes(pcm.tobytes())
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',temp.name,
                    '-c:a','libmp3lame','-b:a','160k',str(out)], check=True)
print({'file':str(out),'seconds':round(DURATION,3),
       'peak_dbfs':round(20*np.log10(np.max(np.abs(track))),2),
       'rms_dbfs':round(20*np.log10(np.sqrt(np.mean(track**2))),2)})
