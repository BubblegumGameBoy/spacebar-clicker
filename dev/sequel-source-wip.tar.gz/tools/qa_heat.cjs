/* M5 threat — prepared browser checks (NOT earned progression).
   Save: a completed camp prepared in-page from the recorded earned completion (preview/media/sequel-progression-checks.json:
   all nine waves cleared at threat 0, gate + beacon built, ballista unlocked, anchors of the final save), then saved and reloaded through
   the real migration. The run's threat is written into that save as the return screen would (S.outpost.heat, seed = wave so it matches
   tools/model_heat.cjs). The raid is started with the visible "defend now" button and runs in real time, no player assistance.
   Contribution: tools/browser_combat_observer.js (Core.hit applied = enemy HP loss), as in dev/COMBAT_RESEARCH.md.
   QA_MODE=trials  threat 0/1/2/3 sets on Wave4 and Wave9 with the completion crew.
   QA_MODE=fixes   conditions the completion crew loses, then the crew/placement changed with the visible UI (drag, hire, train).
   QA_MODE=ui      ja/en/zh × PC/touch(CDP): pick conditions on the return screen, depart, ready (prep time), raid board, loss result.
   GAME_URL (default http://127.0.0.1:4450/preview/), QA_OUT (output dir), QA_ONLY (comma list of row ids). */
'use strict';
const {chromium}=require('playwright'),fs=require('node:fs'),path=require('node:path'),C=require('../2/outpost-core.js'),M=require('./model_heat.cjs');
const URL=process.env.GAME_URL||'http://127.0.0.1:4450/preview/',OUT=process.env.QA_OUT||path.join(__dirname,'..','..','m5-qa'),MODE=process.env.QA_MODE||'trials',ONLY=process.env.QA_ONLY?process.env.QA_ONLY.split(','):null;fs.mkdirSync(OUT,{recursive:true});
const {A,Sw,B,AT,COMPLETION}=M;
// Wave9: the recorded crew (6/6/3) won only with click assistance, so the unassisted baseline is a full four-slot crew from the same camp.
const CREWS={4:COMPLETION[4],9:[A('archUp',10),A('archLow',10),B('ballista',6),Sw('upperSword',6)],'9rec':COMPLETION[9]};
async function prepare(browser,{wave,groups,conditions=[],seed=wave,lang='ja',mobile=false,phase='prep',extra,sealed}){
 const context=await browser.newContext({viewport:mobile?{width:390,height:844}:{width:1280,height:900},hasTouch:mobile,isMobile:mobile,deviceScaleFactor:mobile?2:1});
 await context.addInitScript(lang=>{try{if(!localStorage.getItem('m5_prepared'))localStorage.setItem('sbr2_preview_outpost_lang',lang);}catch(e){}},lang);
 const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(URL);if(await page.locator('#titleBattle').isVisible())await page.locator('#titleBattle').click();
 await page.waitForFunction(()=>window.Outpost?.ready&&window.SupplyFactory?.artReady);
 await page.evaluate(({wave,groups,conditions,seed,AT,phase,extra,sealed})=>{
  S.tutorial={version:1,started:true,first10:true,stock30:true,woodDelivered:60,stoneDelivered:0,automaticWood:30,blownWood:0,workerDelivered:true};S.firstWorkerPickup=true;S.camp.gate=true;S.camp.beacon=true;S.camp.endingSeen=true;
  S.factory.inventory.wood=600;S.factory.inventory.stone=600;S.factory.inventory.food=60;S.enemySeen=OutpostCore.KINDS.slice();
  const records=Array.from({length:9},(_,i)=>({wave:i+1,total:OutpostCore.plan(i+1).potential,bestKills:OutpostCore.plan(i+1).potential,cleared:true}));
  const e=S.expedition=ExpeditionCore.migrate({version:1,initialized:true,groups:[],nextKey:1,unlocks:{farmer:false,ballista:true},coins:0,claimed:37,records,trainingBest:5,run:4,heatUnlocked:true,heatLast:conditions});
  e.groups.push({key:e.nextKey++,id:'woodcutter',count:1,tier:0,active:true,policy:'front',pending:0,anchor:{x:223,y:282},positions:[],receipt:null,legacy:false});
  for(const g of groups){const key=e.nextKey++,anchor=typeof g.at==='string'?AT[g.at]:g.at;e.groups.push({key,id:g.id,count:g.count,tier:[1,3,6,10].indexOf(g.count),active:true,policy:g.policy||'front',pending:0,anchor:{...anchor},positions:[],receipt:null,legacy:false});}
  ExpeditionCore.project(S);ArmyView.reloadFormation();
  // Cramped camp: the sealed squad (by profession) sits in reserve, exactly as returnHome leaves it.
  let sealKey;if(sealed){const g=e.groups.find(g=>g.id===sealed&&g.active);g.active=false;sealKey=g.key;ExpeditionCore.project(S);ArmyView.reloadFormation();}
  const o=OutpostCore.fresh();o.heat=OutpostCore.heat({conditions,seed,sealed:sealKey});o.wave=wave;o.cleared=Math.max(wave-1,phase==='result'?9:0);o.round=wave-1+(phase==='result'?1:0);o.claimedFirst=Array.from({length:o.cleared},(_,i)=>i+1);o.prepRemaining=120;o.prepScheduledRound=o.round;
  if(phase==='result'){o.wave=9;o.phase='result';o.completed=true;o.completedAtRound=o.round;o.result={wave:9,win:true,boxes:3,kills:37,escaped:0,gold:18,first:false,chiefDefeated:true};}
  S.outpost=o;S.clearedBossWave=o.cleared;
  localStorage.setItem('m5_prepared','1');save();
 },{wave,groups,conditions,seed,AT,phase,extra,sealed});
 const planned=await page.evaluate(()=>ArmyView.sim.soldiers.filter(p=>!p.u.worker).map(p=>[p.id,Math.round(p.x),Math.round(p.y)]));
 await page.reload();if(await page.locator('#titleBattle').isVisible())await page.locator('#titleBattle').click();
 await page.waitForFunction(()=>window.Outpost?.ready&&window.SupplyFactory?.artReady);await page.waitForTimeout(400);
 const placed=await page.evaluate(()=>ArmyView.sim.soldiers.filter(p=>!p.u.worker).map(p=>[p.id,Math.round(p.x),Math.round(p.y)]));
 if(JSON.stringify(placed)!==JSON.stringify(planned))throw Error('Prepared positions did not survive the reload: '+JSON.stringify({planned,placed}));
 const heat=await page.evaluate(()=>S.outpost.heat);if(JSON.stringify(heat.conditions)!==JSON.stringify(C_sorted(conditions)))throw Error('threat lost on reload '+JSON.stringify(heat));
 return {context,page,errors};
}
const C_sorted=list=>C.heat({conditions:list}).conditions;
async function board(page){return page.evaluate(()=>({heading:document.querySelector('#raidBoard .raid-heading').textContent,forecast:document.querySelector('#raidBoard .raid-forecast').textContent,boxes:document.querySelector('#raidBoard .raid-boxes').textContent,clock:document.querySelector('#raidBoard .raid-clock').textContent}));}
async function raid(page,timeout,assist=0){
 await page.addScriptTag({path:path.join(__dirname,'combat_metrics.cjs')});await page.addScriptTag({path:path.join(__dirname,'browser_combat_observer.js')});await page.evaluate(()=>{installCombatObserver();window.__cues=[];const play=ForestAudio.play;ForestAudio.play=function(kind,...rest){window.__cues.push(kind);return play.call(this,kind,...rest);};const toast=Rework.toast;Rework.toast=function(title,...rest){(window.__toasts??=[]).push(title);return toast.call(this,title,...rest);};});
 await page.evaluate(()=>document.querySelectorAll('.enemy-card').forEach(c=>c.remove()));
 const before=await board(page);
 await page.locator('#raidStart').click();await page.waitForFunction(()=>S.outpost.phase==='active');
 // Assist: the player's Space key, `assist` presses per second (focus leaves the start button first; the game ignores keys on buttons).
 let presses=0,aimClicks=0;if(assist){
  // A selected tree takes Space (harvest) until the player clicks an enemy once; that visible click switches Space to the raid. Aim stays the game default.
  while(aimClicks<40&&await page.evaluate(()=>SupplyFactory.resourceTarget&&S.outpost.phase==='active')){const at=await page.evaluate(()=>{const e=OutpostCore.target(S.outpost,OutpostCore.WORLD.home,2000,{role:'manual'});if(!e)return null;const d=OutpostCore.ENEMIES[e.kind],r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return {x:r.left+e.x*z,y:r.top+(e.y-d.height*.5-(d.lift||0))*z};});if(at){await page.mouse.click(at.x,at.y);aimClicks++;}await page.waitForTimeout(250);}
  await page.evaluate(()=>document.activeElement?.blur());const until=Date.now()+timeout;while(Date.now()<until&&await page.evaluate(()=>S.outpost.phase==='active')){await page.keyboard.press('Space');presses++;await page.waitForTimeout(Math.max(0,1000/assist-30));}}
 await page.waitForFunction(()=>S.outpost.phase==='result',null,{timeout,polling:500});await page.waitForTimeout(1300);
 const snap=await page.evaluate(()=>{const r=window.__combatResearch.snapshot(),through={};for(const e of r.enemies)if(e.escaped)through[e.kind]=(through[e.kind]||0)+1;return {result:r.result,startBoxes:OutpostCore.planFor(S.outpost).boxes,potential:OutpostCore.planFor(S.outpost).potential,boss:OutpostCore.planFor(S.outpost).boss,observerErrors:r.errors,groups:Object.values(r.metrics.groups).map(g=>({id:g.id,groupKey:g.groupKey,policy:g.policy,count:g.count,applied:+g.applied.toFixed(1),kills:g.kills,armorBlocked:+g.armorBlocked.toFixed(1)})),manual:r.metrics.manual.applied,unattributed:r.metrics.unattributed.applied,coreApplied:+r.coreApplied.toFixed(1),through,toasts:window.__toasts||[],cues:[...new Set(window.__cues)],records:S.expedition.records.filter(r=>r.heat).map(r=>({...r}))};});
 snap.board={before,after:await board(page)};snap.presses=presses;snap.aimClicks=aimClicks;return snap;
}
const describe=M.crewLabel;
function trialJobs(){const jobs=[];for(const wave of [4,9])for(const [set,conditions] of Object.entries(M.SETS))jobs.push({id:'W'+wave+'-'+set,wave,set,conditions,groups:CREWS[wave]});jobs.push({id:'W9rec-0',wave:9,set:'0 (recorded 6/6/3 crew)',conditions:[],groups:CREWS['9rec']});return ONLY?jobs.filter(j=>ONLY.includes(j.id)):jobs;}
async function runJob(browser,job){const {context,page,errors}=await prepare(browser,job);try{const duration=C.plan(job.wave,3,C.heatModifiers(job.wave,{conditions:job.conditions,seed:job.wave})).duration;const snap=await raid(page,(duration+25)*1000);await page.screenshot({path:path.join(OUT,job.id.replace(/[^\w+-]/g,'_')+'.png')});
 const row={id:job.id,wave:job.wave,set:job.set,level:C.heat({conditions:job.conditions}).level,conditions:job.conditions,crew:describe(job.groups),...(job.change?{change:job.change,crewAfter:job.after}:{}),...snap,pageErrors:errors};console.log(row.id.padEnd(30),row.result.win?'WIN ':'LOSE',row.result.boxes+'/'+row.startBoxes,'kills',row.result.kills+'/'+row.potential,JSON.stringify(row.through),row.groups.map(g=>g.id+'#'+g.groupKey+':'+g.applied).join(' '),errors.length?'ERR '+errors.join('|'):'');return row;}finally{await context.close();}}
async function pool(jobs,fn,n=5){const out=[];for(let i=0;i<jobs.length;i+=n)out.push(...await Promise.all(jobs.slice(i,i+n).map(fn)));return out;}
// Visible UI helpers for the changed-crew rows.
async function tap(page,sel,mobile){const el=page.locator(sel).first();await el.scrollIntoViewIfNeeded();if(mobile)await el.tap();else await el.click();await page.waitForTimeout(250);}
async function dragTo(page,target){const screen=await page.evaluate(t=>{const r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return {x:r.left+t.x*z,y:r.top+t.y*z};},target);await page.mouse.move(screen.x,screen.y);await page.mouse.down();await page.waitForTimeout(150);await page.mouse.up();await page.keyboard.press('Escape');await page.waitForTimeout(250);}
// target may be a list of candidates (nearest first): the first legal one is used and recorded; no search for a winning spot.
async function reposition(page,key,targets){await tap(page,'#expeditionButton');await tap(page,'[data-expedition-group="'+key+'"]');await tap(page,'[data-expedition-action="reposition"]');
 const target=await page.evaluate(({key,list})=>{const a=ExpeditionCore.assignments(S).find(a=>a.groupKey===key&&a.member===0),body=ArmyView.sim.soldiers.find(p=>p.id===a.id&&p.index===a.index);return list.find(t=>BattleControl.valid(t,body))||null;},{key,list:[].concat(targets)});if(!target)throw Error('illegal targets '+JSON.stringify(targets));
 await dragTo(page,target);const anchor=await page.evaluate(key=>S.expedition.groups.find(g=>g.key===key).anchor,key);if(Math.hypot(anchor.x-target.x,anchor.y-target.y)>2)throw Error('reposition failed '+JSON.stringify(anchor));return anchor;}
async function hireSquad(page,id,target,count){await tap(page,'#expeditionButton');const slot=await page.evaluate(()=>{const b=[...document.querySelectorAll('[data-expedition-empty="combat"]')];return b.length?b[0].dataset.expeditionSlot:null;});if(slot===null)throw Error('no free slot');await tap(page,'[data-expedition-empty="combat"][data-expedition-slot="'+slot+'"]');await tap(page,'[data-expedition-action="recruit"][data-expedition-id="'+id+'"]');await page.waitForTimeout(300);const spot=await page.evaluate(({t,id})=>{const u=UNITS.find(u=>u.id===id),list=[];for(let dx=-60;dx<=60;dx+=10)for(let dy=-40;dy<=40;dy+=10)list.push({x:t.x+dx,y:t.y+dy});list.sort((a,b)=>Math.hypot(a.x-t.x,a.y-t.y)-Math.hypot(b.x-t.x,b.y-t.y));return list.find(p=>BattleControl.valid(p,{u,r:13,key:-1}))||null;},{t:target,id});if(!spot)throw Error('no legal spot near '+JSON.stringify(target));await dragTo(page,spot);
 const key=await page.evaluate(id=>Math.max(...S.expedition.groups.filter(g=>g.id===id).map(g=>g.key)),id);{const q=await page.evaluate(key=>({q:ExpeditionCore.trainQuote(S,key),g:S.expedition.groups.find(g=>g.key===key),placement:BattleControl.placement}),key);if(!q.q.ready)throw Error('cannot train '+JSON.stringify(q));}for(let i=0;i<3;i++){const n=await page.evaluate(key=>S.expedition.groups.find(g=>g.key===key).count,key);if(n>=count)break;await tap(page,'#expeditionButton');await tap(page,'[data-expedition-group="'+key+'"]');await tap(page,'[data-expedition-action="train"]');await tap(page,'.expedition-close');}
 const g=await page.evaluate(key=>({...S.expedition.groups.find(g=>g.key===key)}),key);if(g.count<count||g.pending)throw Error('hire failed '+JSON.stringify(g));return g;}
const FIXES=[
 {id:'W4-flank-fix',wave:4,conditions:['flank'],change:'下の弓兵3人を上の道側(560,262)へドラッグ',steps:async page=>{const key=await page.evaluate(()=>S.expedition.groups.filter(g=>g.id==='arch')[1].key);await reposition(page,key,{x:560,y:262});},after:[A('archUp',3),A({x:560,y:262},3),B('ballista',3)]},
 {id:'W4-shieldwall-fix',wave:4,conditions:['shieldwall'],change:'剣士を雇い上の角(330,205)に最も近い置ける位置へ配置、3人に増員',steps:async page=>{await hireSquad(page,'sword',AT.upperSword,3);},after:[...COMPLETION[4],Sw('upperSword',3)]},
 {id:'W4-burrow-fix',wave:4,conditions:['burrow'],change:'弓兵2隊を曲がり角の手前（(250,215)(250,405)から最も近い置ける位置）へドラッグ',steps:async page=>{const keys=await page.evaluate(()=>S.expedition.groups.filter(g=>g.id==='arch').map(g=>g.key));const near=(p,dy)=>{const out=[];for(let dx=0;dx<=100;dx+=10)for(let d=0;d<=50;d+=10)out.push({x:p.x+dx,y:p.y+dy*d});return out.sort((u,v)=>Math.hypot(u.x-p.x,u.y-p.y)-Math.hypot(v.x-p.x,v.y-p.y));};await reposition(page,keys[0],near(AT.bendUpper,1));await reposition(page,keys[1],near(AT.bendLower,-1));},after:[A('bendUpper',3),A('bendLower',3),B('ballista',3)]},
 {id:'W4-ironhide-fix',wave:4,conditions:['ironhide'],change:'剣士を雇い上の角(330,205)に最も近い置ける位置へ配置、3人に増員',steps:async page=>{await hireSquad(page,'sword',AT.upperSword,3);},after:[...COMPLETION[4],Sw('upperSword',3)]}
];
async function fixes(browser){const jobs=ONLY?FIXES.filter(j=>ONLY.includes(j.id)):FIXES;return pool(jobs,async job=>{const {context,page,errors}=await prepare(browser,{wave:job.wave,groups:COMPLETION[4],conditions:job.conditions});try{await page.evaluate(()=>document.querySelectorAll('.enemy-card').forEach(c=>c.remove()));await job.steps(page);
  const crew=await page.evaluate(()=>S.expedition.groups.filter(g=>g.active&&g.id!=='woodcutter').map(g=>({id:g.id,count:g.count,anchor:g.anchor,policy:g.policy})));await page.evaluate(()=>save());
  const snap=await raid(page,(C.plan(4,3,C.heatModifiers(4,{conditions:job.conditions,seed:4})).duration+25)*1000);await page.screenshot({path:path.join(OUT,job.id+'.png')});
  const row={id:job.id,wave:job.wave,level:C.heat({conditions:job.conditions}).level,conditions:job.conditions,crewBefore:describe(COMPLETION[4]),change:job.change,crewAfter:crew,...snap,pageErrors:errors};console.log(row.id.padEnd(22),row.result.win?'WIN ':'LOSE',row.result.boxes+'/'+row.startBoxes,'kills',row.result.kills+'/'+row.potential,JSON.stringify(row.through),row.groups.map(g=>g.id+'#'+g.groupKey+':'+g.applied).join(' '));return row;}finally{await context.close();}},4);}
async function ui(browser){const rows=[],configs=[];for(const mobile of [false,true])for(const lang of ['ja','en','zh'])configs.push({mobile,lang});
 return pool(configs,async ({mobile,lang})=>{const tag=lang+'-'+(mobile?'touch':'pc');
  const groups=[A('archUp',1),A('archLow',1),Sw('upperSword',1),B('ballista',1)];
  const {context,page,errors}=await prepare(browser,{wave:9,groups,conditions:[],phase:'result',lang,mobile});try{
  if(mobile){const cdp=await context.newCDPSession(page);await cdp.send('Emulation.setTouchEmulationEnabled',{enabled:true,maxTouchPoints:5});}
  await tap(page,'#expeditionButton',mobile);await tap(page,'.expedition-roster-footer [data-expedition-action="return"], [data-expedition-action="return"]',mobile);
  const pickerBefore=await page.locator('.expedition-heat').innerText();
  await tap(page,'[data-expedition-action="departure"][data-expedition-wave="7"]',mobile);
  for(const id of ['narrow','rush','thin'])await tap(page,'[data-expedition-heat="'+id+'"]',mobile);await tap(page,'[data-expedition-heat="thin"]',mobile);
  const picked=await page.evaluate(()=>({level:document.querySelector('.expedition-heat-level').textContent,summary:document.querySelector('.expedition-heat-summary').textContent,pressed:[...document.querySelectorAll('.expedition-heat-option[aria-pressed="true"]')].map(b=>b.dataset.expeditionHeat),award:document.querySelector('.expedition-award b').textContent}));
  const overflow=await page.evaluate(()=>{const d=document.querySelector('.expedition-dialog');return {scrollWidth:document.documentElement.scrollWidth,client:document.documentElement.clientWidth,dialog:d.getBoundingClientRect().width,options:[...document.querySelectorAll('.expedition-heat-option')].map(b=>Math.round(b.getBoundingClientRect().height))};});
  const sealedLine=await page.locator('.expedition-heat-sealed').innerText().catch(()=>null);
  await page.locator('.expedition-heat').screenshot({path:path.join(OUT,'ui-'+tag+'-picker.png')});
  await tap(page,'[data-expedition-action="confirm-return"]',mobile);
  const departed=await page.evaluate(()=>({heat:S.outpost.heat,wave:S.outpost.wave,message:document.querySelector('.expedition-message').textContent,briefing:document.querySelector('.expedition-briefing')?.innerText,sealed:document.querySelectorAll('.expedition-slot.is-sealed').length,combatHeader:[...document.querySelectorAll('.expedition-slot-section header b')].map(b=>b.textContent),reserve:S.expedition.groups.filter(g=>!g.active).map(g=>g.id),ready:document.querySelector('[data-expedition-action="ready"]')?.textContent}));
  await page.screenshot({path:path.join(OUT,'ui-'+tag+'-roster.png')});
  const reserveText=await page.locator('.expedition-reserves').innerText().catch(()=>'');const sealedKey=await page.evaluate(()=>S.outpost.heat.sealed);
  await tap(page,'.expedition-reserves [data-expedition-group="'+sealedKey+'"]',mobile);const resumeBtn=page.locator('[data-expedition-action="resume"]');let resumeSealed={shown:await resumeBtn.count()>0,disabled:await resumeBtn.isDisabled().catch(()=>null),note:await page.locator('.expedition-detail .expedition-heat-sealed').innerText().catch(()=>null)};if(resumeSealed.shown&&!resumeSealed.disabled){await tap(page,'[data-expedition-action="resume"]',mobile);}resumeSealed={...resumeSealed,stillReserve:await page.evaluate(k=>!S.expedition.groups.find(g=>g.key===k).active,sealedKey),message:await page.locator('.expedition-message').innerText()};
  await tap(page,'[data-expedition-action="ready"]',mobile);await page.waitForTimeout(300);
  const prep=await page.evaluate(()=>({prepRemaining:S.outpost.prepRemaining}));const raidBoard=await board(page);await page.screenshot({path:path.join(OUT,'ui-'+tag+'-board.png')});
  await page.evaluate(()=>document.querySelectorAll('.enemy-card').forEach(c=>c.remove()));await tap(page,'#raidStart',mobile);await page.waitForFunction(()=>S.outpost.phase==='active');const activeBoard=await board(page);
  await page.waitForFunction(()=>S.outpost.phase==='result',null,{timeout:120000,polling:500});await page.waitForSelector('.expedition-result',{timeout:6000}).catch(()=>{});await page.waitForTimeout(400);
  const result=await page.locator('.expedition-result').innerText().catch(()=>'');const outcome=await page.evaluate(()=>({...S.outpost.result,startBoxes:OutpostCore.planFor(S.outpost).boxes}));await page.screenshot({path:path.join(OUT,'ui-'+tag+'-result.png')});
  const row={lang,mobile,touch:mobile?'CDP touch emulation (not a real device)':null,pickerBefore,sealedLine,picked,overflow,departed:{...departed,reserveText},resumeSealed,prep,raidBoard,activeBoard,result,outcome,pageErrors:errors};console.log(tag,sealedLine,JSON.stringify(resumeSealed),picked.level,picked.pressed.join('+'),departed.sealed,departed.reserve.join(','),prep.prepRemaining.toFixed(1),activeBoard.heading,outcome.win,outcome.boxes+'/'+outcome.startBoxes,errors.length);return row;}finally{await context.close();}},3);}
// QA_MODE=tune: the model's threat-1 table rows in the browser — recorded crew without/with assist (4 presses/s) and the budget counter without assist;
// plus threat 2–4 sets with counter + assist. Crews come from tools/model_heat.cjs (COUNTERS, COMBOS).
function tuneJobs(){const jobs=[],R=M.COMPLETION;const add=(id,wave,conditions,groups,assist,role,sealed)=>jobs.push({id,wave,conditions,groups,assist,role,sealed});
 add('W9-0-rec',9,[],R[9],0,'recorded');add('W9-0-rec+assist',9,[],R[9],4,'recorded+assist');
 for(const c of ['horde','ironhide','flank','wings','shieldwall','burrow','thin','procession','siege']){add('W9-'+c+'-rec+assist',9,[c],R[9],4,'recorded+assist');add('W9-'+c+'-counter',9,[c],M.COUNTERS[9][c][0],0,'counter');}
 add('W9-narrow-rec(sealed ballista)+assist',9,['narrow'],R[9],4,'recorded+assist','ballista');
 for(const c of ['ironhide','flank','shieldwall','burrow','siege']){add('W4-'+c+'-rec',4,[c],R[4],0,'recorded');add('W4-'+c+'-counter',4,[c],M.COUNTERS[4][c][0],0,'counter');}
 add('W4-rush-rec',4,['rush'],R[4],0,'recorded');
 for(const [cond,crew] of M.COMBOS.filter((_,i)=>[0,1,3,6].includes(i)))add('W9-L'+C.heat({conditions:cond}).level+'-'+cond.join('+')+'-counter+assist',9,cond,crew,4,'counter+assist');
 return ONLY?jobs.filter(j=>ONLY.includes(j.id)):jobs;}
async function tune(browser){return pool(tuneJobs(),async job=>{const {context,page,errors}=await prepare(browser,job);try{const duration=C.plan(job.wave,3,C.heatModifiers(job.wave,{conditions:job.conditions,seed:job.wave})).duration;const snap=await raid(page,(duration+25)*1000,job.assist);await page.screenshot({path:path.join(OUT,'tune-'+job.id.replace(/[^\w+-]/g,'_')+'.png')});
  const row={id:job.id,role:job.role,wave:job.wave,level:C.heat({conditions:job.conditions}).level,conditions:job.conditions,crew:describe(job.groups)+(job.sealed?' (sealed: '+job.sealed+')':''),assist:job.assist,...snap,pageErrors:errors};console.log(row.id.padEnd(44),row.result.win?'WIN ':'LOSE',row.result.boxes+'/'+row.startBoxes,'kills',row.result.kills+'/'+row.potential,'manual',Math.round(row.manual),'presses',row.presses,'aim',row.aimClicks,JSON.stringify(row.through));return row;}finally{await context.close();}},3);}
module.exports={prepare,raid,board,CREWS,tap,dragTo,reposition,hireSquad};
if(require.main===module)(async()=>{const browser=await chromium.launch();try{const out={kind:'m5-heat-'+MODE,url:URL,at:new Date().toISOString(),note:'Prepared in-page completed save (from the recorded earned completion), reloaded through migration, raid started with the visible button, real time, no player assistance. Not earned progression.'};
 if(MODE==='trials')out.rows=await pool(trialJobs(),job=>runJob(browser,job));if(MODE==='fixes')out.rows=await fixes(browser);if(MODE==='ui')out.rows=await ui(browser);if(MODE==='tune')out.rows=await tune(browser);
 fs.writeFileSync(path.join(OUT,'heat-'+MODE+(ONLY?'-partial':'')+'.json'),JSON.stringify(out,null,1));}finally{await browser.close();}})().catch(e=>{console.error(e);process.exit(1);});
