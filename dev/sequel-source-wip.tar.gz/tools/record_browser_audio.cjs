// Record the browser's real Web Audio output and HTML music into an Opus stream.
// Call install(context) before navigation; start(page) after a real start click.
const fs=require('node:fs');
exports.install=async context=>context.addInitScript(()=>{
 const contexts=[],music=[],taps=new WeakMap(),sources=new WeakMap();
 const nativeConnect=AudioNode.prototype.connect;
 AudioNode.prototype.connect=function(destination,...args){
  const tap=taps.get(this.context);
  if(tap&&destination===this.context.destination)nativeConnect.call(this,tap,...args);
  return nativeConnect.call(this,destination,...args);
 };
 const NativeContext=window.AudioContext||window.webkitAudioContext;
 const CaptureContext=new Proxy(NativeContext,{construct(target,args,newTarget){
  const c=Reflect.construct(target,args,newTarget),tap=c.createMediaStreamDestination();
  contexts.push(c);taps.set(c,tap);return c;
 }});
 window.AudioContext=CaptureContext;if(window.webkitAudioContext)window.webkitAudioContext=CaptureContext;
 window.Audio=new Proxy(window.Audio,{construct(target,args,newTarget){const a=Reflect.construct(target,args,newTarget);music.push(a);return a;}});
 window.__browserAudioTap={async start(){
  const c=contexts[0]||window.ForestAudio.context();await c.resume();
  for(const a of music)if(!sources.has(a)){const source=c.createMediaElementSource(a);source.connect(c.destination);sources.set(a,source);}
  const chunks=[],mime='audio/webm;codecs=opus';
  if(!MediaRecorder.isTypeSupported(mime))throw Error('Opus browser recording unavailable');
  const recorder=new MediaRecorder(taps.get(c).stream,{mimeType:mime,audioBitsPerSecond:128000});
  recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};
  this.recorder=recorder;this.chunks=chunks;recorder.start(100);this.startedAt=Date.now();return this.startedAt;
 },async stop(){
  const recorder=this.recorder;await new Promise(resolve=>{recorder.onstop=resolve;recorder.stop();});
  const blob=new Blob(this.chunks,{type:recorder.mimeType});
  const data=await new Promise(resolve=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result.split(',')[1]);reader.readAsDataURL(blob);});
  return {data,startedAt:this.startedAt};
 }};
});
exports.start=async page=>{
 const startedAt=await page.evaluate(()=>window.__browserAudioTap.start());
 return async file=>{const audio=await page.evaluate(()=>window.__browserAudioTap.stop());fs.writeFileSync(file,Buffer.from(audio.data,'base64'));return {file,startedAt};};
};
