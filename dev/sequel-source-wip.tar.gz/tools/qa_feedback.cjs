// Regressions found by independent visual playtests; run against a static preview.
const {chromium}=require('playwright'),assert=require('node:assert/strict');
const url=process.env.GAME_URL||'http://127.0.0.1:4181/preview/';
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true});
 try{
  const page=await browser.newPage({viewport:{width:1280,height:900}}),errors=[];
  page.on('pageerror',e=>errors.push({name:e.name,message:e.message}));
  await page.goto(url);assert.equal(await page.locator('.rx-launch button').first().getAttribute('id'),'titleBattle');
  await page.click('#titleBattle');await page.waitForFunction(()=>SupplyFactory.artReady);await page.waitForTimeout(300);
  const point=async(type)=>page.evaluate(type=>{const n=S.factory.nodes.filter(n=>n.type===type).sort((a,b)=>Math.hypot(a.x-S.factory.depot.x,a.y-S.factory.depot.y)-Math.hypot(b.x-S.factory.depot.x,b.y-S.factory.depot.y))[0],r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return {x:r.left+n.x*z,y:r.top+(n.y-30)*z,key:n.key};},type);
  const tree=await point('wood');
  const field=await page.locator('#field').boundingBox(),hud=await page.locator('#hud').boundingBox();
  await page.evaluate(key=>{const n=S.factory.nodes.find(n=>n.key===key),canvas=document.getElementById('armyCanvas'),view=canvas.getBoundingClientRect(),world=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale,d=canvas.width/view.width;window.__hitRect=[Math.floor((world.left-view.left+(n.x-44)*z)*d),Math.floor((world.top-view.top+(n.y-100)*z)*d),Math.ceil(88*z*d),Math.ceil(93*z*d)];window.__hitPixels=canvas.getContext('2d').getImageData(...window.__hitRect).data;},tree.key);
  await page.mouse.click(tree.x,tree.y);await page.waitForTimeout(45);
  const changed=await page.evaluate(()=>{const now=document.getElementById('armyCanvas').getContext('2d').getImageData(...window.__hitRect).data;return now.reduce((n,v,i)=>n+(v!==window.__hitPixels[i]),0);});assert.ok(changed>100,'struck tree must visibly react');
  await page.waitForTimeout(550);
  const settled=await page.evaluate(()=>{const now=document.getElementById('armyCanvas').getContext('2d').getImageData(...window.__hitRect).data;return now.reduce((n,v,i)=>n+(v!==window.__hitPixels[i]),0);});assert.equal(settled,0,'tree must settle, without continuous motion');assert.deepEqual(await page.locator('#field').boundingBox(),field);
  console.log('PASS visible local hit reaction settles; the field never shakes');
  await page.keyboard.press('Space');await page.keyboard.press('Space');
  async function pickup(type,worker=false){const pt=await page.evaluate(({type,worker})=>{const d=S.factory.drops.find(d=>d.type===type&&(!worker||d.worker));if(!d)return null;const r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return {x:r.left+d.x*z,y:r.top+d.y*z-12};},{type,worker});assert.ok(pt);await page.mouse.click(pt.x,pt.y);}
  await pickup('wood');await page.click('[data-id="woodcutter"] .nm');assert.equal(await page.evaluate(()=>S.owned.woodcutter),0,'card description cannot buy people');
  await page.click('[data-recruit="woodcutter"]');assert.equal(await page.locator('#commandMode').isVisible(),false);assert.ok(await page.evaluate(()=>BattleControl.spots().length>0));
  await page.mouse.click(tree.x,tree.y);assert.equal(await page.evaluate(()=>S.pending.woodcutter),0);const position=await page.evaluate(()=>ArmyView.sim.soldiers.map(p=>[p.x,p.y]));
  await page.waitForFunction(()=>S.factory.drops.some(d=>d.worker));await pickup('wood',true);
  assert.deepEqual(await page.locator('[data-recruit]').evaluateAll(bs=>bs.map(b=>b.dataset.recruit)),['woodcutter','miner','arch']);
  assert.deepEqual(await page.evaluate(()=>ArmyView.sim.soldiers.map(p=>[p.x,p.y])),position);
  console.log('PASS explicit hire, clear tree-side placement, fixed feet and stable unlock order');
  for(const [type,n]of [['wood',5],['stone',3]]){while(await page.evaluate(({type,n})=>S.factory.inventory[type]+SupplyFactory.totalGround(type)<n,{type,n}))await page.click(type==='wood'?'#gatherWood':'#gatherStone');if(await page.evaluate(type=>SupplyFactory.totalGround(type)>0,type))await pickup(type);}
  await page.click('[data-recruit="arch"]');assert.equal(await page.locator('#boss').isVisible(),true);assert.ok(await page.locator('#field').evaluate(el=>el.classList.contains('planning-combat')));
  const spot=await page.evaluate(()=>{const q=BattleControl.spots()[0],r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return {x:r.left+q.x*z,y:r.top+q.y*z};});await page.mouse.click(spot.x,spot.y);
  assert.deepEqual(await page.locator('#hud').boundingBox(),hud);console.log('PASS enemy visible before the first archer is placed; HUD height stays fixed');
  // A transparent canvas isolates actual rendered idle people from scenery.
  await page.evaluate(()=>{S.owned={woodcutter:1,miner:1,arch:1};S.pending={};S.factory.nodes=[];S.factory.drops=[];S.factory.depot={x:-1000,y:-1000};ArmyView.render();BattleControl.setPlacement(false);ArmyView.sim.soldiers.forEach((p,i)=>{p.x=230+i*180;p.y=380;p.enterAt=-100;p.attackAt=-100;p.cooldown=999;});});await page.waitForTimeout(2400);
  const heights=await page.evaluate(()=>{const c=document.getElementById('armyCanvas'),v=c.getBoundingClientRect(),r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale,d=c.width/v.width,ctx=c.getContext('2d');return ArmyView.sim.soldiers.map(p=>{const x=Math.floor((r.left-v.left+(p.x-65)*z)*d),y=Math.floor((r.top-v.top+(p.y-100)*z)*d),w=Math.floor(130*z*d),h=Math.floor(105*z*d),pixels=ctx.getImageData(x,y,w,h).data;let t=h,b=0;for(let yy=0;yy<h;yy++)for(let xx=0;xx<w;xx++)if(pixels[(yy*w+xx)*4+3]>120){t=Math.min(t,yy);b=Math.max(b,yy);}return {id:p.id,height:(b-t+1)/d/z};});});assert.ok(Math.max(...heights.map(p=>p.height))-Math.min(...heights.map(p=>p.height))<6,JSON.stringify(heights));
  console.log('PASS actual rendered lumberjack, miner and archer have consistent idle body heights',heights);
  for(let i=0;i<12;i++){await page.click('#bgmBtn');await page.waitForTimeout(12);}await page.waitForTimeout(100);assert.deepEqual(errors,[]);
  console.log('PASS repeated music toggles produce no invalid fade volume or runtime errors');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
