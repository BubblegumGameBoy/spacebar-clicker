// Collect reviewed captures without modifying the images or videos.
const fs=require('node:fs'),path=require('node:path'),{execFileSync}=require('node:child_process');
const source=path.resolve(process.env.REWORK_MEDIA||'promo-output/rework');
const destination=path.resolve(process.env.REWORK_REVIEW||'promo-output/mythos-slayers-2-review');
const pictures=[
 ['measurement-desktop.png','連打測定'],['result-desktop.png','測定結果'],
 ['ranking-desktop.png','速度ランキング（ローカル検証データ）'],['skills-desktop.png','魂のスキルツリー'],
 ['combat-and-supply-desktop.png','市の討伐依頼・軍団・補給'],['combat-and-supply-mobile.png','スマホの戦場'],
 ['evolution-desktop.png','部隊の進化'],['army-5000-desktop.png','5,000人の描画検証'],
 ['army-5000-combat.png','5,000人の進軍・攻撃検証'],['commands-desktop.png','個体への移動指示'],['rails-desktop.png','レールと物資'],
 ['retreat-desktop.png','撤退と再挑戦'],['measurement-mobile.png','スマホの測定'],
 ['measurement-en.png','英語表示'],['measurement-zh.png','中国語表示'],
 ['five-minute-play.png','序盤の自動操作によるプレイ確認'],
];
const videos=[['measurement-to-result.mp4','10秒の測定から結果まで'],
 ['army-recruit-evolution.mp4','増援・進化・軍団の拡大（後半はデモ人数）'],
 ['combat-and-supply.mp4','ボスの攻撃・回避・採集・レール（デモ用セーブ）']];
fs.mkdirSync(destination,{recursive:true});
for(const [file]of [...pictures,...videos])fs.copyFileSync(path.join(source,file),path.join(destination,file));
for(const file of ['validation.json','sequel-validation.json','play-balance.json','army-load.json','clips.json'])fs.copyFileSync(path.join(source,file),path.join(destination,file));
for(const [from,to]of [['2/ECONOMY.md','ECONOMY.md'],['REWORK.md','REWORK.md']])fs.copyFileSync(path.resolve(__dirname,'..',from),path.join(destination,to));
const report=JSON.parse(fs.readFileSync(path.join(source,'play-balance.json'),'utf8'));
const escape=s=>String(s).replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
fs.writeFileSync(path.join(destination,'index.html'),`<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Mythos Slayers II レビュー素材</title><style>body{margin:0;background:#111c21;color:#e6e3ce;font:16px/1.8 system-ui}main{max-width:1120px;margin:auto;padding:32px 20px 80px}h1{color:#ead49b;line-height:1.3}a{color:#a9e3c4}p{max-width:850px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:22px}figure{margin:0 0 30px}img,video{width:100%;background:#101820;border:1px solid #52655a;border-radius:8px}figcaption{margin:8px 0}small{color:#b4c2b5}pre{overflow:auto;background:#17282a;padding:18px;border-radius:7px;font-size:13px}</style><main><h1>SPACEBAR Mythos Slayers II</h1><p>レビュー用のローカル試作と記事用素材です。前作を残し、続編を別URLへ配信する構成。本番公開は行っていません。</p><p><a href="ECONOMY.md">市の討伐報酬と軍団・物流の設計</a> · <a href="REWORK.md">実装と検証の範囲</a></p><p>映像は実ブラウザの無音MP4です。軍団拡大の後半はデモ用に人数を切り替えています。戦闘・補給の映像は準備したセーブを使用。ランキングはローカルの検証用記録で、本番へ送信していません。画像を開いて保存、または動画のダウンロードリンクを利用できます。</p><h2>短い動画</h2>${videos.map(([f,t])=>`<figure><video controls preload="metadata" playsinline src="${f}"></video><figcaption>${escape(t)} · <a download href="${f}">MP4を保存</a></figcaption></figure>`).join('')}<h2>記事用スクリーンショット</h2><div class="grid">${pictures.map(([f,t])=>`<figure><a href="${f}"><img loading="lazy" src="${f}" alt="${escape(t)}"></a><figcaption>${escape(t)}</figcaption></figure>`).join('')}</div><h2>実ゲームの進行確認</h2><p>秒間${report.cps}回、一定の購入方針で${report.seconds}秒を仮想時計で操作。回避操作なし。人間の所要時間や継続率を予測するものではありません。</p><pre>${escape(JSON.stringify(report,null,2))}</pre></main></html>`);
fs.writeFileSync(path.join(destination,'README.txt'),'Mythos Slayers II レビュー素材\n\nindex.html をブラウザで開くと画面と動画を一覧できます。\nECONOMY.md: 市の討伐報酬・人員・物資・設備の設計。\nREWORK.md: 実装と検証の範囲。\n\nMP4はH.264、無音。PNGは実ブラウザの画面。\n軍団映像の後半は人数を切り替えるデモです。戦闘・補給映像はデモ用セーブ。\nランキングはローカルの検証データです。本番へは送信していません。\n\nこの素材集はゲーム本体を含みません。ソースはリポジトリの2/を参照してください。\n');
const archive=destination+'.zip';if(fs.existsSync(archive))fs.unlinkSync(archive);
execFileSync('zip',['-qr',archive,path.basename(destination)],{cwd:path.dirname(destination)});
console.log(JSON.stringify({gallery:path.join(destination,'index.html'),archive,bytes:fs.statSync(archive).size}));
