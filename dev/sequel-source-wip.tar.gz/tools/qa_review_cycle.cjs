// User-visible regressions found by the diverse independent reviewers.
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
const url=process.env.GAME_URL||'http://127.0.0.1:4184/preview/';
(async()=>{const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true});try{
 const context=await browser.newContext({viewport:{width:1280,height:900}}),page=await context.newPage(),errors=[];
 page.on('pageerror',e=>errors.push(e.message));await page.goto(url);await page.waitForFunction(()=>!!window.Rework);
 await page.locator('#titleBattle').focus();await page.keyboard.press('Space');await page.waitForFunction(()=>document.getElementById('titleScreen').classList.contains('hidden'));
 await page.waitForFunction(()=>SupplyFactory.artReady);const ground=await page.evaluate(()=>SupplyFactory.totalGround('wood'));
 await page.locator('#bgmBtn').focus();await page.keyboard.press('Space');assert.equal(await page.evaluate(()=>ForestAudio.stats.paused),true);assert.equal(await page.evaluate(()=>SupplyFactory.totalGround('wood')),ground);
 await page.locator('#field').focus();await page.keyboard.press('Space');assert.equal(await page.evaluate(()=>SupplyFactory.totalGround('wood')),ground+1);
 console.log('PASS Space activates focused buttons and harvests only when the field has focus');
 await page.click('#langBtn');await page.waitForFunction(()=>document.getElementById('titleScreen').contains(document.activeElement));
 for(let i=0;i<16;i++){await page.keyboard.press('Tab');assert.ok(await page.evaluate(()=>document.getElementById('titleScreen').contains(document.activeElement)));}
 assert.equal(await page.locator('#field').evaluate(e=>e.inert),true);await page.keyboard.press('Escape');assert.equal(await page.locator('#titleScreen').evaluate(e=>e.classList.contains('hidden')),true);assert.equal(await page.evaluate(()=>document.activeElement.id),'langBtn');
 console.log('PASS language dialog contains focus, excludes the covered field and returns to its opener');
 await page.click('#rxMeasure');await page.click('[data-seconds="5"]');assert.equal(await page.evaluate(()=>document.activeElement.dataset.seconds),'5');
 await page.click('#measureStart');await page.locator('.measure-orb.live').waitFor();for(let i=0;i<12;i++)await page.keyboard.press('Space');await page.locator('.measure-total').waitFor();assert.equal(await page.evaluate(()=>S.measureBests[5].count),12);
 await page.locator('#resultRank').focus();await page.keyboard.press('Space');await page.locator('#rankOverlay.on').waitFor();await page.keyboard.press('Escape');await page.locator('#measureOverlay.on .measure-total').waitFor();assert.equal(await page.evaluate(()=>document.activeElement.id),'resultRank');
 await page.keyboard.press('Escape');assert.equal(await page.evaluate(()=>document.activeElement.id),'rxMeasure');assert.deepEqual(errors,[]);
 console.log('PASS duration choice retains focus; result buttons accept Space; leaderboard returns to the result and then the game');
 await context.close();
 const fixture=process.env.REVIEW_FIXTURE;if(fixture){
  const data=JSON.parse(fs.readFileSync(fixture,'utf8')),state=data.localStorage?Object.fromEntries(Object.entries(data.localStorage)):null;
  const c=await browser.newContext({viewport:{width:390,height:844},hasTouch:true});await c.addInitScript(state=>{for(const [k,v]of Object.entries(state))localStorage.setItem(k,v);localStorage.setItem('sbr2_preview_forest_lang','ja');},state);const p=await c.newPage();p.on('pageerror',e=>errors.push(e.message));await p.goto(url);if(await p.locator('#titleBattle').isVisible())await p.click('#titleBattle');await p.waitForFunction(()=>SupplyFactory.artReady&&BattleControl.reserved.length>0);await p.waitForTimeout(300);
  const checks=await p.evaluate(()=>new Promise(resolve=>{const original=BattleControl.reserved.map(q=>({...q})),bad=[],changed=[],start=performance.now();const timer=setInterval(()=>{const u=UNITS.find(u=>S.pending[u.id]>0);for(const q of original)if(!BattleControl.valid(q,{u,r:10}))bad.push({time:performance.now()-start,q});if(JSON.stringify(BattleControl.reserved)!==JSON.stringify(original))changed.push(performance.now()-start);if(performance.now()-start>16000){clearInterval(timer);resolve({bad,changed,piles:S.factory.drops.length,original});}},100);}));
  assert.deepEqual(checks.bad,[],'a displayed + must stay legal while workers create piles');assert.deepEqual(checks.changed,[],'placement guides must stay put while choosing');assert.equal(await p.locator('#bossPlate').evaluate(e=>getComputedStyle(e).visibility),'visible');
  const q=checks.original[0],point=await p.evaluate(q=>{const r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return {x:r.left+q.x*z,y:r.top+q.y*z};},q);await p.touchscreen.tap(point.x,point.y);assert.equal(await p.evaluate(()=>S.pending.arch),0);await p.screenshot({path:'/workspace/scratch/diverse-system/stable-mobile-placement.png'});await c.close();
  console.log('PASS earned mobile review save: guides stay valid for 16 seconds of real worker output, then touch placement succeeds');
 }
 assert.deepEqual(errors,[]);
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
