/* Prepared checkpoint and construction fixtures. These are targeted regressions,
   separate from the normally earned campaign playthrough. No remote requests. */
'use strict';
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
const {make}=require('./qa_m4_helpers.cjs');
const URL=process.env.GAME_URL||'http://127.0.0.1:4422/preview/?lesson=2';
const OUT=process.env.QA_OUT||'/tmp/mythos-campaign-recovery';fs.mkdirSync(OUT,{recursive:true});
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium'}),rows=[];
 try{for(const touch of [false,true])for(const lang of ['ja']){
  const context=await browser.newContext({viewport:touch?{width:390,height:844}:{width:1280,height:900},isMobile:touch,hasTouch:touch});
  await context.addInitScript(lang=>localStorage.setItem('sbr_lang',lang),lang);
  const page=await context.newPage(),cdp=touch?await context.newCDPSession(page):null;
  const h=make(page,{touch,cdp,out:OUT,tag:lang+(touch?'-touch':'-pc')});
  try{
   await page.goto(URL+(URL.includes('?')?'&':'?')+'lang='+lang);if(await page.locator('#titleBattle').isVisible())await h.press('#titleBattle');await page.waitForFunction(()=>Outpost.ready&&SupplyFactory.artReady);
   assert.equal(await page.evaluate(()=>LANG),lang);
   for(const wave of [3,6]){
    await page.evaluate(wave=>{
     S.outpost={...OutpostCore.fresh(),phase:'result',wave,cleared:wave,round:wave,prepScheduledRound:wave,prepRemaining:120,result:{wave,win:true,kills:OutpostCore.plan(wave).potential,escaped:0,boxes:3,gold:0}};
     ExpeditionCore.ensure(S);S.expedition.awaitingReady=true;S.expedition.awaitingDecision=false;S.tutorial.woodDelivered=2;
     ExpeditionUI.sync();Outpost.update();save();
    },wave);
    await page.reload();await page.waitForFunction(()=>Outpost.ready&&SupplyFactory.artReady&&!Rework.paused&&document.getElementById('titleScreen').classList.contains('hidden'));
    const factoryTime=await page.evaluate(()=>S.factory.time);
    await page.waitForTimeout(1100);
    assert.deepEqual(await page.evaluate(()=>({held:S.expedition.awaitingReady,prep:S.outpost.prepRemaining,wave:S.outpost.wave})),{held:true,prep:120,wave});
    assert.ok(await page.evaluate(t=>S.factory.time>t+.5,factoryTime),'Production keeps ticking while only the raid clock is held');
    await h.press('#expeditionNotice button');
    await page.evaluate(()=>{S.pending.arch=1;ExpeditionUI.sync();});
    assert.equal(await page.locator('[data-expedition-action="ready"]').isDisabled(),true);
    await page.evaluate(()=>{S.pending.arch=0;ExpeditionUI.sync();});
    await h.press('[data-expedition-action="ready"]');
    await page.waitForFunction(()=>!S.expedition.awaitingReady);
    const remaining=await page.evaluate(()=>S.outpost.prepRemaining);assert.ok(remaining>88&&remaining<=90);
   }
   await page.evaluate(()=>{
    S.factory.inventory={wood:500,stone:500};S.progression=ProgressionCore.fresh();
    for(const id of ['recipe_woodcutter','recipe_blower','carry1','carry2','recipe_belt'])assertPurchase(id);
    function assertPurchase(id){if(!ProgressionCore.purchase(S,id))throw Error('Fixture recipe failed: '+id);}
    ProgressionIntegration.refresh();
   });
   const before=await page.evaluate(()=>S.factory.inventory.wood);
   await h.press('[data-equipment="belt"]');await h.field();
   await h.drag(await h.screen({x:162,y:328}),await h.screen({x:700,y:328}),28);
   await page.waitForFunction(()=>S.camp.links.length===1);
   const first=await page.evaluate(()=>({length:ConveyorCore.length(S.camp.links[0].points),end:S.camp.links[0].points.at(-1),wood:S.factory.inventory.wood,toast:document.getElementById('rxToast').textContent}));
   assert.ok(Math.abs(first.length-240)<.01);assert.equal(before-first.wood,5);
   assert.match(first.toast,lang==='ja'?/長さ上限/:lang==='en'?/length limit/:/长度上限/);
   await h.shot('capped-endpoint');
   await h.press('[data-equipment="belt"]');await h.field();
   await h.drag(await h.screen(first.end),await h.screen({x:520,y:328}),22);
   await page.waitForFunction(()=>S.camp.links.length===2);
   const joined=await page.evaluate(()=>({firstLength:ConveyorCore.length(S.camp.links[0].points),secondLength:ConveyorCore.length(S.camp.links[1].points),gap:ConveyorCore.distance(S.camp.links[0].points.at(-1),S.camp.links[1].points[0]),end:S.camp.links[1].points.at(-1),wood:S.factory.inventory.wood}));
   assert.equal(joined.gap,0);assert.ok(joined.firstLength<=240.01&&joined.secondLength<=240.01);assert.ok(Math.abs(joined.end.x-520)<1);assert.equal(first.wood-joined.wood,4);
   // A belt is valid ground for a loader. The green preview must agree with a real tap.
   await page.evaluate(()=>{for(const id of ['storage1','storage2','recipe_loader'])if(!ProgressionCore.purchase(S,id))throw Error('Loader fixture failed: '+id);ProgressionIntegration.refresh();});
   const loaderStock=await page.evaluate(()=>({...S.factory.inventory}));
   assert.equal(await page.evaluate(()=>OutpostCamp.canPlaceLoader({x:250,y:328})),true);
   await h.press('[data-equipment="loader"]');await h.field();await h.tap(await h.screen({x:250,y:328}));await h.press('[data-placement-confirm]');
   await page.waitForFunction(()=>S.camp.loaders.length===1);
   assert.deepEqual(await page.evaluate(()=>({x:S.camp.loaders[0].x,y:S.camp.loaders[0].y})),{x:250,y:328});
   assert.equal(await page.evaluate(()=>S.factory.inventory.wood),loaderStock.wood-12);assert.equal(await page.evaluate(()=>S.factory.inventory.stone),loaderStock.stone-6);
   await h.press('[data-equipment="loader"]');await h.field();await h.tap(await h.screen({x:250,y:328}));
   assert.equal(await page.evaluate(()=>S.camp.loaders.length),1,'Tapping an existing loader still selects it');
   assert.equal(await page.evaluate(()=>S.factory.inventory.wood),loaderStock.wood-12);
   // Reopen a prepared late loss through its notice, then use the advised policy.
   const swordKey=await page.evaluate(()=>{
    OutpostCamp.cancelRails();Rework.close();S.factory.inventory={wood:500,stone:500,food:100};
    for(const id of ['recipe_arch','recipe_sword'])if(!ProgressionCore.purchase(S,id))throw Error('Defeat fixture recipe failed');
    const g=ExpeditionCore.recruit(S,'sword');ExpeditionCore.setAnchor(S,'sword',0,{x:500,y:165});ExpeditionCore.train(S,g.key);ExpeditionIntegration.refresh();
    S.outpost={...OutpostCore.fresh(),phase:'result',wave:9,cleared:8,round:9,prepScheduledRound:9,prepRemaining:90,result:{wave:9,win:false,boxes:0,kills:34,escaped:3,gold:8},enemies:[{key:1,kind:'guard',lane:'upper',hp:27,alive:false}]};
    S.expedition.awaitingDecision=true;S.expedition.awaitingReady=false;ExpeditionUI.showResult(S.outpost.result);return g.key;
   });
   await h.press('.expedition-close');await h.press('#expeditionNotice button');
   assert.match(await page.locator('.expedition-cause').innerText(),lang==='ja'?/鎧を優先/:lang==='en'?/Armour first/:/重甲优先/);
   await h.press('[data-expedition-action="retry"]');
   const funds=await page.evaluate(()=>({...S.factory.inventory}));
   await h.press('[data-expedition-group="'+swordKey+'"]');await h.press('[data-expedition-action="policy"][data-expedition-policy="armor"]');
   assert.equal(await page.evaluate(key=>S.expedition.groups.find(g=>g.key===key).policy,swordKey),'armor');
   assert.deepEqual(await page.evaluate(()=>({...S.factory.inventory})),funds);
   assert.equal(await page.evaluate(()=>S.expedition.awaitingReady),true);
   assert.deepEqual(h.errors,[]);
   rows.push({lang,input:touch?'CDP touch':'mouse',status:'passed',checks:['Wave 3 and 6 hold through reload until Ready','Pending placement disables Ready','Ready starts real 90-second preparation','Capped construction explains the limit','Next manual drag joins at the highlighted end; exact material costs preserved','Green loader preview on a belt places the loader; existing machines remain selectable','Loss notice reopens the result, retry holds the clock, and the advised armour policy applies without spending stock'],errors:h.errors});
  }finally{await context.close();}
 }}finally{await browser.close();}
 fs.writeFileSync(OUT+'/result.json',JSON.stringify({fixture:'Prepared checkpoint results and research stock; not a new-save campaign',rows},null,2));
 console.log(JSON.stringify(rows));
})().catch(error=>{console.error(error);process.exitCode=1;});
