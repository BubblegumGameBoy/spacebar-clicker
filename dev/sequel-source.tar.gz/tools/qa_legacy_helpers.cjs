'use strict';
// Visible-input helpers for the published M1/M2 build (no M3 ground tool API assumed).
module.exports=(page,touch,cdp)=>{const touchEvent=(type,p)=>cdp.send('Input.dispatchTouchEvent',{type,touchPoints:p?[p]:[]});
 const screen=p=>page.evaluate(p=>{const r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return{x:r.left+p.x*z,y:r.top+p.y*z};},p);
 const tap=async(q,hold=60)=>{if(touch){await touchEvent('touchStart',q);await page.waitForTimeout(hold);await touchEvent('touchEnd');}else await page.mouse.click(q.x,q.y);await page.waitForTimeout(130);};
 const press=async sel=>{for(let i=0;;i++){try{const el=page.locator(sel).first();await el.waitFor({state:'visible',timeout:3000});await el.scrollIntoViewIfNeeded({timeout:1000});const b=await el.boundingBox();if(b){await tap({x:b.x+b.width/2,y:b.y+b.height/2});return;}}catch(e){if(i>=5)throw e;}await page.waitForTimeout(150);}};
 const drag=async(a,z,steps=14)=>{if(touch){await touchEvent('touchStart',a);for(let i=1;i<=steps;i++){await touchEvent('touchMove',{x:a.x+(z.x-a.x)*i/steps,y:a.y+(z.y-a.y)*i/steps});await page.waitForTimeout(16);}await touchEvent('touchEnd');}else{await page.mouse.move(a.x,a.y);await page.mouse.down();await page.mouse.move(z.x,z.y,{steps});await page.mouse.up();}await page.waitForTimeout(150);};
 const field=()=>page.locator('#field').scrollIntoViewIfNeeded();
 const tree=()=>page.evaluate(()=>{const n=S.factory.nodes.find(n=>n.type==='wood'&&n.stock>0),r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return{x:r.left+n.x*z,y:r.top+(n.y-48)*z};});
 const pile=()=>page.evaluate(()=>{const d=S.factory.drops.find(d=>d.type==='wood'&&!d.onConveyor&&!SupplyFactory.isAirborne(d));if(!d)return null;const b=SupplyFactory.pileBounds(d),r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return{x:r.left+(b.left+b.right)*.5*z,y:r.top+(b.top+b.bottom)*.5*z};});
 const harvest=async n=>{await field();for(let i=0;i<400;i++){if(await page.evaluate(()=>S.factory.drops.filter(d=>d.type==='wood'&&!d.worker&&!d.onConveyor).length)>=n)return;await tap(await tree(),40);}throw new Error('harvest stuck');};
 const deliver=async()=>{await field();for(let i=0;i<60;i++){const p=await pile();if(!p)return;await drag(p,await screen({x:100,y:290}));}};
 return {screen,tap,press,drag,field,harvest,deliver};};
