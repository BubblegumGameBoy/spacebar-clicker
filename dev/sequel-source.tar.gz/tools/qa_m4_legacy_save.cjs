/* M4 prepared test: a save made by visible play on the pre-M1 build (conveyors from the start; OLD_URL, e.g. a
   `git archive 81b7b72 preview assets` served locally) is loaded into the M4 build.
   Checks (PC mouse and CDP touch; CDP touch is not a real device):
   - belts (points, cost), items riding them, cargo, inventory and work skills are unchanged; logisticsVersion 2;
   - catalogue: blower/fence open, wooden conveyor / hopper / platform locked before Chapter 1;
   - the kept belt still delivers; its removal card says it cannot be rebuilt yet, in ja / en / zh;
   - removing it with the card refunds half and the conveyor stays locked;
   - prepared step (state edit, marked as such): Chapter 1 cleared -> the unlock milestone once, cards open, the
     removal card no longer carries the note. */
'use strict';
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const OLD=(process.env.OLD_URL||'http://127.0.0.1:4452/preview/')+'?lesson=1',NEW=(process.env.GAME_URL||'http://127.0.0.1:4451/preview/')+'?lesson=1',OUT=process.env.QA_OUT||'/tmp/qa-m4-legacy';fs.mkdirSync(OUT,{recursive:true});
const helpers=require('./qa_m4_helpers.cjs'),legacyHelpers=require('./qa_legacy_helpers.cjs');
async function makeOldSave(browser){
 const ctx=await browser.newContext({viewport:{width:1280,height:900}}),page=await ctx.newPage(),errors=[],h=legacyHelpers(page,false,null);page.on('pageerror',e=>errors.push(e.message));
 await page.goto(OLD);await page.waitForTimeout(1200);await h.press('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);await page.waitForTimeout(400);
 await h.harvest(10);await h.deliver();await h.press('#onboardingAction');await page.waitForTimeout(400);await h.press('[data-harvest-learn]:not([disabled])');await page.keyboard.press('Escape');await page.waitForTimeout(300);
 await h.harvest(6);await h.deliver();await h.press('[data-recruit="woodcutter"]');await page.waitForTimeout(400);await h.field();const spot=(await page.evaluate(()=>BattleControl.spots()))[0];await h.drag(await h.screen(spot),await h.screen(spot),2);
 const land=await page.evaluate(()=>{const p=ArmyView.sim.soldiers.find(p=>p.id==='woodcutter'),n=S.factory.nodes.filter(n=>n.type==='wood').sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y))[0];return SupplyFactory.outputForWorker(p,n);});
 await h.harvest(8);await h.deliver();await h.press('[data-equipment="belt"]');await page.waitForTimeout(300);await h.field();await h.drag(await h.screen({x:162,y:328}),await h.screen({x:land.x+12,y:land.y+6}),18);
 const before=await page.evaluate(()=>S.factory.delivered);await page.waitForFunction(d=>S.factory.delivered>d,before,{timeout:30000});
 // stop with a log riding the belt, then save
 await page.waitForFunction(()=>S.factory.drops.some(d=>d.onConveyor&&d.beltId),null,{timeout:20000}).catch(()=>{});await page.evaluate(()=>typeof save==='function'&&save());await page.waitForTimeout(300);
 const old={state:await page.evaluate(()=>({links:S.camp.links.map(l=>({nodeKey:l.nodeKey,kind:l.kind,points:l.points,costWood:l.costWood})),riding:S.factory.drops.filter(d=>d.onConveyor).map(d=>({key:d.key,beltId:d.beltId??null})),skills:S.harvestSkills,inventory:S.factory.inventory,cargo:S.camp.cargo.length,cleared:S.outpost.cleared})),storage:await page.evaluate(()=>{const out={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);out[k]=localStorage[k];}return out;})};
 await page.screenshot({path:path.join(OUT,'old-build-belt.png')});assert.deepEqual(errors,[]);await ctx.close();return old;
}
async function loadNew(browser,old,mode){
 const touch=mode==='touch',ctx=await browser.newContext({...(touch?{viewport:{width:390,height:844},hasTouch:true,isMobile:true,deviceScaleFactor:2}:{viewport:{width:1280,height:900}})});await ctx.addInitScript(helpers.cueCounter);
 // The old build is on another origin: copy its saved keys once, exactly as stored.
 await ctx.addInitScript(storage=>{if(sessionStorage.getItem('__m4_seeded'))return;for(const [k,v] of Object.entries(storage))localStorage.setItem(k,v);sessionStorage.setItem('__m4_seeded','1');},old.storage);
 const page=await ctx.newPage(),cdp=touch?await ctx.newCDPSession(page):null,h=helpers.make(page,{touch,cdp,out:OUT,tag:mode}),checks=[];
 const open=async lang=>{await page.goto(NEW);await page.waitForTimeout(1000);if(await page.locator('#titleBattle').isVisible())await h.press('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);await page.waitForTimeout(500);
  if(lang){await h.press('#langBtn');await page.waitForTimeout(300);await h.press('.ts-lang[data-lang="'+lang+'"]');await page.waitForTimeout(300);if(await page.locator('#titleBattle').isVisible())await h.press('#titleBattle');await page.waitForTimeout(400);}};
 const selectBelt=async()=>{await h.field();const p=await page.evaluate(()=>{const ps=ConveyorCore.oriented(S.camp.links[0]);return ConveyorCore.at(ps,ConveyorCore.length(ps)*.45);});const q=await h.screen(p);if(touch){await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[q]});await page.waitForTimeout(700);await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await page.waitForTimeout(200);if((await page.evaluate(()=>OutpostCamp.selection))?.kind!=='belt')await h.tap(q);}else await h.tap(q);await page.waitForTimeout(200);assert.equal(await page.evaluate(()=>OutpostCamp.selection?.kind),'belt');return page.locator('[data-pick-action="remove"]').textContent();};
 try{
  await open(null);
  const s=await page.evaluate(()=>({links:S.camp.links.map(l=>({nodeKey:l.nodeKey,kind:l.kind,points:l.points,costWood:l.costWood})),riding:S.factory.drops.filter(d=>d.onConveyor).map(d=>({key:d.key,beltId:d.beltId??null})),skills:S.harvestSkills,inventory:S.factory.inventory,cargo:S.camp.cargo.length,v:S.camp.logisticsVersion,legacy:S.camp.legacyBelts,hoppers:S.camp.hoppers,seen:S.camp.conveyorUnlockSeen}));
  assert.deepEqual(s.links,old.state.links);checks.push('belts kept exactly ('+s.links.length+', length '+Math.round(await page.evaluate(()=>ConveyorCore.length(S.camp.links[0].points)))+')');
  const now=new Map(s.riding.map(d=>[d.key,d.beltId]));for(const d of old.state.riding)if(now.has(d.key))assert.equal(now.get(d.key),d.beltId,'rides the same belt');checks.push('items on belts: '+old.state.riding.length+' before, '+s.riding.length+' after load');
  assert.deepEqual(s.skills,old.state.skills);assert.deepEqual(s.inventory,old.state.inventory);checks.push('work skills and inventory unchanged '+JSON.stringify(s.skills));
  assert.equal(s.v,2);assert.equal(s.legacy,true);assert.deepEqual(s.hoppers,[]);
  assert.deepEqual(await h.cards(),[['blower',false],['fence',false],['belt',true],['hopper',true],['platform',true]]);checks.push('conveyor, hopper and platform locked before chapter 1');
  const d0=await page.evaluate(()=>S.factory.delivered);await page.waitForFunction(d=>S.factory.delivered>d,d0,{timeout:30000});checks.push('the kept belt still delivers');
  const labels={};for(const lang of ['ja','en','zh']){await open(lang);labels[lang]=await selectBelt();await h.shot('belt-card-'+lang);await page.keyboard.press('Escape').catch(()=>{});}
  assert.match(labels.ja,/解放前のため敷き直せません/);assert.match(labels.en,/Cannot be rebuilt until unlocked/);assert.match(labels.zh,/解锁前无法重建/);checks.push('removal card: '+JSON.stringify(labels));
  await open('ja');const w0=(await h.read()).wood;await selectBelt();await h.press('[data-pick-action="remove"]');await page.waitForTimeout(300);const after=await h.read();assert.equal(after.links,s.links.length-1);checks.push('removed with the card: wood '+Math.floor(w0)+' -> '+Math.floor(after.wood)+' (half of '+s.links[0].costWood+')');
  assert.deepEqual((await h.cards()).find(c=>c[0]==='belt'),['belt',true]);checks.push('still locked after removal');
  // Prepared step: Chapter 1 cleared by a state edit (not earned here).
  await page.evaluate(()=>{S.outpost.cleared=3;S.clearedBossWave=Math.max(S.clearedBossWave||0,3);});await page.waitForFunction(()=>S.camp.conveyorUnlockSeen===true,null,{timeout:5000});
  const u=await page.evaluate(()=>({banner:OutpostCamp.unlockBannerActive,cues:window.__cues.filter(c=>c==='unlock').length}));assert.equal(u.banner,true);assert.equal(u.cues,1);await h.field();await h.shot('unlocked');
  assert.deepEqual(await h.cards(),[['blower',false],['fence',false],['belt',false],['hopper',false],['platform',false]]);checks.push('prepared: chapter 1 -> milestone once ('+JSON.stringify(u)+'), cards open');
  await page.evaluate(()=>typeof save==='function'&&save());await open('ja');assert.equal(await page.evaluate(()=>window.__cues.filter(c=>c==='unlock').length),0);checks.push('after reload: no second milestone');
  assert.deepEqual(h.errors,[]);return {mode,status:'passed',checks};
 }catch(e){await h.shot('FAIL').catch(()=>{});return {mode,status:'failed',message:e.stack,errors:h.errors,checks};}finally{await ctx.close();}
}
(async()=>{const browser=await chromium.launch();const results=[];let old=null;try{old=await makeOldSave(browser);for(const m of (process.env.QA_MODES||'pc,touch').split(','))results.push(await loadNew(browser,old,m));}catch(e){results.push({status:'failed',message:e.stack});}finally{await browser.close();}
 fs.writeFileSync(path.join(OUT,'result.json'),JSON.stringify({fixture:'Save made by visible play on the pre-M1 build ('+OLD+'), loaded into the M4 build; one prepared step (Chapter 1 set by state edit) is marked; touch is CDP touch',old:old&&{links:old.state.links.length,riding:old.state.riding.length,skills:old.state.skills},results},null,2));console.log(JSON.stringify(results,null,1));if(!results.length||results.some(r=>r.status!=='passed'))process.exitCode=1;})();
