/* Prepared near-breach / deadline / capacity fixtures; not an earned campaign.
   UI actions use a mouse or CDP touch. Audio observations preserve native playback. */
'use strict';
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
const {make}=require('./qa_m4_helpers.cjs');
const URL=process.env.GAME_URL||'http://127.0.0.1:4423/preview/?lesson=2';
const OUT=process.env.QA_OUT||'/tmp/mythos-defeat-qa';fs.mkdirSync(OUT,{recursive:true});
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium'}),rows=[];
 try{for(const touch of [false,true])for(const lang of ['ja','en','zh']){
  const context=await browser.newContext({viewport:touch?{width:390,height:844}:{width:1280,height:900},isMobile:touch,hasTouch:touch});
  await context.addInitScript(lang=>localStorage.setItem('sbr_lang',lang),lang);
  const page=await context.newPage(),cdp=touch?await context.newCDPSession(page):null,h=make(page,{touch,cdp,out:OUT,tag:lang+(touch?'-touch':'-pc')});
  try{
   await page.goto(URL+'&lang='+lang);if(await page.locator('#titleBattle').isVisible())await h.press('#titleBattle');
   await page.waitForFunction(()=>Outpost.ready&&SupplyFactory.artReady);
   assert.equal(await page.evaluate(()=>LANG),lang);
   // A trained squad and three actual plan enemies about to breach. A fourth stays on the road.
   const before=await page.evaluate(()=>{
    Rework.close();S.tutorial.started=true;S.tutorial.woodDelivered=2;S.firstWorkerPickup=true;
    const e=ExpeditionCore.ensure(S);e.groups=[{key:1,id:'arch',count:3,tier:1,active:true,pending:0,policy:'armor',anchor:{x:780,y:120},positions:[{x:780,y:120},{x:770,y:120},{x:790,y:120}]}];e.nextKey=2;e.coins=5;e.awaitingDecision=false;e.awaitingReady=false;
    S.factory.inventory={wood:77,stone:42,food:9};S.gold=123;
    const o=OutpostCore.fresh();o.wave=8;o.cleared=7;o.claimedFirst=[1,2,3,4,5,6,7];OutpostCore.start(o);OutpostCore.tick(o,OutpostCore.planFor(o).spawns[3].at);
    for(const enemy of o.enemies.slice(0,3)){enemy.travel=OutpostCore.lengthOf(enemy);enemy.atGate=true;enemy.gateTime=.99;enemy.x=OutpostCore.WORLD.home.x;enemy.y=OutpostCore.WORLD.home.y;}
    S.outpost=o;ExpeditionIntegration.refresh();Outpost.update();
    return {inventory:{...S.factory.inventory},gold:S.gold,coins:e.coins,claimedFirst:[...o.claimedFirst]};
   });
   await page.waitForSelector('.expedition-loss-reason');
   const failure=await page.evaluate(()=>({reason:S.outpost.result.reason,escaped:S.outpost.escaped,boxes:S.outpost.boxes,gold:S.gold,remaining:S.outpost.enemies.filter(e=>e.alive).length,elapsed:S.outpost.elapsed}));
   assert.equal(failure.reason,'crates');assert.equal(failure.escaped,3);assert.equal(failure.boxes,0);assert.equal(failure.gold,before.gold);assert.ok(failure.remaining>0);
   assert.match(await page.locator('[data-expedition-action="retry"]').innerText(),/7/);
   assert.match(await page.locator('.expedition-retry-cost').innerText(),/0G|0。/);
   await h.shot('crates-loss');
   await h.press('[data-expedition-action="retry"]');
   assert.deepEqual(await page.evaluate(()=>({wave:S.outpost.wave,phase:S.outpost.phase,count:S.expedition.groups[0].count,policy:S.expedition.groups[0].policy,inventory:S.factory.inventory,gold:S.gold,coins:S.expedition.coins,first:S.outpost.claimedFirst,held:S.expedition.awaitingReady})),{wave:7,phase:'prep',count:3,policy:'armor',inventory:before.inventory,gold:before.gold,coins:before.coins,first:before.claimedFirst,held:true});
   assert.equal(await page.locator('[data-expedition-action="return"]').isDisabled(),false,'Earned results remain bankable after choosing retry');
   await h.press('.expedition-rules summary');assert.equal(await page.locator('.expedition-rules').getAttribute('open'),'');
   await h.shot('retry-rules');
   await h.press('.expedition-close');await page.reload();await page.waitForFunction(()=>Outpost.ready&&SupplyFactory.artReady);
   const factoryTime=await page.evaluate(()=>S.factory.time);await page.waitForTimeout(1100);
   assert.deepEqual(await page.evaluate(()=>({wave:S.outpost.wave,prep:S.outpost.prepRemaining,held:S.expedition.awaitingReady,count:S.expedition.groups[0].count})),{wave:7,prep:90,held:true,count:3});
   assert.ok(await page.evaluate(t=>S.factory.time>t+.5,factoryTime));
   await h.press('#expeditionNotice button');await h.press('[data-expedition-action="ready"]');await page.waitForFunction(()=>!S.expedition.awaitingReady);
   assert.ok(await page.evaluate(()=>S.outpost.prepRemaining>88&&S.outpost.prepRemaining<=90));
   assert.equal(await page.locator('.raid-rule').isVisible(),true);
   // Final captain gets through even while two crates remain.
   await page.evaluate(()=>{
    const o=OutpostCore.fresh();o.wave=9;OutpostCore.start(o);const p=OutpostCore.planFor(o),boss=p.spawns.find(e=>e.kind==='chief');o.elapsed=boss.at;OutpostCore.tick(o,0);
    for(const e of o.enemies)if(e.kind!=='chief')OutpostCore.hit(o,e.key,10000,'arch');
    const b=o.enemies.find(e=>e.kind==='chief');b.travel=OutpostCore.lengthOf(b);b.atGate=true;b.gateTime=.99;b.x=OutpostCore.WORLD.home.x;b.y=OutpostCore.WORLD.home.y;
    S.expedition.groups=[];ExpeditionCore.project(S);S.expedition.awaitingDecision=false;S.expedition.awaitingReady=false;S.outpost=o;Outpost.update();
   });
   await page.waitForSelector('.expedition-loss-reason');assert.deepEqual(await page.evaluate(()=>({reason:S.outpost.result.reason,boxes:S.outpost.boxes,escaped:S.outpost.escaped,gold:S.outpost.result.gold})),{reason:'captain',boxes:2,escaped:1,gold:0});
   await h.shot('captain-loss');await h.press('[data-expedition-action="retry"]');await h.press('.expedition-close');
   // Timeout leaves a real survivor on the road; it is not a breakthrough.
   await page.evaluate(()=>{
    const o=OutpostCore.fresh();OutpostCore.start(o);OutpostCore.tick(o,12);for(const e of o.enemies.slice(0,-1))OutpostCore.hit(o,e.key,10000,'arch');o.elapsed=OutpostCore.planFor(o).duration-.02;
    S.expedition.awaitingDecision=false;S.expedition.awaitingReady=false;S.outpost=o;Outpost.update();
   });
   await page.waitForSelector('.expedition-loss-reason');assert.deepEqual(await page.evaluate(()=>({reason:S.outpost.result.reason,boxes:S.outpost.boxes,escaped:S.outpost.escaped,remaining:S.outpost.enemies.filter(e=>e.alive).length})),{reason:'timeout',boxes:3,escaped:0,remaining:1});
   await h.shot('timeout-loss');await h.press('[data-expedition-action="retry"]');await h.press('.expedition-close');
   // Fill the ground. No worker emits warnings: only the player's rejected harvest does.
   const node=await page.evaluate(()=>{
    const s=SupplyFactory.state;s.drops=[];const n=SupplyFactory.choose('wood');n.stock=180;n.work=0;
    for(let i=0;i<SupplyFactory.stats.groundCapacity;i++)SupplyCore.drop(s,'wood',1,850+i%4*5,450+Math.floor(i/4)*2,n.key);
    SupplyFactory.translate();Outpost.update();return {x:n.x,y:n.y-48,key:n.key,stock:n.stock,work:n.work,limit:SupplyFactory.stats.groundCapacity};
   });
   await h.field();const target=await h.screen(node);
   await h.tap(target);const sound=await page.evaluate(()=>({at:ForestAudio.lastPlayed('groundBlocked'),stats:ForestAudio.stats}));assert.ok(Number.isFinite(sound.at));assert.ok(sound.stats.sounds.includes('groundBlocked'));
   await h.tap(target);assert.equal(await page.evaluate(()=>ForestAudio.lastPlayed('groundBlocked')),sound.at,'Repeated taps within 700ms are quiet');
   assert.deepEqual(await page.evaluate(key=>{const n=S.factory.nodes.find(n=>n.key===key);return {stock:n.stock,work:n.work,used:S.factory.drops.length,limit:SupplyFactory.stats.groundCapacity};},node.key),{stock:node.stock,work:node.work,used:node.limit,limit:node.limit});
   await page.evaluate(()=>ForestAudio.setSe(false));await page.waitForTimeout(750);await h.tap(target);assert.equal(await page.evaluate(()=>ForestAudio.lastPlayed('groundBlocked')),sound.at,'SE off suppresses the rejection sound');
   await page.evaluate(()=>{ForestAudio.setSe(true);S.factory.drops.pop();});
   await h.tap(target);assert.equal(await page.evaluate(()=>ForestAudio.lastPlayed('groundBlocked')),sound.at,'A successful strike after clearing space does not play rejection');
   const resumed=await page.evaluate(key=>{const n=S.factory.nodes.find(n=>n.key===key);return {stock:n.stock,work:n.work};},node.key);assert.ok(resumed.work>node.work||resumed.stock<node.stock,'Clearing capacity really resumes gathering');
   const size=await page.evaluate(()=>({width:innerWidth,body:document.documentElement.scrollWidth,overflow:[...document.querySelectorAll('.expedition-dialog,.expedition-body,#raidBoard')].filter(e=>e.offsetWidth&&e.scrollWidth>e.clientWidth+2).map(e=>e.className||e.id)}));
   assert.ok(size.body<=size.width+1);assert.deepEqual(size.overflow,[]);assert.deepEqual(h.errors,[]);
   rows.push({lang,input:touch?'CDP touch':'mouse',status:'passed',failure,checks:['Zero crates stops immediately; unresolved raiders are not breakthroughs','Loss earns no gold','Wave 8 retries at 7 with paid reinforcements, stock, coins and reward receipts intact','Reload holds preparation while production time advances; Ready starts 90 seconds','Escaped final captain fails with two crates left','Timeout reports a remaining raider instead of inventing a breach','Real full-ground pointer input plays a decoded rejection sound; rapid repeat and SE off are quiet; freed capacity permits harvesting','Rules and controls fit the viewport'],errors:h.errors});
  }finally{await context.close();}
 }}finally{await browser.close();}
 fs.writeFileSync(OUT+'/result.json',JSON.stringify({fixture:'Prepared battles and full-ground stock; no new-save balance claim',rows},null,2));console.log(JSON.stringify(rows));
})().catch(e=>{console.error(e);process.exitCode=1;});
