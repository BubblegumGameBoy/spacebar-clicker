// Prepared layout + real-pointer regression. CDP touch is emulation, not physical hardware.
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
const OUT=process.env.QA_OUT||'/tmp/qa-warehouse-dock';fs.mkdirSync(OUT,{recursive:true});
const URL=process.env.GAME_URL||'http://127.0.0.1:4468/preview/';
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium'}),rows=[];
try{for(const mobile of [false,true])for(const lang of ['ja','en','zh']){
 const context=await browser.newContext({viewport:mobile?{width:390,height:844}:{width:1280,height:900},hasTouch:mobile,isMobile:mobile});
 const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(lang=>localStorage.setItem('sbr2_preview_outpost_lang',lang),lang);await page.goto(URL+'?lesson=1&lang='+lang);if(await page.locator('#titleBattle').isVisible())await page.locator('#titleBattle').click();await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);await page.waitForTimeout(350);
 // Prepared: turn off worker production; show food to exercise all three material columns.
 await page.evaluate(()=>{S.factory.inventory.food=17;S.expedition.unlocks.farmer=true;SupplyFactory.ensureFarm();for(const u of ArmyView.sim.soldiers)u.cooldown=1e9;S.factory.drops.length=0;const d=SupplyCore.drop(S.factory,'wood',1,100,410,1,240);d.physical=true;SupplyFactory.translate();});
 await page.waitForTimeout(350);const layout=await page.evaluate(()=>{const a=document.getElementById('campWarehouse').getBoundingClientRect(),b=document.getElementById('field').getBoundingClientRect();return {parent:document.getElementById('campWarehouse').parentElement.id,dock:{x:a.x,y:a.y,w:a.width,h:a.height},field:{x:b.x,y:b.y,w:b.width,h:b.height},overlap:a.left<b.right&&a.right>b.left&&a.top<b.bottom&&a.bottom>b.top,overflow:document.documentElement.scrollWidth>innerWidth,foodVisible:!document.getElementById('gatherFood').hidden,text:[...document.querySelectorAll('#campWarehouse .resource-buttons button:not([hidden])')].map(e=>({label:e.dataset.campLabel,width:e.clientWidth,overflow:e.scrollWidth>e.clientWidth+1}))};});
 assert.equal(await page.evaluate(()=>LANG),lang);assert.equal(layout.parent,'deckMain');assert.equal(layout.overlap,false);assert.equal(layout.overflow,false);assert.equal(layout.foodVisible,true);assert.ok(layout.text.every(e=>!e.overflow));
 await page.locator('#field').scrollIntoViewIfNeeded();
 const coords=await page.evaluate(()=>{const d=S.factory.drops.find(d=>d.type==='wood'),b=SupplyFactory.pileBounds(d),r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return {from:{x:r.left+(b.left+b.right)/2*z,y:r.top+(b.top+b.bottom)/2*z},to:{x:r.left+100*z,y:r.top+300*z},wood:S.factory.inventory.wood};});
 const cdp=mobile?await context.newCDPSession(page):null;
 if(mobile)await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[coords.from]});else{await page.mouse.move(coords.from.x,coords.from.y);await page.mouse.down();}
 assert.equal(await page.evaluate(()=>OutpostCamp.dragging),true,'piece below the old card can be grabbed');
 if(mobile)await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[coords.to]});else await page.mouse.move(coords.to.x,coords.to.y,{steps:8});
 await page.waitForTimeout(100);assert.equal(await page.locator('#field').evaluate(e=>e.classList.contains('delivery-ready')),true,'house accepts piece');await page.screenshot({path:OUT+'/'+(mobile?'touch':'pc')+'-'+lang+'-receiving.png'});
 if(mobile)await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});else await page.mouse.up();await page.waitForTimeout(200);
 assert.equal(await page.evaluate(()=>S.factory.inventory.wood),coords.wood+1,'same piece delivered once');assert.equal(await page.evaluate(()=>S.factory.drops.length),0);assert.deepEqual(errors,[]);
 rows.push({mode:mobile?'CDP touch (not physical device)':'PC',lang,layout,grabAndDeliver:true,pageErrors:errors});await context.close();
}}finally{await browser.close();}fs.writeFileSync(OUT+'/result.json',JSON.stringify({fixture:'Prepared supplies; no earned progression claimed.',rows},null,2));console.log(JSON.stringify(rows));})().catch(e=>{console.error(e);process.exitCode=1;});
