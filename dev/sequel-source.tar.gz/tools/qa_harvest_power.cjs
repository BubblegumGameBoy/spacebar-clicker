/* Fresh visible pointer input; no material grants/time edits. CDP touch is browser emulation, not a physical device. */
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
const {make}=require('./qa_m4_helpers.cjs');
const OUT=process.env.QA_OUT||'/tmp/qa-harvest-power';fs.mkdirSync(OUT,{recursive:true});
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium'}),rows=[];
try{for(const touch of [false,true]){
 const mode=touch?'touch':'pc',context=await browser.newContext({viewport:touch?{width:390,height:844}:{width:1280,height:900},hasTouch:touch,isMobile:touch}),page=await context.newPage(),cdp=touch?await context.newCDPSession(page):null,h=make(page,{touch,cdp,out:OUT,tag:mode});
 try{
  await page.goto(process.env.GAME_URL||'http://127.0.0.1:4436/preview/?lesson=1');await h.press('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);
  const reach=await page.evaluate(()=>{const n=S.factory.nodes.find(n=>n.type==='wood');return {range:SupplyFactory.WORK_RANGE,edge:SupplyFactory.nearby({x:n.x+64+n.radius,y:n.y},'wood')?.key===n.key,beyond:SupplyFactory.workerInRange({x:n.x+65+n.radius,y:n.y},n)};});assert.equal(reach.range,64);assert.equal(reach.edge,true);assert.equal(reach.beyond,false);
  const read=()=>page.evaluate(()=>({wood:S.factory.nodes.find(n=>n.type==='wood'),stone:S.factory.nodes.find(n=>n.type==='stone'),drops:S.factory.drops.length,inventory:{...S.factory.inventory},capacity:SupplyFactory.stats.groundCapacity}));
  for(let i=0;i<2;i++){await h.tap(await h.nodeAt('wood'));const r=await read();assert.equal(r.drops,0);assert.equal(r.wood.work,i+1);}
  await h.shot('partial-work');await page.reload();if(await page.locator('#titleBattle').isVisible())await h.press('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);assert.equal((await read()).wood.work,2,'partial work persisted without granting output');
  await h.tap(await h.nodeAt('wood'));assert.equal((await read()).drops,1);assert.equal((await read()).wood.work,0);
  for(let i=0;i<4;i++){await h.tap(await h.nodeAt('stone'));assert.equal((await read()).drops,1);}
  await h.tap(await h.nodeAt('stone'));assert.equal((await read()).drops,2);
  while((await read()).drops<(await read()).capacity){await h.tap(await h.nodeAt('wood'));}
  await page.waitForTimeout(500);const full=await read();await h.shot('ground-full');assert.equal(await page.locator('#groundCapacityWarning').isVisible(),true);assert.equal(await page.locator('body.ground-full').count(),1);
  for(let i=0;i<4;i++)await h.tap(await h.nodeAt('wood'));const blocked=await read();assert.equal(blocked.drops,full.drops);assert.equal(blocked.wood.stock,full.wood.stock);assert.equal(blocked.wood.work,full.wood.work);
  await h.deliver('wood',1);await page.waitForTimeout(400);assert.equal((await read()).drops,full.drops-1);assert.equal(await page.locator('#groundCapacityWarning').isVisible(),false);
  for(let i=0;i<3;i++)await h.tap(await h.nodeAt('wood'));assert.equal((await read()).drops,full.drops,'production naturally resumes after a delivery');
  assert.deepEqual(h.errors,[]);rows.push({mode,status:'passed',fixture:'Fresh strikes and manual delivery only; reload preserves work; no state grants or acceleration',full:{ground:full.drops,cap:full.capacity},errors:h.errors});
 }catch(e){await h.shot('FAIL').catch(()=>{});rows.push({mode,status:'failed',message:e.stack,errors:h.errors});}
 finally{await context.close();}
}}finally{await browser.close();}
fs.writeFileSync(OUT+'/result.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));if(rows.some(r=>r.status!=='passed'))process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1;});
