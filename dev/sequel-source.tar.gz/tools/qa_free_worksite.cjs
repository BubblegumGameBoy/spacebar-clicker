/* Prepared material fixture. Real recruitment, freely chosen positions, pointer/touch aiming and natural harvest.
   No production/time/result edits. CDP touch emulates input and is not physical hardware. */
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),{make}=require('./qa_m4_helpers.cjs');
const OUT=process.env.QA_OUT||'/tmp/qa-free-worksite';fs.mkdirSync(OUT,{recursive:true});
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/chromium'}),rows=[];
try{for(const touch of [false,true]){
 const mode=touch?'touch':'pc',ctx=await b.newContext({viewport:touch?{width:390,height:844}:{width:1280,height:900},hasTouch:touch,isMobile:touch}),p=await ctx.newPage(),cdp=touch?await ctx.newCDPSession(p):null,h=make(p,{touch,cdp,out:OUT,tag:mode});
 try{
  await p.goto(process.env.GAME_URL||'http://127.0.0.1:4418/preview/');await h.press('#titleBattle');await p.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);
  await p.evaluate(()=>{S.factory.inventory.wood=60;S.factory.inventory.stone=20;S.tutorial.woodDelivered=2;OutpostTutorial.sync(true);renderCards();SupplyFactory.translate();});
  const sites=await p.evaluate(()=>S.factory.nodes.map(n=>({type:n.type,x:n.x,y:n.y})));assert.equal(sites[0].x,340);assert.equal(sites[1].x,620);assert.equal(sites[2].x,430);
  await h.press('[data-recruit="woodcutter"]');await h.field();const far={x:860,y:285};await h.drag(await h.screen(far),await h.screen(far),2);await p.waitForFunction(()=>!S.pending.woodcutter);
  await p.waitForTimeout(6100);assert.equal(await p.evaluate(()=>S.factory.drops.filter(d=>d.worker).length),0,'worker with no tree in range waits');await h.shot('freely-placed-idle');
  const near={x:270.5,y:315.5};await h.tap(await h.screen({x:far.x,y:far.y-20}));await p.waitForFunction(()=>BattleControl.placement);await h.drag(await h.screen(near),await h.screen(near),2);
  const placed=await p.evaluate(()=>{const q=ArmyView.sim.soldiers.find(q=>q.id==='woodcutter');return{x:q.x,y:q.y,node:SupplyFactory.nearby(q,'wood')?.key};});assert.ok(Math.hypot(placed.x-near.x,placed.y-near.y)<1.1,'position stays where the player released, no marker snapping');assert.equal(placed.node,1);
  await p.waitForFunction(()=>S.factory.drops.some(d=>d.worker),null,{timeout:10000});await h.shot('freely-placed-working');
  const underLeaves={x:340,y:240};assert.equal(await p.evaluate(q=>OutpostCamp.canPlaceBlower(q),underLeaves),true,'canopy is not an invisible placement wall');
  await h.press('[data-equipment="blower"]');await h.field();await h.drag(await h.screen(underLeaves),await h.screen(underLeaves),2);await p.waitForFunction(()=>S.camp.blowers.length===1);
  const beforeAim=await p.evaluate(()=>({...S.camp.blowers[0]}));await h.drag(await h.screen(underLeaves),await h.screen({x:340,y:325}),12);
  const afterAim=await p.evaluate(()=>({...S.camp.blowers[0]}));assert.equal(afterAim.dir,2,'drag aims south in a single gesture');assert.equal(afterAim.x,beforeAim.x);assert.equal(afterAim.y,beforeAim.y);await h.shot('fan-drag-aimed');
  // A second manually placed fan is chosen by reading the same physical prediction the player sees.
  const plan=await p.evaluate(()=>{const q=ArmyView.sim.soldiers.find(q=>q.id==='woodcutter'),n=SupplyFactory.nearby(q,'wood'),base=SupplyFactory.outputForWorker(q,n);let best=null;for(let dx=24;dx<=90;dx+=10)for(let dy=-20;dy<=30;dy+=10){const at={x:Math.round(base.x+dx),y:Math.round(base.y+dy),dir:4};if(!OutpostCamp.canPlaceBlower(at))continue;const home=SupplyFactory.groundShare(base,{...at,kind:'blower'});if(!best||home>best.home)best={...at,home};}return best;});assert.ok(plan?.home>0);
  await h.press('[data-equipment="blower"]');await h.field();await h.drag(await h.screen(plan),await h.screen(plan),2);await p.waitForFunction(()=>S.camp.blowers.length===2);
  await p.waitForFunction(()=>S.tutorial.blownWood>0,null,{timeout:35000});await h.shot('player-built-wind-delivery');
  assert.deepEqual(h.errors,[]);rows.push({mode,status:'passed',fixture:'Prepared material grant only; real pointer placement and natural worker/physics output',sites,idlePoint:far,workingPoint:placed,beforeAim,afterAim,plan,errors:h.errors});
 }catch(e){await h.shot('FAIL').catch(()=>{});rows.push({mode,status:'failed',message:e.stack,errors:h.errors});}finally{await ctx.close();}
}}finally{await b.close();}
fs.writeFileSync(OUT+'/result.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));if(rows.some(r=>r.status!=='passed'))process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1;});
