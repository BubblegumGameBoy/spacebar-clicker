/* Prepared troops exercise actual browser controls, defeat, save and retry. */
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {chromium}=require('playwright');
const {make}=require('./qa_m4_helpers.cjs');
const output=process.env.QA_OUT||'../review-recovery';
fs.mkdirSync(output,{recursive:true});
const base=process.env.GAME_URL||'http://127.0.0.1:4427/preview/?slot=campaign-recovery-qa';

(async()=>{
 const browser=await chromium.launch({args:['--mute-audio'],executablePath:process.env.CHROMIUM_PATH||'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe'});
 const results=[];
 try{
  for(const [width,height,touch] of [[1280,900,false],[390,844,true],[844,390,true]]){
   const context=await browser.newContext({viewport:{width,height},hasTouch:touch,isMobile:touch});
   const page=await context.newPage(),cdp=touch?await context.newCDPSession(page):null;
   const input=make(page,{touch,cdp,out:output,tag:width+'x'+height});
   await page.goto(base);
   await page.waitForFunction(()=>window.TerritoryUI?.ready&&SupplyFactory.artReady);
   await input.press('#titleBattle');
   if(!touch){
    await page.keyboard.press('m');
    assert.equal(await page.locator('#territoryMapOverlay').isVisible(),true);
    await page.keyboard.press('m');
    assert.equal(await page.locator('#territoryMapOverlay').isVisible(),false);
   }
   await page.evaluate(()=>{
    S.owned.arch=1;
    S.factory.inventory.wood=27;
    S.factory.inventory.stone=16;
    S.pending={};
    S.battle={width:1600,height:900,captain:{x:150,y:370},units:[['arch',0,515,210,-1,-1]]};
    S.expedition=null;
    ExpeditionCore.ensure(S);
    ExpeditionCore.project(S);
    ArmyView.reloadFormation();
    BattleControl.setPlacement(false);
    TerritoryUI.sync(true);
    save();
   });
   const prior=await page.evaluate(()=>({stock:{...S.factory.inventory},gold:S.gold}));
   await input.press('#territoryMapButton');
   await input.press('[data-territory-site="2"]');
   await input.press('#territoryDepart');
   await page.waitForFunction(()=>S.invasion.phase==='march');
   if(touch)await input.press('#territoryRetreat');
   else{
    await page.locator('#territoryRetreat').focus();
    await page.keyboard.press('Space');
   }
   await page.waitForFunction(()=>S.invasion.phase==='return'||S.invasion.phase==='idle');
   await page.waitForFunction(()=>S.invasion.phase==='idle');
   assert.match(await page.locator('.territory-scene-name').innerText(),/南の前哨から撤退/);
   await input.shot('retreat-result');
   await page.reload();
   await page.waitForFunction(()=>window.TerritoryUI?.ready&&SupplyFactory.artReady);
   assert.match(await page.locator('.territory-scene-name').innerText(),/南の前哨から撤退/);
   assert.deepEqual(await page.evaluate(()=>({stock:{...S.factory.inventory},gold:S.gold})),prior);
   await input.press('#territoryReinforce');
   assert.equal(await page.locator('[data-cabin-tab=expedition]').getAttribute('aria-selected'),'true');
   await input.press('[data-cabin-close]');
   await input.press('#territoryMapButton');
   assert.equal(await page.locator('[data-territory-site][aria-pressed=true]').getAttribute('data-territory-site'),'2');
   await input.press('#territoryDepart');
   await page.waitForFunction(()=>S.invasion.phase==='march');
   if(!touch){
    await page.waitForFunction(()=>S.invasion.phase==='idle',null,{timeout:80000});
    assert.deepEqual(await page.evaluate(()=>S.invasion.conquered),[2]);
    assert.equal(await page.evaluate(()=>S.invasion.outcome.win),true);
    await input.press('#territoryMapButton');
    assert.equal(await page.locator('[data-territory-site][aria-pressed=true]').getAttribute('data-territory-site'),'1');
    assert.equal(await page.locator('[data-territory-site="3"]').isDisabled(),true);
   }
   assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));
   assert.deepEqual(input.errors,[]);
   results.push({width,height,touch,retreat:true,reload:true,originalTarget:true,resourcePreserved:true,roster:true,realTimeWinAfterRetry:!touch});
   await context.close();
  }
  const context=await browser.newContext({viewport:{width:1280,height:900}});
  const page=await context.newPage();
  await page.goto(base);
  await page.waitForFunction(()=>window.TerritoryUI?.ready&&SupplyFactory.artReady);
  await page.locator('#titleBattle').click();
  await page.evaluate(()=>{
   S.owned.arch=1;
   S.pending={};
   S.battle={width:1600,height:900,captain:{x:150,y:370},units:[['arch',0,515,210,-1,-1]]};
   S.expedition=null;
   ExpeditionCore.ensure(S);
   ExpeditionCore.project(S);
   ArmyView.reloadFormation();
   BattleControl.setPlacement(false);
   S.invasion.conquered=Array.from({length:29},(_,index)=>index+1);
   S.invasion.selected=30;
   S.outpost.cleared=29;
   TerritoryUI.sync(true);
  });
  await page.locator('#territoryMapButton').click();
  await page.locator('#territoryDepart').click();
  await page.waitForFunction(()=>S.invasion.phase==='battle');
  await page.waitForFunction(()=>S.invasion.phase==='idle',null,{timeout:180000});
  const result=await page.evaluate(()=>({win:S.invasion.outcome.win,reason:S.invasion.outcome.reason,cleared:S.invasion.conquered.length,army:S.owned.arch}));
  assert.deepEqual(result,{win:false,reason:'rout',cleared:29,army:1});
  assert.match(await page.locator('.territory-scene-name').innerText(),/敗退/);
  assert.equal(await page.locator('#territoryEnding').isVisible(),false);
  await context.close();
  fs.writeFileSync(path.join(output,'result.json'),JSON.stringify({scenarios:results,lateDefeat:result},null,2));
  console.log(JSON.stringify({scenarios:results,lateDefeat:result}));
 }finally{await browser.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
