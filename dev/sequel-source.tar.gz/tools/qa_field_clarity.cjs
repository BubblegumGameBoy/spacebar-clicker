/* Prepared placement/visual regression. Materials are granted here, never called earned progression.
   All recruits, placement and drags use real mouse/CDP inputs. CDP is not physical hardware. */
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
const {make}=require('./qa_m4_helpers.cjs');
const OUT=process.env.QA_OUT||'/tmp/qa-field-clarity';fs.mkdirSync(OUT,{recursive:true});
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium'}),rows=[];
try{for(const touch of [false,true]){
 const mode=touch?'touch':'pc',context=await browser.newContext({viewport:touch?{width:390,height:844}:{width:1280,height:900},hasTouch:touch,isMobile:touch}),page=await context.newPage();
 const cdp=touch?await context.newCDPSession(page):null,h=make(page,{touch,cdp,out:OUT,tag:mode});
 try{
  await page.goto(process.env.GAME_URL||'http://127.0.0.1:4414/preview/');await h.press('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);
  await page.evaluate(()=>{S.factory.inventory.wood=60;S.factory.inventory.stone=20;S.tutorial.woodDelivered=2;S.tutorial.visibleOptions={worker:true,blower:true,defence:true,upgrade:true};OutpostTutorial.sync(true);renderCards();SupplyFactory.translate();});
  const spot=await h.placeAlly('woodcutter','p.x>300&&p.x<380&&p.y>290');
  const view=await page.evaluate(()=>({workerHeight:ArmyView.bodyHeight(UNITS.find(u=>u.id==='woodcutter')),archerHeight:ArmyView.bodyHeight(UNITS.find(u=>u.id==='arch')),ballistaHeight:ArmyView.bodyHeight(UNITS.find(u=>u.id==='ballista'))}));
  assert.equal(view.workerHeight,44);assert.equal(view.archerHeight,44);assert.equal(view.ballistaHeight,60);
  await h.shot('worker-scale');
  assert.equal(await page.evaluate(p=>OutpostCamp.canPlaceBlower(p),spot),false,'fan cannot sit on worker feet');
  // Player-side inspection of the exact previews to find a legal position. The game never places it for us.
  const plan=await page.evaluate(()=>{
   const p=ArmyView.sim.soldiers.find(p=>p.id==='woodcutter'),base=SupplyFactory.outputForWorker(p,SupplyFactory.nearby(p,'wood'));
   let best=null;for(let dx=24;dx<=96;dx+=12)for(let dy=-36;dy<=36;dy+=12){const q={x:Math.round(base.x+dx),y:Math.round(base.y+dy),dir:4};if(!OutpostCamp.canPlaceBlower(q))continue;const home=SupplyFactory.groundShare(base,{...q,kind:'blower'});if(!best||home>best.home)best={...q,home};}
   return best;
  });
  assert.ok(plan?.home>0,'there is a legal fan spot that really delivers worker logs');
  await h.press('[data-equipment="blower"]');await h.field();
  const q=await h.screen(plan);if(touch){await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[q]});}else{await page.mouse.move(q.x,q.y);await page.mouse.down();}
  await page.waitForTimeout(400);const draft=await page.evaluate(()=>OutpostCamp.draftDevice);assert.equal(draft.x,plan.x);assert.equal(draft.y,plan.y);assert.equal(draft.dir,plan.dir);await h.shot('blower-preview');
  if(touch)await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});else await page.mouse.up();
  await page.waitForFunction(()=>S.camp.blowers.length===1);const placed=await page.evaluate(()=>({...S.camp.blowers[0]}));assert.equal(placed.x,draft.x);assert.equal(placed.y,draft.y);assert.equal(placed.dir,draft.dir);
  await page.waitForFunction(()=>S.tutorial.blownWood>0,null,{timeout:40000});await h.shot('actual-wind-delivery');
  assert.deepEqual(h.errors,[]);rows.push({mode,status:'passed',fixture:'Prepared inventory only; real placement and worker output/physics delivery',view,spot,plan,draft,placed,errors:h.errors});
 }catch(error){await h.shot('FAIL').catch(()=>{});rows.push({mode,status:'failed',message:error.stack,errors:h.errors});}
 finally{await context.close();}
}}finally{await browser.close();}
fs.writeFileSync(OUT+'/result.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));if(rows.some(r=>r.status!=='passed'))process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1;});
