/* Prepared M4 regression: direct log taps inside enlarged hopper tool circle, PC / CDP touch (not a real device). */
'use strict';
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
const URL=(process.env.GAME_URL||'http://127.0.0.1:4434/preview/')+'?lesson=1';
(async()=>{const browser=await chromium.launch(),results=[];try{for(const touch of [false,true]){
 const ctx=await browser.newContext(touch?{viewport:{width:390,height:844},isMobile:true,hasTouch:true}:{viewport:{width:1280,height:900}}),page=await ctx.newPage(),errors=[];
 page.on('pageerror',e=>errors.push(e.message));await page.goto(URL);await page.locator('#titleBattle').click();await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);
 await page.evaluate(()=>{for(const w of ArmyView.sim.soldiers)w.cooldown=1e9;S.factory.drops.length=0;S.camp.hoppers.push({key:1,x:420,y:430,dir:0,costWood:10,costStone:4});const d=SupplyCore.drop(S.factory,'wood',1,458,430,1,240);d.physical=true;});
 await page.locator('#field').scrollIntoViewIfNeeded();await page.waitForTimeout(300);
 const p=await page.evaluate(()=>{const d=S.factory.drops.find(d=>d.x===458),b=SupplyFactory.itemGeometry(d).image,point={x:(b.left+b.right)/2,y:(b.top+b.bottom)/2},r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return {x:r.left+point.x*z,y:r.top+point.y*z};});
 const cdp=touch?await ctx.newCDPSession(page):null;
 if(touch)await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[p]});else{await page.mouse.move(p.x,p.y);await page.mouse.down();}
 await page.waitForTimeout(70);assert.equal(await page.evaluate(()=>OutpostCamp.dragging),true,'direct log press starts carrying');assert.equal(await page.evaluate(()=>OutpostCamp.selection),null);
 if(touch)await cdp.send('Input.dispatchTouchEvent',{type:'touchCancel',touchPoints:[]});else await page.mouse.up();
 await page.waitForTimeout(100);assert.equal(await page.evaluate(()=>S.factory.drops.reduce((n,d)=>n+d.count,0)),1);assert.deepEqual(errors,[]);
 results.push({mode:touch?'CDP touch (not real device)':'PC',directLogCarry:true,singleItemPreserved:true,pageerrors:0});await ctx.close();
}}finally{await browser.close();}console.log(JSON.stringify(results,null,2));})().catch(e=>{console.error(e);process.exitCode=1;});
