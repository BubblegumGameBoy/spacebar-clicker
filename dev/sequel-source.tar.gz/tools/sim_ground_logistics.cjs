'use strict';
// M3 numbers: how many woodcutter / hand logs reach the warehouse with blowers and fences.
// Usage: node tools/sim_ground_logistics.cjs [--json] [--quick] [--params '{"blowerAccel":400}'] [--tune]
// Map coordinates are copied from 2/outpost-camp.js state() (nodes, HOME) and the woodcutter
// placement rules of 2/battle-control.js spots()/valid() and 2/supply-factory.js outputForWorker().
const G=require('../2/ground-physics.js');
const args=process.argv.slice(2),flag=n=>args.includes(n),opt=n=>{const i=args.indexOf(n);return i>=0?args[i+1]:null;};
const QUICK=flag('--quick'),JSON_OUT=flag('--json');
const NODES=[{key:1,type:'wood',x:280,y:300,radius:16},{key:2,type:'wood',x:470,y:300,radius:16},{key:3,type:'stone',x:330,y:395,radius:19},{key:4,type:'stone',x:490,y:395,radius:19}];
const HOME={x:100,y:340},WORKER_INTERVAL=[5,2.5,1.5];// OutpostCore.stats woodcutter interval by wood tool level

// Woodcutter spots exactly as BattleControl.spots() proposes them (first 3 valid per tree).
function workerSpots(){const out=[];for(const n of NODES.filter(n=>n.type==='wood')){let found=0;const mine=[];
 for(let i=0;i<40&&found<3;i++){const a=i*2.399963+n.key*.13,r=61+Math.sin(i*7.3)*2,p={x:n.x+Math.cos(a)*r,y:n.y+Math.sin(a)*r};
  let ok=p.y>=90+15&&p.y<=540-30&&Math.hypot(p.x-n.x,p.y-n.y)<64;
  for(const m of NODES){const half=m.type==='wood'?53:44,h=m.type==='wood'?100:54;if(Math.abs(p.x-m.x)<half&&p.y>m.y-h&&p.y-64<m.y+5)ok=false;}
  if(!ok||mine.some(q=>Math.hypot(q.x-p.x,q.y-p.y)<36))continue;mine.push(p);found++;
  out.push({name:'tree'+n.key+(p.x>=n.x?'R':'L')+(p.y<n.y?'up':'dn'),worker:{x:+p.x.toFixed(1),y:+p.y.toFixed(1)},base:{x:+(p.x+(p.x>=n.x?24:-24)).toFixed(1),y:+(p.y+24).toFixed(1)},node:n});}
 }return out;}
const baseWorld=(params,extra={})=>({width:960,height:540,home:HOME,nodes:NODES,params,...extra});
function rateOf(params,starts,blowers,fences=[]){const w=G.normalizeWorld(baseWorld(params,{blowers,fences}));let ok=0,time=0;const ends=[];
 for(const s of starts){const r=G.predict(w,s);if(r.status==='warehouse'){ok++;time+=r.time;}ends.push(r.status==='warehouse'?'W':'('+Math.round(r.end.x)+','+Math.round(r.end.y)+')');}
 return {rate:ok/starts.length,ok,n:starts.length,time:ok?time/ok:null,ends};}
function blowerOk(b,starts){if(b.x<20||b.x>940||b.y<100||b.y>530)return false;if(Math.hypot(b.x-HOME.x,b.y-HOME.y)<75)return false;
 if(NODES.some(n=>Math.hypot(b.x-n.x,b.y-n.y)<n.radius+20))return false;if(starts.some(s=>Math.hypot(b.x-s.x,b.y-s.y)<20))return false;return true;}
function searchBlower(params,starts,fences=[],step=QUICK?10:6,span=110){
 const cx=starts.reduce((n,s)=>n+s.x,0)/starts.length,cy=starts.reduce((n,s)=>n+s.y,0)/starts.length;let best=null;const all=[];
 for(let x=Math.round(cx-span);x<=cx+span;x+=step)for(let y=Math.round(cy-span);y<=cy+span;y+=step)for(let dir=0;dir<8;dir++){const b={x,y,dir};if(!blowerOk(b,starts))continue;
  const r=rateOf(params,starts,[b],fences);if(!r.ok&&!best)continue;all.push(r.rate);
  if(!best||r.rate>best.rate+1e-9||Math.abs(r.rate-best.rate)<1e-9&&r.time<best.time)best={...r,blower:b};}
 const covering=all.filter(r=>r>0);return best?{...best,placementsAboveZero:covering.length,placementsAtBest:all.filter(r=>Math.abs(r-best.rate)<1e-9).length}:null;}
function fenceCandidates(starts,step=QUICK?24:16){const xs=starts.map(s=>s.x),ys=starts.map(s=>s.y),out=[];const x0=60,x1=Math.max(...xs)+60,y0=Math.max(110,Math.min(...ys)-110),y1=Math.min(520,Math.max(...ys)+110);
 for(let x=x0;x<=x1;x+=step)for(let y=y0;y<=y1;y+=step)for(let k=0;k<8;k++){const a=k*Math.PI/8;for(const l of QUICK?[48,96]:[48,72,96,120]){const f={a:{x,y},b:{x:+(x+Math.cos(a)*l).toFixed(2),y:+(y+Math.sin(a)*l).toFixed(2)}};
  if(Math.hypot((f.a.x+f.b.x)/2-HOME.x,(f.a.y+f.b.y)/2-HOME.y)<40)continue;out.push(f);}}return out;}
function searchFences(params,starts,blower,count){let fences=[],cur=rateOf(params,starts,[blower]);const cands=fenceCandidates(starts);
 for(let k=0;k<count;k++){let best=null;for(const f of cands){const r=rateOf(params,starts,[blower],[...fences,f]);if(!best||r.rate>best.rate+1e-9||Math.abs(r.rate-best.rate)<1e-9&&(r.time??99)<(best.time??99))best={...r,fence:f};}
  if(!best||best.rate<=cur.rate+1e-9)break;fences.push(best.fence);cur=best;}
 return {...cur,fences};}
function combo(params,starts,count){// blower first, then fences, then re-place the blower around the fences once
 const a=searchBlower(params,starts);if(!a)return null;let b=searchFences(params,starts,a.blower,count);const again=searchBlower(params,starts,b.fences);
 if(again&&again.rate>b.rate+1e-9){b={...again,fences:b.fences};const more=searchFences(params,starts,again.blower,Math.max(0,count-b.fences.length));if(more.rate>b.rate)b={...more,fences:[...b.fences,...more.fences].slice(0,count)};}
 return {...b,blower:b.blower||a.blower};}
const pct=r=>Math.round(r*100)+'%';
const per60=(rate,interval)=>+(60/interval*rate).toFixed(1);

function run(params){
 const spots=workerSpots(),rows=[];
 for(const s of spots){const starts=Array.from({length:8},(_,i)=>G.workerDropPoint(s.base,i,8));
  const a=searchBlower(params,starts),b1=combo(params,starts,1),b2=combo(params,starts,2);
  rows.push({spot:s.name,worker:s.worker,base:s.base,dist:Math.round(Math.hypot(s.base.x-HOME.x,s.base.y-HOME.y)),a,b1,b2});}
 const hand=[];for(const n of NODES.filter(n=>n.type==='wood')){const starts=Array.from({length:4},(_,i)=>G.handDropPoint(n,i,4)),c=searchBlower(params,starts),c2=combo(params,starts,2);hand.push({node:'tree'+n.key,base:{x:n.x+72,y:n.y+28},starts,c,c2});}
 return {rows,hand};
}
function perf(params){
 const w=G.normalizeWorld(baseWorld(params,{blowers:[{x:420,y:330,dir:4},{x:250,y:420,dir:5}],fences:[{a:{x:200,y:280},b:{x:300,y:260}},{a:{x:200,y:400},b:{x:300,y:420}},{a:{x:380,y:250},b:{x:480,y:240}},{a:{x:380,y:430},b:{x:470,y:450}}]}));
 const make=()=>Array.from({length:240},(_,i)=>{const a=i*2.399963;return {x:180+(i%24)*30,y:150+Math.floor(i/24)*36,vx:Math.cos(a)*220,vy:Math.sin(a)*220};});
 let items=make(),steps=0,moving=0,ms=0;const t0=process.hrtime.bigint();
 for(let rep=0;rep<120;rep++){items=make();for(let k=0;k<5;k++){const t=process.hrtime.bigint();const r=G.stepAll(w,items,0);ms+=Number(process.hrtime.bigint()-t)/1e6;moving+=r.moving+r.delivered.length;steps++;}}
 const predictor=G.createPredictor(),starts=Array.from({length:200},(_,i)=>({x:330+(i%20)*3,y:300+Math.floor(i/20)*4}));let pm=0,pc=0;
 for(const s of starts){const t=process.hrtime.bigint();predictor.predict(w,s);pm+=Number(process.hrtime.bigint()-t)/1e6;pc++;}
 let cm=0;for(const s of starts){const t=process.hrtime.bigint();predictor.predict(w,s);cm+=Number(process.hrtime.bigint()-t)/1e6;}
 void t0;return {stepMs240:+(ms/steps).toFixed(3),avgMoving:Math.round(moving/steps),predictMs:+(pm/pc).toFixed(3),cachedPredictMs:+(cm/pc).toFixed(4),cache:predictor.stats};
}
function fmtB(b){return b?'('+b.x+','+b.y+') '+['→','↘','↓','↙','←','↖','↑','↗'][b.dir]:'-';}
function fmtF(f){return '('+Math.round(f.a.x)+','+Math.round(f.a.y)+')-('+Math.round(f.b.x)+','+Math.round(f.b.y)+') L'+Math.round(G.fenceLength(f));}
function report(params,res){
 const lines=[];lines.push('params '+JSON.stringify(params));
 lines.push('spot | worker -> drop(dist) | (a) blower only | (b) +1 fence | (b) +2 fences | 60s @5s/2.5s/1.5s (a / b2)');
 for(const r of res.rows)lines.push([r.spot,'('+r.worker.x+','+r.worker.y+')->('+r.base.x+','+r.base.y+') '+r.dist,pct(r.a?.rate||0)+' '+fmtB(r.a?.blower)+' ['+(r.a?.placementsAtBest||0)+' best / '+(r.a?.placementsAboveZero||0)+' >0]',pct(r.b1?.rate||0)+' '+(r.b1?.fences||[]).map(fmtF).join(' '),pct(r.b2?.rate||0)+' '+fmtB(r.b2?.blower)+' '+(r.b2?.fences||[]).map(fmtF).join(' '),WORKER_INTERVAL.map(i=>per60(r.a?.rate||0,i)+'/'+per60(r.b2?.rate||0,i)).join('  ')].join(' | '));
 for(const h of res.hand)lines.push('hand '+h.node+' spots '+h.starts.map(s=>'('+s.x+','+s.y+')').join(' ')+' | (c) 1 blower '+pct(h.c?.rate||0)+' '+fmtB(h.c?.blower)+' ends '+(h.c?.ends||[]).join(' ')+' | +2 fences '+pct(h.c2?.rate||0)+' '+(h.c2?.fences||[]).map(fmtF).join(' '));
 return lines.join('\n');
}
function inBand(res){const far=res.rows.filter(r=>r.dist>150);return far.map(r=>({spot:r.spot,a:r.a?.rate||0,b:r.b2?.rate||0}));}

if(require.main===module){
 const params={...G.PARAMS,...JSON.parse(opt('--params')||'{}')};
 if(flag('--tune')){
  // Coarse sweep of the four numbers the plan asks to tune; prints the share of far spots in band.
  const grid=[];for(const blowerAccel of [300,420,560])for(const dragLinear of [1.2,1.6,2.2])for(const dragConstant of [30,45,70])grid.push({blowerAccel,dragLinear,dragConstant});
  for(const g of grid){const p={...params,...g},res=run(p),band=inBand(res);console.log(JSON.stringify(g),band.map(b=>b.spot+':'+pct(b.a)+'/'+pct(b.b)).join(' '));}
 }else{
  const t=Date.now(),res=run(params),pf=perf(params);
  if(JSON_OUT)console.log(JSON.stringify({params,res,perf:pf},null,1));else{console.log(report(params,res));console.log('perf '+JSON.stringify(pf));console.log('sim seconds '+((Date.now()-t)/1000).toFixed(1));}
 }
}
module.exports={run,perf,workerSpots,rateOf,searchBlower,combo,NODES,HOME};
