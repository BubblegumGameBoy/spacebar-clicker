/* Prepared hiring inventory; positions chosen through actual PC/CDP inputs. No worker movement or harvest is forced. */
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
const {make}=require('./qa_m4_helpers.cjs');
const OUT=process.env.QA_OUT||'/tmp/qa-worker-range';fs.mkdirSync(OUT,{recursive:true});
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium'}),rows=[];
try{for(const touch of [false,true]){
 const mode=touch?'touch':'pc',context=await browser.newContext({viewport:touch?{width:390,height:844}:{width:1280,height:900},hasTouch:touch,isMobile:touch}),page=await context.newPage(),cdp=touch?await context.newCDPSession(page):null,h=make(page,{touch,cdp,out:OUT,tag:mode});
 try{
  await page.goto(process.env.GAME_URL||'http://127.0.0.1:4436/preview/');await h.press('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);
  await page.evaluate(()=>{S.factory.inventory.wood=20;S.tutorial.woodDelivered=2;OutpostTutorial.sync(true);renderCards();SupplyFactory.translate();});
  await h.press('[data-recruit="woodcutter"]');await h.field();const far={x:820,y:250},f=await h.screen(far);await h.drag(f,f,2);await page.waitForFunction(()=>!S.pending.woodcutter);
  await h.shot('freely-placed-idle');const before=await page.evaluate(()=>({worker:ArmyView.sim.soldiers.find(p=>p.id==='woodcutter'),stock:S.factory.nodes.filter(n=>n.type==='wood').map(n=>n.stock),outputs:S.factory.drops.filter(d=>d.worker).length}));
  assert.ok(Math.hypot(before.worker.x-820,before.worker.y-250)<.01);await page.waitForTimeout(6200);
  const idle=await page.evaluate(()=>({point:ArmyView.sim.soldiers.filter(p=>p.id==='woodcutter').map(p=>[p.x,p.y]),stock:S.factory.nodes.filter(n=>n.type==='wood').map(n=>n.stock),outputs:S.factory.drops.filter(d=>d.worker).length}));
  assert.deepEqual(idle.stock,before.stock);assert.equal(idle.outputs,before.outputs);assert.ok(idle.point.every(p=>Math.hypot(p[0]-before.worker.x,p[1]-before.worker.y)<.001),'worker does not walk toward a tree');
  await h.tap(await h.screen({x:820,y:228}));assert.equal(await page.evaluate(()=>BattleControl.placement),true);
  const near=await page.evaluate(()=>{const n=S.factory.nodes.find(n=>n.type==='wood');return {x:n.x+74,y:n.y};}),q=await h.screen(near);await h.drag(q,q,2);await page.waitForFunction(()=>!BattleControl.placement);
  await page.waitForFunction(()=>S.factory.drops.some(d=>d.worker),null,{timeout:8000});await h.shot('tree-intersects-work-range');
  const output=await page.evaluate(()=>({point:ArmyView.sim.soldiers.filter(p=>p.id==='woodcutter').map(p=>[p.x,p.y]),count:S.factory.drops.filter(d=>d.worker).length}));
  assert.ok(output.point.every(p=>Math.hypot(p[0]-near.x,p[1]-near.y)<.01));assert.ok(output.count>0);assert.deepEqual(h.errors,[]);
  rows.push({mode,status:'passed',fixture:'Prepared wood20 and learned gesture flag; real recruit/free placement/reposition; natural6.2sidle and real harvesting',far,near,idle,output,errors:h.errors});
 }catch(e){await h.shot('FAIL').catch(()=>{});rows.push({mode,status:'failed',message:e.stack,errors:h.errors});}
 finally{await context.close();}
}}finally{await browser.close();}
fs.writeFileSync(OUT+'/result.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));if(rows.some(r=>r.status!=='passed'))process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1;});
