/* Fresh pointer journey followed by a labelled material fixture for late-game equipment.
   Touch input is CDP emulation, not a claim about a physical phone. */
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),{make}=require('./qa_m4_helpers.cjs');
const OUT=process.env.QA_OUT||'/tmp/qa-unified-loader';fs.mkdirSync(OUT,{recursive:true});
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/chromium'}),rows=[];
try{for(const touch of [false,true]){
const ctx=await b.newContext({viewport:touch?{width:390,height:844}:{width:1280,height:900},hasTouch:touch,isMobile:touch}),p=await ctx.newPage(),cdp=touch?await ctx.newCDPSession(p):null,h=make(p,{touch,cdp,out:OUT,tag:touch?'touch':'pc'});
try{
 await p.goto(process.env.GAME_URL||'http://127.0.0.1:4422/preview/?lesson=2');await h.press('#titleBattle');await p.waitForFunction(()=>Outpost.ready&&SupplyFactory.artReady);
 assert.equal(await p.locator('[data-recruit]').count(),0);assert.equal(await p.evaluate(()=>S.progression.recipes.length),0);
 await h.need('wood',2);assert.equal(await p.evaluate(()=>S.tutorial.woodDelivered),2);
 assert.equal(await p.evaluate(()=>document.body.dataset.lesson),'recipe_woodcutter');
 await h.press('#onboardingAction');await p.waitForTimeout(850);assert.equal(await p.locator('[data-progression-node]').count(),43);
 assert.equal(await p.evaluate(()=>HarvestSkills.selected),'recipe_woodcutter');await h.shot('unified-tree-before-research');
 await h.press('#harvestLearn');await p.waitForTimeout(1000);assert.equal(await p.evaluate(()=>ProgressionCore.hasRecipe(S,'woodcutter')),true);assert.equal(await p.evaluate(()=>S.owned.woodcutter),0);
 await h.press('[data-progression-card="recipe_woodcutter"]');await h.press('[data-recruit="woodcutter"]'); // unaffordable: no hire yet
 assert.equal(await p.evaluate(()=>S.owned.woodcutter),0);
 await h.need('wood',6);await h.press('[data-recruit="woodcutter"]');await h.field();await h.drag(await h.screen({x:270,y:315}),await h.screen({x:270,y:315}),2);await p.waitForFunction(()=>S.owned.woodcutter===1&&!S.pending.woodcutter);await p.waitForFunction(()=>S.factory.drops.some(d=>d.worker),null,{timeout:10000});await h.shot('first-worker-producing');
 // Prepared stock only: unlock all research normally through the visible tree purchase API, then place equipment by pointer.
 await p.evaluate(()=>{S.factory.inventory.wood=100000;S.factory.inventory.stone=100000;S.expedition.coins=100;for(let i=0;i<12;i++)for(const n of ProgressionCore.nodes)if(ProgressionCore.quote(S,n.id).ready)ProgressionCore.purchase(S,n.id);ProgressionIntegration.refresh();});
 assert.equal(await p.locator('[data-equipment="loader"]').count(),1);assert.equal(await p.locator('[data-recruit="sword"]').count(),1);
 await h.press('[data-equipment="loader"]');await h.field();const at={x:250,y:390};assert.equal(await p.evaluate(p=>OutpostCamp.canPlaceLoader(p),at),true);await h.tap(await h.screen(at));await p.waitForFunction(()=>S.camp.loaders.length===1);assert.equal(await p.evaluate(()=>LoaderDevice.status(S.camp.loaders[0]).reason),'no-belt');await h.shot('loader-waits-for-conveyor');
 await p.evaluate(()=>{OutpostCamp.cancelRails();S.factory.drops=[];S.camp.links=[{nodeKey:501,kind:'conveyor',points:[{x:100,y:340},{x:330,y:340}],costWood:5}];SupplyCore.drop(S.factory,'stone',1,250,420,3,240);});
 const delivered=await p.evaluate(()=>S.factory.inventory.stone);await p.waitForFunction(()=>LoaderDevice.tracks.get('1')?.item);await h.shot('loader-arm-carries-stone');await p.waitForFunction(n=>S.factory.inventory.stone>n,delivered,{timeout:15000});assert.equal(await p.evaluate(n=>S.factory.inventory.stone-n,delivered),1);
 await p.evaluate(()=>{SupplyCore.drop(S.factory,'wood',1,250,420,1,240);});await p.waitForFunction(()=>LoaderDevice.tracks.get('1')?.item);await p.evaluate(()=>OutpostCamp.removePiece('loader',1));assert.equal(await p.evaluate(()=>S.factory.drops.some(d=>d.loaderKey!=null)),false);assert.equal(await p.evaluate(()=>S.factory.drops.length),1);
 await p.evaluate(()=>{save();});await p.reload();await p.waitForTimeout(700);assert.equal(await p.evaluate(()=>ProgressionCore.hasRecipe(S,'loader')),true);assert.equal(await p.evaluate(()=>S.camp.loaders.length),0);
 for(const lang of ['ja','en','zh']){await p.evaluate(lang=>{LANG=lang;HarvestSkills.open('recipe_loader');},lang);await p.waitForTimeout(800);assert.equal(await p.locator('[data-progression-node]').count(),43);assert.equal(await p.locator('.unified-edge').count(),await p.evaluate(()=>ProgressionCore.nodes.reduce((n,x)=>n+Math.max(1,x.requires.length),0)));const box=await p.locator('#harvestLearn').boundingBox();assert.ok(box&&box.x>=0&&box.y>=0&&box.x+box.width<=(touch?390:1280));await h.shot('tree-'+lang);await p.evaluate(()=>Rework.close());}
 assert.deepEqual(h.errors,[]);rows.push({mode:touch?'CDP touch':'PC',status:'passed',freshJourney:true,preparedLateEquipment:true,errors:h.errors});
}catch(e){await h.shot('FAIL').catch(()=>{});rows.push({mode:touch?'CDP touch':'PC',status:'failed',error:e.stack,errors:h.errors});}finally{await ctx.close();}
}}finally{await b.close();}fs.writeFileSync(OUT+'/result.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));if(rows.some(r=>r.status!=='passed'))process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1;});
