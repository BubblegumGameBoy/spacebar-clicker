/* M1 board removal, real play from a fresh ?lesson=1 save (no grants, no time acceleration).
   PC mouse (1280x900) and CDP touch (390x844, not a real device). evaluate() only reads state/coordinates.
   Flow: deliver wood -> learn the first skill -> hire and place a lumberjack -> lay a deliberately offset belt
   -> tap the tree beside it and drag a log on/off it (must not select) -> select the belt on the board
   -> remove it from the card (2 inputs, no workshop dialog) -> re-lay to the landing point -> a log arrives. */
'use strict';
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const BASE=process.env.GAME_URL||'http://127.0.0.1:4411/preview/',URL=BASE+(BASE.includes('?')?'&':'?')+'lesson=1',OUT=process.env.QA_OUT||'/tmp/qa-manual-rails';fs.mkdirSync(OUT,{recursive:true});
const MODES=(process.env.QA_MODES||'pc,touch').split(',');
async function run(browser,mode){
 const touch=mode==='touch',ctx=await browser.newContext(touch?{viewport:{width:390,height:844},hasTouch:true,isMobile:true,deviceScaleFactor:2}:{viewport:{width:1280,height:900}}),page=await ctx.newPage(),errors=[],checks=[];let serial=0,inputs=0;
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
 const cdp=touch?await ctx.newCDPSession(page):null,touchEvent=(type,p)=>cdp.send('Input.dispatchTouchEvent',{type,touchPoints:p?[p]:[]});
 const shot=n=>page.screenshot({path:path.join(OUT,mode+'-'+String(++serial).padStart(2,'0')+'-'+n+'.png')});
 const read=()=>page.evaluate(()=>({inventory:{...S.factory.inventory},links:S.camp.links.map(l=>({key:l.nodeKey,points:l.points})),selection:OutpostCamp.selection,ground:S.factory.drops.length,delivered:S.factory.delivered,owned:S.owned.woodcutter}));
 const screen=p=>page.evaluate(p=>{const r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return{x:r.left+p.x*z,y:r.top+p.y*z};},p);
 const tap=async(q,hold=60)=>{inputs++;if(touch){await touchEvent('touchStart',q);await page.waitForTimeout(hold);await touchEvent('touchEnd');}else await page.mouse.click(q.x,q.y);await page.waitForTimeout(140);};
 // Panels re-render while opening; retry until the element is attached and has a box.
 const press=async sel=>{for(let i=0;;i++){try{const el=page.locator(sel).first();await el.waitFor({state:'visible',timeout:3000});await el.scrollIntoViewIfNeeded({timeout:1000});const b=await el.boundingBox();if(b){await tap({x:b.x+b.width/2,y:b.y+b.height/2});return;}}catch(e){if(i>=5)throw e;}await page.waitForTimeout(150);}};
 const drag=async(a,z,steps=14)=>{if(touch){await touchEvent('touchStart',a);for(let i=1;i<=steps;i++){await touchEvent('touchMove',{x:a.x+(z.x-a.x)*i/steps,y:a.y+(z.y-a.y)*i/steps});await page.waitForTimeout(16);}await touchEvent('touchEnd');}else{await page.mouse.move(a.x,a.y);await page.mouse.down();await page.mouse.move(z.x,z.y,{steps});await page.mouse.up();}await page.waitForTimeout(150);};
 const field=()=>page.locator('#field').scrollIntoViewIfNeeded();
 const tree=()=>page.evaluate(()=>{const n=S.factory.nodes.find(n=>n.type==='wood'&&n.stock>0),r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return{x:r.left+n.x*z,y:r.top+(n.y-48)*z};});
 const pile=(onBelt=false)=>page.evaluate(onBelt=>{const d=S.factory.drops.find(d=>d.type==='wood'&&!d.worker&&!!d.onConveyor===onBelt&&!SupplyFactory.isAirborne(d));if(!d)return null;const b=SupplyFactory.pileBounds(d),r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return{x:r.left+(b.left+b.right)*.5*z,y:r.top+(b.top+b.bottom)*.5*z};},onBelt);
 const harvest=async n=>{await field();for(let i=0;i<400;i++){if(await page.evaluate(()=>S.factory.drops.filter(d=>d.type==='wood'&&!d.worker&&!d.onConveyor).length)>=n)return;await tap(await tree(),40);}throw new Error('harvest stuck');};
 const deliver=async()=>{await field();for(let i=0;i<60;i++){const p=await pile();if(!p)return;await drag(p,await screen({x:100,y:290}));}};
 try{
  await page.goto(URL);await page.waitForTimeout(1200);await press('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);await page.waitForTimeout(400);
  await harvest(10);await deliver();await press('text=スキルを強化 →');await page.waitForTimeout(400);await press('[data-harvest-learn]:not([disabled])');await page.keyboard.press('Escape');await page.waitForTimeout(300);
  await harvest(6);await deliver();await press('[data-recruit="woodcutter"]');await page.waitForTimeout(400);await field();const spot=(await page.evaluate(()=>BattleControl.spots()))[0];await drag(await screen(spot),await screen(spot),2);assert.equal((await read()).owned,1);
  await harvest(8);await deliver();await press('[data-equipment="belt"]');await page.waitForTimeout(300);await field();await drag(await screen({x:162,y:328}),await screen({x:250,y:360}),18);let r=await read();assert.equal(r.links.length,1);await shot('offset-belt');checks.push('A belt laid by hand toward the wrong place');
  const ground=r.ground;await tap(await tree(),40);await page.waitForTimeout(500);r=await read();assert.equal(r.selection,null);assert.ok(r.ground>ground);checks.push('Tapping the tree beside the belt still harvests and selects nothing');
  const pts=r.links[0].points;let p=await pile();if(p){await drag(p,await screen(pts[Math.floor(pts.length/2)]));assert.equal((await read()).selection,null);const q=await pile(true);if(q){await drag(q,await screen({x:100,y:290}));assert.equal((await read()).selection,null);checks.push('Dragging a log onto and off the belt never selects it');}}
  const before=await read(),mid=before.links[0].points[Math.floor(before.links[0].points.length*.6)],t0=Date.now(),start=inputs;
  await tap(await screen(mid));assert.equal((await read()).selection?.kind,'belt');assert.ok(await page.locator('#beltActions').isVisible());const btn=await page.locator('[data-pick-action="remove"]').boundingBox();assert.ok(btn.width>=44&&btn.height>=44);await shot('belt-selected');
  await tap({x:btn.x+btn.width/2,y:btn.y+btn.height/2});const after=await read();
  assert.equal(after.links.length,0);assert.ok(after.inventory.wood>before.inventory.wood);assert.equal(await page.locator('#campWorkshop.on').count(),0);assert.equal(inputs-start,2);await shot('belt-removed');
  checks.push('Board removal: '+(inputs-start)+' '+(touch?'taps':'clicks')+', '+((Date.now()-t0)/1000).toFixed(2)+'s, wood '+before.inventory.wood+' -> '+after.inventory.wood+', no workshop dialog');
  const land=await page.evaluate(()=>{const p=ArmyView.sim.soldiers.find(p=>p.id==='woodcutter'),n=S.factory.nodes.filter(n=>n.type==='wood').sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y))[0];return SupplyFactory.outputForWorker(p,n);});
  if(after.inventory.wood<8){await harvest(8-after.inventory.wood);await deliver();}
  await press('[data-equipment="belt"]');await page.waitForTimeout(300);await field();await drag(await screen({x:162,y:328}),await screen({x:land.x+12,y:land.y+6}),18);r=await read();assert.equal(r.links.length,1);await shot('belt-relaid');
  await page.waitForFunction(d=>S.factory.delivered>d,r.delivered,{timeout:30000});checks.push('Re-laid belt under the landing point delivers a log by itself');
  assert.deepEqual(errors,[]);return {mode,status:'passed',checks};
 }catch(e){await shot('FAIL').catch(()=>{});return {mode,status:'failed',message:e.stack,errors,checks};}finally{await ctx.close();}
}
(async()=>{const browser=await chromium.launch();const results=[];try{for(const m of MODES)results.push(await run(browser,m));}finally{await browser.close();}
 fs.writeFileSync(path.join(OUT,'result.json'),JSON.stringify({fixture:'Fresh ?lesson=1 save, visible inputs only; touch is CDP touch, not a real device',results},null,2));console.log(JSON.stringify(results,null,1));if(results.some(r=>r.status!=='passed'))process.exitCode=1;})();
