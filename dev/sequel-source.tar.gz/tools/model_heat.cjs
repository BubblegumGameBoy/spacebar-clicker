/* M5 threat trials, jittered dt (1/60–0.1 s), four cooldown seeds. Prepared, not a playthrough: the crew is the recorded completion crew of the earned
   nine-wave run (preview/media/sequel-progression-checks.json: arch 3/3 + ballista 3 [armour] at Wave4, arch 6/6 + ballista 3 at Wave9,
   positions from its final save), with the finished camp's gate (2.5 s) and beacon (archer range 110). Assistance is recorded per row.
   Usage: node tools/model_heat.cjs [out.json]   Each batch uses the four SEEDS below. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),C=require('../2/outpost-core.js'),{Battle}=require('../2/army-sim.js'),{createLedger}=require('./combat_metrics.cjs');
const ROLE={arch:{damage:5,interval:1.3,range:110,ranged:true,impact:680},sword:{damage:3,interval:1.2,range:28,ranged:false,impact:240},ballista:{damage:20,interval:6,range:160,minRange:60,ranged:true,impact:650}};
function formation(anchor,key,count){return Array.from({length:count},(_,m)=>m?{x:anchor.x+Math.cos(m*2.399963+key*.17)*23*Math.sqrt(m),y:anchor.y+Math.sin(m*2.399963+key*.17)*23*Math.sqrt(m)}:{...anchor});}
// Anchors of the earned completion save (keys 2,3,4), plus a few alternatives used by the "changed crew" rows.
const AT={archUp:{x:643,y:250},archLow:{x:620,y:360},ballista:{x:620,y:400},homeUpper:{x:200,y:250},homeLower:{x:200,y:400},home:{x:160,y:330},upperSword:{x:330,y:205},lowerSword:{x:330,y:415},forwardUpper:{x:780,y:225},forwardLower:{x:780,y:395},ballistaMid:{x:700,y:310},bendUpper:{x:250,y:215},bendLower:{x:250,y:405}};
const A=(at,count,policy)=>({id:'arch',at,count,policy}),Sw=(at,count,policy)=>({id:'sword',at,count,policy}),B=(at,count,policy='armor')=>({id:'ballista',at,count,policy});
const COMPLETION={4:[A('archUp',3),A('archLow',3),B('ballista',3)],9:[A('archUp',6),A('archLow',6),B('ballista',3)]};
function trial({wave,heat,groups,seed=1,gate=true,dt:step=1/30,assist=0}){
 const state=C.fresh();state.wave=wave;state.cleared=wave-1;state.claimedFirst=Array.from({length:wave-1},(_,i)=>i+1);state.heat=C.heat(heat);C.start(state);
 const sim=new Battle();sim.fixedWorld=true;sim.stationary=true;sim.bounds(960,540,{x:10000,y:10000,r:0,alive:false});sim.outpostState=state;sim.roundToken=state.round;sim.enemies=state.enemies;
 const actors=[],indices={};let key=2;
 for(const g of groups){const pts=formation(AT[g.at]||g.at,key,g.count);for(const p of pts){const index=indices[g.id]=(indices[g.id]??-1)+1;actors.push({id:g.id,index,groupKey:key,policy:g.policy||'front',x:p.x,y:p.y});}key++;}
 const ids=[...new Set(actors.map(a=>a.id))];
 sim.sync(ids.map(id=>({id,count:actors.filter(a=>a.id===id).length,ranged:ROLE[id].ranged,damage:ROLE[id].damage,interval:ROLE[id].interval,range:ROLE[id].range,minRange:ROLE[id].minRange||0,anim:{impact:ROLE[id].impact}})));
 for(const p of sim.soldiers){const a=actors.find(a=>a.id===p.id&&a.index===p.index);Object.assign(p,{x:a.x,y:a.y,policy:a.policy,enterAt:-1});}
 sim.encounter(seed);const ledger=createLedger(actors);let steps=0,rng=seed*9301+49297,pressAt=assist?1/assist:Infinity,selected=null,combo=0,manual=0;
 // jitter: frame steps drawn in [1/60, 0.1] s like a loaded browser (army-view caps each step at 0.1). assist: Space presses per second,
 // the same rule as Outpost.manual (keeps the chosen enemy until it dies, else the exposed enemy nearest home; 4×(1+min(.25,combo·0.005)), armour applies).
 const next=()=>{if(step!=='jitter')return step;rng=(rng*9301+49297)%233280;return 1/60+(rng/233280)*(0.1-1/60);};
 while(state.phase==='active'&&steps++<30000){const dt=next();C.tick(state,dt,{gateBuilt:gate});
  if(assist&&state.phase==='active'&&state.elapsed>=pressAt){pressAt+=1/assist;const chosen=state.enemies.find(e=>e.alive&&e.key===selected&&C.exposed(e)),enemy=chosen||C.target(state,C.WORLD.home,2000,{role:'manual'});if(enemy){selected=enemy.key;combo++;const amount=4*(1+Math.min(.25,combo*.005)),outcome=C.hit(state,enemy.key,amount,'manual');manual+=outcome.applied;}}C.reveal(state,sim.soldiers);sim.outpostState=state;sim.enemies=state.phase==='active'?state.enemies:[];const events=sim.step(dt,{x:0,y:0,hp:1,max:1});
  for(const event of events){if(event.kind==='release'&&state.phase==='active')ledger.release(event,state.elapsed);if(event.kind!=='damage'||state.phase!=='active'||event.roundToken!==state.round||event.target!==state.enemies.find(e=>e.key===event.targetKey)||!event.target.alive)continue;const before={...event.target},outcome=C.hit(state,event.targetKey,event.amount,event.p.id,{x:event.p.x,y:event.p.y});ledger.hit({role:event.p.id,index:event.p.index,amount:event.amount,before,outcome,time:state.elapsed});}}
 const m=ledger.summary(),through={};for(const e of state.enemies)if(!e.alive&&e.hp>0)through[e.kind]=(through[e.kind]||0)+1;
 return {manual:+manual.toFixed(1),win:state.result.win,boxes:state.result.boxes,startBoxes:C.planFor(state).boxes,kills:state.result.kills,escaped:state.result.escaped,potential:C.planFor(state).potential,boss:C.planFor(state).boss,
  damage:Object.fromEntries(Object.values(m.groups||{}).map(g=>[g.id+'#'+g.groupKey,{applied:+g.applied.toFixed(1),kills:g.kills,armorBlocked:+g.armorBlocked.toFixed(1)}])),through};
}
const crewLabel=groups=>groups.map(g=>g.count+'×'+g.id+'@'+(typeof g.at==='string'?g.at:JSON.stringify(g.at))+(g.policy&&g.policy!=='front'?'['+g.policy+']':'')).join(', ');
/* Budget = what the same camp can reach: use the 4th defence slot (≤ the crew's squad size), raise one squad one step (3→6 / 6→10), change policy or placement.
   Recorded crews: Wave4 arch3+arch3+ballista3[armour], Wave9 arch6+arch6+ballista3[armour] (earned completion, which used click assistance). */
const REC=COMPLETION;
const COUNTERS={
 4:{horde:[REC[4],'そのまま'],ironhide:[[A('archUp',6),A('archLow',3),B('ballista',3)],'上の弓兵を6人に'],flank:[[A('archUp',6),A('archLow',3),B('ballista',3),Sw('upperSword',3)],'俊足の道(上)の弓兵を6人＋上の角に剣士3'],wings:[REC[4],'そのまま'],shieldwall:[[A('archUp',6),A('archLow',3),B('ballista',3)],'上の弓兵を6人に'],burrow:[[A('archUp',3),A('archLow',3),B('ballista',3),A('home',3)],'4枠目に弓兵3を倉庫前(角の内側)へ'],thin:[REC[4],'そのまま'],procession:[REC[4],'そのまま'],siege:[[A('archUp',6),A('archLow',3),B('ballista',3)],'上の弓兵を6人に'],rush:[REC[4],'（戦闘は同じ。準備の資材が減る）'],narrow:[[A('archUp',3),A('archLow',3),B('ballistaMid',3)],'封鎖された弓兵1隊の代わりにバリスタを前へ']},
 9:{horde:[[A('archUp',6),A('archLow',10),B('ballista',3),A('homeUpper',6)],'下の弓兵を10人＋4枠目に弓兵6を倉庫寄り'],ironhide:[[A('archUp',6),A('archLow',6),B('ballista',6,'front'),B('bendUpper',6,'armor')],'バリスタを6人(方針=突破阻止)＋4枠目にバリスタ6(鎧を優先)を上の角'],flank:[[A('archUp',10),A('archLow',6),B('ballista',3),A('homeUpper',6)],'俊足の道(上)の弓兵を10人＋弓兵6を上の倉庫寄り'],wings:[[A('archUp',6),A('archLow',6),B('ballista',6),A('homeUpper',6)],'バリスタ6人＋4枠目に弓兵6を倉庫寄り'],shieldwall:[[A('archUp',6),A('archLow',6),B('ballista',6),B('bendUpper',6,'healer')],'バリスタ6人＋4枠目にバリスタ6を上の角'],burrow:[[A('archUp',6),A('archLow',6),B('ballista',6),A('bendUpper',6)],'バリスタ6人＋4枠目に弓兵6を上の角'],thin:[[A('archUp',6),A('archLow',10),B('ballista',3),A('homeUpper',6)],'下の弓兵を10人＋弓兵6を倉庫寄り'],procession:[[A('archUp',6),A('archLow',10),B('ballista',3),A('homeUpper',6)],'下の弓兵を10人＋弓兵6を倉庫寄り'],siege:[[A('archUp',10),A('archLow',6),B('ballista',3),B('bendLower',6,'armor')],'上の弓兵を10人＋バリスタ6を下の角、方針は鎧を優先'],rush:[[A('archUp',6),A('archLow',10),B('ballista',3),A('homeUpper',6)],'（脅威度0と同じ強化）'],narrow:[[A('archUp',10),A('archLow',6),B('ballistaMid',3)],'封鎖されたバリスタの代わりに新しいバリスタ隊を中央へ、上の弓兵10人']}
};
// Threat 2+ sets: [conditions, crew, label]. FULL = the camp's strongest four-slot crew (all at 10 is not budget; used only for threat 4+ existence).
const FULL=[A('archUp',10),A('archLow',10),B('ballista',10),A('homeUpper',10)];
const COMBOS=[
 [['shieldwall','flank'],[A('archUp',10),A('archLow',6),B('ballista',6),B('bendUpper',6,'armor')]],
 [['ironhide','thin'],COUNTERS[9].ironhide[0]],
 [['wings','procession'],COUNTERS[9].wings[0]],
 [['horde','flank','burrow'],[A('archUp',10),A('archLow',6),B('ballista',6),A('bendUpper',6)]],
 [['narrow','rush'],COUNTERS[9].narrow[0]],
 [['siege','wings'],COUNTERS[9].siege[0]],
 [['ironhide','thin','wings'],FULL],
 [['horde','shieldwall','burrow','flank'],FULL],
 [['siege','procession','thin'],FULL],
 [['narrow','ironhide','horde'],[A('archUp',10),A('archLow',10),B('ballistaMid',10)]]
];
const SEEDS=[1,2,3,4];
function batch(wave,conditions,groups,assist,sealed){const rs=SEEDS.map(seed=>trial({wave,heat:{conditions,seed:wave},groups,seed,dt:'jitter',assist}));return {wins:rs.filter(r=>r.win).length,of:rs.length,runs:rs.map(r=>(r.win?'W':'L')+r.boxes).join(' '),boxes:Math.min(...rs.map(r=>r.boxes)),startBoxes:rs[0].startBoxes,kills:Math.min(...rs.map(r=>r.kills)),potential:rs[0].potential,killShare:+(Math.min(...rs.map(r=>r.kills))/rs[0].potential).toFixed(2),boss:rs[0].boss,through:rs[0].through,damage:rs[0].damage,manual:rs[0].manual};}
// narrow seals one squad in use: the recorded 3-squad crew loses squad (run % 3); the model shows the worst case (the ballista) and an archer.
function recFor(wave,c){if(c!=='narrow')return REC[wave];return REC[wave].filter(g=>g.id!=='ballista');}
function run(){const single=[];for(const wave of [4,9])for(const c of ['0',...Object.keys(COUNTERS[wave])]){const cond=c==='0'?[]:[c],rec=c==='0'?REC[wave]:recFor(wave,c),counter=c==='0'?null:COUNTERS[wave][c];
  single.push({wave,condition:c,level:heat({conditions:cond}).level,recorded:{crew:crewLabel(rec),...batch(wave,cond,rec,0)},recordedAssist:{crew:crewLabel(rec),assist:4,...batch(wave,cond,rec,4)},...(counter?{counter:{crew:crewLabel(counter[0]),change:counter[1],...batch(wave,cond,counter[0],0)}}:{})});}
 const combos=COMBOS.map(([cond,crew])=>({wave:9,conditions:cond,level:heat({conditions:cond}).level,recordedAssist:{crew:crewLabel(REC[9]),...batch(9,cond,cond.includes('narrow')?recFor(9,'narrow'):REC[9],4)},counter:{crew:crewLabel(crew),...batch(9,cond,crew,0)},counterAssist:{crew:crewLabel(crew),...batch(9,cond,crew,4)}}));
 return {single,combos};}
const heat=C.heat;
module.exports={trial,run,batch,AT,COMPLETION,COUNTERS,COMBOS,FULL,crewLabel,A,Sw,B};
if(require.main===module){const out=run(),f=b=>(b.wins+'/'+b.of+' '+b.runs+' k'+b.killShare).padEnd(26);
 for(const r of out.single)console.log(('W'+r.wave+' '+r.condition).padEnd(16),'rec',f(r.recorded),'rec+assist',f(r.recordedAssist),r.counter?'counter '+f(r.counter)+r.counter.change:'');
 for(const r of out.combos)console.log(('W9 L'+r.level+' '+r.conditions.join('+')).padEnd(34),'rec+assist',f(r.recordedAssist),'counter',f(r.counter),'counter+assist',f(r.counterAssist));
 const file=process.argv[2];if(file){fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,JSON.stringify({kind:'m5-heat-model',tune:C.HEAT_TUNE,dt:'jitter 1/60–0.1 s',seeds:SEEDS,...out},null,1));}}
