/* Plays the whole campaign on the actual browser state. Automates input and ticks.
   No stock, troop, encounter, hit point, or victory grants. */
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {chromium}=require('playwright');
const output=process.env.QA_OUT||'../campaign-full';
fs.mkdirSync(output,{recursive:true});

(async()=>{
 const browser=await chromium.launch({args:['--mute-audio'],executablePath:process.env.CHROMIUM_PATH||'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe'});
 try{
  const context=await browser.newContext({viewport:{width:1280,height:900}});
  const page=await context.newPage(),errors=[];
  page.on('pageerror',error=>errors.push(error.message));
  page.on('console',message=>{if(message.text().startsWith('CAMPAIGN '))console.log(message.text());});
  await page.goto(process.env.GAME_URL||'http://127.0.0.1:4427/preview/?slot=campaign-full');
  await page.waitForFunction(()=>window.TerritoryUI?.ready&&SupplyFactory.artReady);
  assert.match(await page.locator('#titleArmyLead').innerText(),/黄昏の王.*10地域/);
  await page.screenshot({path:path.join(output,'01-premise.png')});
  await page.locator('#titleBattle').click();
  await page.locator('#titleScreen.hidden').waitFor({state:'attached'});
  assert.match(await page.locator('.territory-scene-name').innerText(),/弓兵/);
  const run=await page.evaluate(()=>{
   const check=(value,message)=>{if(!value)throw Error(message);};
   const groups=()=>ExpeditionCore.groups(S);
   const clock=(dt=.05)=>{ArmyView.tick(dt);SupplyFactory.tick(dt);};
   const totals={taps:0,territoryTaps:0,trips:0,wood:0,stone:0,food:0};
   const battles=[];
   check(S.invasion.conquered.length===0&&S.gold===0&&S.factory.inventory.wood===0&&S.factory.inventory.stone===0,'fresh campaign');
   function deliver(type,limit){
    const stock=S.factory.inventory[type]||0;
    while((S.factory.inventory[type]||0)<limit){
     const drop=S.factory.drops.find(item=>item.type===type&&!SupplyFactory.isAirborne(item));
     if(!drop)break;
     check(SupplyCore.deliver(S.factory,drop),'existing physical item');
     totals[type]++;
     OutpostTutorial.delivered(type,1,false,drop.worker);
    }
    return (S.factory.inventory[type]||0)>=limit;
   }
   function gather(type,amount){
    TerritoryUI.home();
    for(let guard=0;guard<12000&&!deliver(type,amount);guard++){
     const id=type==='wood'?1:type==='stone'?2:0;
     if(id&&S.invasion.conquered.includes(id)&&S.harvestSkills.carry>=1&&amount-(S.factory.inventory[type]||0)>=6){
      check(TerritoryCore.visit(S,id),'visit conquered supplier');
      const site=TerritoryCore.entry(S,id);
      while(site.cart.length<TerritoryCore.CAPACITY){
       for(const drop of [...site.drops]){
        if(site.cart.length===TerritoryCore.CAPACITY)break;
        check(TerritoryCore.transfer(S,id,drop.key,'drops','cart'),'load a real drop');
       }
       if(site.cart.length>=TerritoryCore.CAPACITY)break;
       if(!site.nodes[0].stock)TerritoryCore.tick(S,66);
       check(TerritoryCore.harvest(S,id,site.nodes[0].key),'work at captured supplier');
       totals.territoryTaps++;
      }
      check(TerritoryCore.sendCart(S,id),'send earned cargo');
      TerritoryCore.tick(S,1);
      check(TerritoryCore.unload(S).unloaded===12,'unload earned cargo');
      totals.trips++;
      continue;
     }
     if(S.factory.drops.some(item=>item.type===type)){clock(.4);continue;}
     const node=SupplyFactory.choose(type);
     if(!node?.stock){clock(66);continue;}
     check(SupplyFactory.harvestSelected(),'gather '+type+' '+JSON.stringify({paused:Rework.paused,placement:BattleControl.placement,hidden:document.hidden,building:OutpostCamp.layingRails,target:SupplyFactory.resourceTarget,node:node.stock,ground:S.factory.drops.length,selected:InventoryUI.selected}));
     totals.taps++;
     clock(.4);
    }
    check((S.factory.inventory[type]||0)>=amount,'materials '+type+' '+amount);
   }
   function afford(cost){
    for(const type of ['wood','stone'])if(cost[type]>(S.factory.inventory[type]||0))gather(type,cost[type]);
    while(cost.food>(S.factory.inventory.food||0))check(ExpeditionCore.buyFood(S),'victory gold buys rations');
   }
   function learn(id){
    const quote=ProgressionCore.quote(S,id);
    if(quote.built)return;
    check(!quote.locked,'available research '+id);
    afford(quote.cost);
    check(ProgressionCore.purchase(S,id),'earn and buy '+id);
   }
   function hire(id,x,y){
    const quote=ExpeditionCore.slotQuote(S,id);
    afford(quote.cost);
    const group=ExpeditionCore.recruit(S,id);
    check(group,'pay recruit '+id+' '+JSON.stringify(quote));
    const assignment=ExpeditionCore.assignments(S).find(item=>item.groupKey===group.key);
    check(ExpeditionCore.setAnchor(S,id,assignment.index,{x,y}),'manual deployment point');
    ExpeditionCore.project(S);
    ExpeditionIntegration.refresh();
    BattleControl.setPlacement(false);
    return group;
   }
   function train(group){
    afford(ExpeditionCore.trainQuote(S,group.key).cost);
    check(ExpeditionCore.train(S,group.key),'pay reinforcement');
    ExpeditionIntegration.refresh();
   }
   learn('recipe_woodcutter');
   hire('woodcutter',270,315);
   learn('recipe_arch');
   const arch=hire('arch',515,210);
   let sword=null,ballista=null;
   for(let id=1;id<=CampaignCore.MAX_WAVE;id++){
    if(id===2){learn('hand1');learn('carry1');}
    if(id===3){learn('recipe_sword');sword=hire('sword',550,390);train(arch);}
    if(id===4){learn('hand2');learn('carry2');train(sword);}
    if(id===7){learn('recipe_ballista');ballista=hire('ballista',410,520);train(arch);}
    if(id===10){train(sword);train(ballista);}
    if(id===16){ExpeditionCore.setPolicy(S,arch.key,'healer');ExpeditionIntegration.refresh();}
    if(id===22){ExpeditionCore.setPolicy(S,ballista.key,'armor');ExpeditionIntegration.refresh();}
    TerritoryUI.home();
    check(TerritoryUI.start(id),'depart for '+id+' '+JSON.stringify({pending:S.pending,placement:BattleControl.placement,soldiers:ArmyView.sim.soldiers.map(a=>a.id),phase:S.invasion.phase}));
    for(let i=0;i<4000&&(S.territories.travel||S.invasion.phase!=='idle');i++)clock(.05);
    check(S.invasion.phase==='idle'&&!S.territories.travel,'settled '+id);
    const result={id,win:S.invasion.outcome?.win,reason:S.invasion.outcome?.reason,army:groups().filter(g=>!['woodcutter','miner','farmer'].includes(g.id)).map(g=>g.id+' '+g.count),gate:S.invasion.gateHP};
    battles.push(result);
    console.log('CAMPAIGN '+JSON.stringify(result));
    check(result.win,'campaign balance at '+id+' '+JSON.stringify(result));
    if(id<CampaignCore.MAX_WAVE)check(CampaignCore.objective(S.invasion.conquered).next===id+1,'next objective');
   }
   clock(2);
   save();
   return {battles,totals,completed:S.outpost.completed,objective:CampaignCore.objective(S.invasion.conquered)};
  });
  assert.equal(run.battles.length,30);
  assert.equal(run.completed,true);
  assert.equal(run.objective.regions,10);
  await page.locator('#campaignEnding.on').waitFor({timeout:10000});
  assert.match(await page.locator('#campaignEnding .ending-lead').innerText(),/黄昏の王.*10地域/);
  await page.screenshot({path:path.join(output,'02-ending.png')});
  await page.locator('#endingLook').click();
  await page.reload();
  await page.locator('#territoryEnding').click();
  await page.locator('#campaignEnding.on').waitFor();
  assert.deepEqual(errors,[]);
  fs.writeFileSync(path.join(output,'result.json'),JSON.stringify({...run,ending:true,reload:true,accelerated:true,nativeOpeningAndEnding:true},null,2));
 }finally{await browser.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
