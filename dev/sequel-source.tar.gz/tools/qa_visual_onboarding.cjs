/* Fresh earned onboarding: visible cue coordinates + visible buttons only. No grants, state edits or acceleration.
   CDP touch is emulation, not a real device. Text descriptions are never consulted. */
'use strict';
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const URL=(process.env.GAME_URL||'http://127.0.0.1:4456/preview/')+'?lesson=1',OUT=process.env.QA_OUT||'/tmp/qa-visual-onboarding';fs.mkdirSync(OUT,{recursive:true});
async function run(browser,mode){
 const touch=mode==='touch',ctx=await browser.newContext({viewport:touch?{width:390,height:844}:{width:1280,height:900},hasTouch:touch,isMobile:touch}),page=await ctx.newPage(),errors=[],log=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
 const cdp=touch?await ctx.newCDPSession(page):null;
 const tap=async q=>{if(touch){await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[q]});await page.waitForTimeout(55);await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});}else await page.mouse.click(q.x,q.y);await page.waitForTimeout(180);};
 const press=async selector=>{for(let tries=0;;tries++){try{const e=page.locator(selector).first();await e.waitFor({state:'visible'});await e.scrollIntoViewIfNeeded();const b=await e.boundingBox();assert.ok(b,selector+' visible');await tap({x:b.x+b.width/2,y:b.y+b.height/2});return;}catch(e){if(tries>=4)throw e;await page.waitForTimeout(220);}}};
 const screen=async p=>page.evaluate(p=>{const r=document.querySelector('#battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return {x:r.left+p.x*z,y:r.top+p.y*z};},p);
 const drag=async(a,b)=>{if(touch){await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[a]});for(let i=1;i<=12;i++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:a.x+(b.x-a.x)*i/12,y:a.y+(b.y-a.y)*i/12}]});await page.waitForTimeout(25);}await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});}else{await page.mouse.move(a.x,a.y);await page.mouse.down();await page.mouse.move(b.x,b.y,{steps:12});await page.mouse.up();}await page.waitForTimeout(250);};
 const read=()=>page.evaluate(()=>({cue:OutpostTutorial.visualCue(),started:OutpostTutorial.raidAllowed(),phase:S.outpost.phase,wood:S.factory.inventory.wood,stone:S.factory.inventory.stone,drops:S.factory.drops.length,workers:S.owned.woodcutter,arch:S.owned.arch,paused:Rework.paused,remaining:S.outpost.prepRemaining,workerDelivered:!!S.tutorial?.workerDelivered,workerPlaced:ArmyView.sim.soldiers.some(p=>p.id==='woodcutter'),pending:Object.values(S.pending||{}).some(n=>n>0)}));
 const startedAt=Date.now();let serial=0,last='';
 try{
 await page.goto(URL);await press('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady&&window.OutpostTutorial?.visualCue);
 const before=await read();await page.waitForTimeout(3000);const after=await read();assert.equal(after.wood,before.wood);assert.equal(after.drops,before.drops,'hand demonstration creates no resource');
 assert.equal(await page.locator('#onboardingGuide p').count(),0,'no explanatory paragraph');
 for(let i=0;i<500;i++){
  const s=await read();if(process.env.QA_GOAL==='raid'?(s.arch>=2&&!s.pending):(s.workerPlaced&&s.workerDelivered)){log.push({at:(Date.now()-startedAt)/1000,event:'worker-delivery-earned',...s});break;}
  if(Date.now()-startedAt>220000)throw Error('onboarding exceeds 220s');
  if(i%15===0)console.log(mode,'progress',i,JSON.stringify(s));const c=s.cue,key=c.step+':'+c.kind+':'+(c.type||'');if(key!==last){console.log(mode,key);log.push({at:(Date.now()-startedAt)/1000,event:key,wood:s.wood,stone:s.stone});last=key;await page.screenshot({path:path.join(OUT,mode+'-'+String(++serial).padStart(2,'0')+'-'+c.kind+'.png')});}
  if(c.button){await press('#onboardingAction');await page.waitForTimeout(750);if(c.kind==='upgrade'){await press('[data-harvest-learn]:not([disabled])');await page.waitForTimeout(500);await page.keyboard.press('Escape');await page.waitForTimeout(250);}continue;}
  await page.locator('#field').scrollIntoViewIfNeeded();
  if(c.kind==='tap'){assert.ok(c.point);await tap(await screen(c.point));}
  else if(c.kind==='carry'){assert.ok(c.point&&c.to);await drag(await screen(c.point),await screen(c.to));}
  else if(c.kind==='boost'&&c.point){await tap(await screen(c.point));}
  else if(c.kind==='place'&&c.point){const p=await screen(c.point);await drag(p,p);}
  else await page.waitForTimeout(400);
 }
 if(process.env.QA_GOAL==='raid'){await page.waitForFunction(()=>S.outpost.phase==='active',null,{timeout:300000});await page.screenshot({path:path.join(OUT,mode+'-automatic-raid.png')});}
 const earned=await read();assert.equal(earned.workerPlaced,true);assert.equal(earned.workerDelivered,true);assert.equal(earned.workers,1);assert.deepEqual(errors,[]);
 await page.screenshot({path:path.join(OUT,mode+'-worker-delivered.png')});return {mode,status:'passed',seconds:(Date.now()-startedAt)/1000,earned,log,errors,fixture:'Fresh save through hire, placement and real worker delivery; visible cue targets, real pointer input. Touch is CDP emulation.'};
 }catch(e){await page.screenshot({path:path.join(OUT,mode+'-FAIL.png')}).catch(()=>{});return {mode,status:'failed',message:e.stack,state:await read().catch(()=>null),log,errors};}finally{await ctx.close();}
}
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium'});let results;try{results=[];for(const mode of (process.env.QA_MODES||'pc,touch').split(','))results.push(await run(browser,mode));}finally{await browser.close();}fs.writeFileSync(path.join(OUT,'result.json'),JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,1));if(results.some(r=>r.status!=='passed'))process.exitCode=1;})().catch(e=>{console.error(e);process.exitCode=1;});
