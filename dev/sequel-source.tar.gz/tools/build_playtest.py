"""Build a separate static playtest without changing the original or release game."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import sys

source = Path(__file__).resolve().parent.parent
target = Path(sys.argv[1]).resolve()
preview = target / 'preview'
marker = preview / 'build.json'
if preview.exists() and not marker.exists():
    raise SystemExit('Refusing to overwrite an existing preview directory')
previous_assets=set(json.loads(marker.read_text()).get('playtest_assets', [])) if marker.exists() else set()
preview.mkdir(parents=True, exist_ok=True)

boot = """/* Isolated playtest: no online scores, analytics or advertisements. */
window.__MYTHOS_PLAYTEST__ = true;
(() => {
  const params = new URLSearchParams(location.search);
  const namespace = params.has('lab') ? 'mythos_lab:' : params.get('lesson') === '1' ? 'mythos_lesson:' : '';
  if (namespace) {
    // A separate practice slot preserves existing play and laboratory saves.
    for (const method of ['getItem', 'setItem', 'removeItem']) {
      const native = Storage.prototype[method];
      Storage.prototype[method] = function (key, ...args) {
        return native.call(this, namespace + key, ...args);
      };
    }
  }
  const nativeFetch = window.fetch.bind(window);
  window.fetch = (input, options) => {
    const url = new URL(typeof input === 'string' ? input : input.url, location.href);
    if (url.origin !== location.origin) {
      return Promise.resolve(new Response(JSON.stringify({error: 'playtest_offline'}), {
        status: 503, headers: {'Content-Type': 'application/json'}
      }));
    }
    return nativeFetch(input, options);
  };
})();
"""
(preview / 'playtest-boot.js').write_text(boot)
files = ['index.html', 'ranking.html', 'game-core.js', 'expedition-core.js', 'expedition-ui.js', 'expedition-ui.css', 'expedition-integration.js', 'EXPEDITION_DESIGN.md', 'supply-core.js',
         'rail-core.js', 'conveyor-core.js', 'placement-controls.js', 'compact-ui.css', 'harvest-skill-core.js', 'harvest-skills.js', 'harvest-skills.css', 'EXPANSION_DESIGN.md', 'army-sim.js', 'army-view.js', 'boss-art.js', 'battle-control.js',
         'supply-factory.js', 'forest-audio.js', 'camp-training.js', 'outpost-tutorial-core.js', 'outpost-tutorial.js', 'outpost-tutorial.css', 'outpost-core.js', 'outpost-camp.js', 'outpost.js', 'outpost.css', 'rework.js', 'rework.css', 'FOREST_LOOP.md', 'OUTPOST_DESIGN.md', 'REVIEW_EXPERIMENT.md', 'PLAYTEST_REVIEWS.md']
hashes = {}
for name in files:
    original = (source / '2' / name).read_text()
    hashes[name] = hashlib.sha256(original.encode()).hexdigest()
    text = original.replace('sbr2_', 'sbr2_preview_outpost_')
    if name.endswith('.html'):
        text = re.sub(r'<script\b[^>]*src="https://www\.googletagmanager\.com/[^\"]*"[^>]*></script>', '', text)
        text = text.replace('function gtag(){dataLayer.push(arguments);}', 'function gtag(){}')
        text = text.replace('<head>', '<head>\n<script src="playtest-boot.js"></script>\n<meta name="robots" content="noindex, nofollow">', 1)
        text = text.replace('<title>', '<title>[PLAYTEST] ', 1)
        text = text.replace('if(window.self!==window.top||PARAMS.has("capture")) return;', 'if(window.__MYTHOS_PLAYTEST__) return;')
        text = text.replace('MMXXVI · Bubblegum', 'PLAYTEST · Bubblegum · Online ranking off')
    if name == 'rework.js':
        text = text.replace('function track(event,params={}){', 'function track(event,params={}){if(window.__MYTHOS_PLAYTEST__)return;')
        text = text.replace('function queueMeasurement(seconds,count){', 'function queueMeasurement(seconds,count){if(window.__MYTHOS_PLAYTEST__)return;')
        text = text.replace("offlineRank:['通信できません。自己ベストはこの端末に保存されます。','Offline. Your personal best is saved on this device.','无法连接。个人最佳已保存在本设备。']", "offlineRank:['試遊版ではオンラインランキングは未接続です。自己ベストはこの端末に保存します。','Online rankings are disabled in this playtest. Personal bests are saved on this device.','试玩版尚未连接在线排行。个人最佳保存在本设备。']")
    (preview / name).write_text('\n'.join(line.rstrip() for line in text.splitlines()) + '\n')

for extension in ['html', 'js']:
    name = 'workshop.' + extension
    text = (source / 'tools' / ('playtest-' + name)).read_text()
    hashes[name] = hashlib.sha256(text.encode()).hexdigest()
    (preview / name).write_text(text)

media_index = (source / 'tools' / 'playtest-media.html').read_text()
(preview / 'media').mkdir(exist_ok=True)
(preview / 'media' / 'index.html').write_text(media_index)
hashes['media/index.html'] = hashlib.sha256(media_index.encode()).hexdigest()

# A fresh local build also needs the existing art. Never overwrite a deployed asset.
tracked_assets = subprocess.run(['git', 'ls-files', '-z', '--', 'assets'],
                                cwd=source, check=True, capture_output=True).stdout.decode().split('\0')
for name in filter(None, tracked_assets):
    src, dst = source / name, target / name
    if src.is_file() and not dst.exists():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)

# Existing paid assets are already in the Pages repository. Copy only new assets.
assets = subprocess.run(['git', 'ls-files', '--others', '--exclude-standard', '-z', '--', 'assets'],
                        cwd=source, check=True, capture_output=True).stdout.decode().split('\0')
for name in filter(None, assets):
    src, dst = source / name, target / name
    if dst.exists() and dst.read_bytes() != src.read_bytes() and name not in previous_assets:
        tracked = subprocess.run(['git', 'ls-files', '--error-unmatch', '--', name], cwd=target, capture_output=True).returncode == 0
        if tracked:
            raise SystemExit('Refusing to overwrite a different existing asset: ' + name)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
(preview / 'README.md').write_text('Mythos Slayers II — PLAYTEST\n\n'
    'A separate playtest; the original game remains at the repository root.\n'
    'Scores, analytics and ads are disabled. Local saves use sbr2_preview_outpost_ keys. The earlier forest prototype and its saves remain at forest/.\n'
    'The playtest is generated from the sequel source, without deploying its Worker.\n')
marker.write_text(json.dumps({'kind': 'mythos-slayers-2-playtest', 'ruleset': 'outpost-9-release-candidate-v6', 'source_sha256': hashes, 'playtest_assets': sorted(previous_assets | set(filter(None, assets)))}, indent=2) + '\n')
print('Built isolated playtest at ' + str(preview))
