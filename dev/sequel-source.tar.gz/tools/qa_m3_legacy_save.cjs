/* M3 prepared test: an existing save that already has a conveyor (made by real play on the published
   M1/M2 build) loads into the M3 build without breaking. Only visible inputs on the old build; the save is
   copied as-is (localStorage) into the new origin. evaluate() only reads state.
   Checks: belts kept and still deliver; conveyor cards locked until chapter 1; lesson does not replay
   blower/fence; the "new tools" notice shows once; the belt's removal card warns it cannot be rebuilt. */
'use strict';
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const OLD=(process.env.OLD_URL||'http://127.0.0.1:4423/preview/')+'?lesson=1',NEW=(process.env.GAME_URL||'http://127.0.0.1:4422/preview/')+'?lesson=1',OUT=process.env.QA_OUT||'/tmp/qa-m3-legacy';fs.mkdirSync(OUT,{recursive:true});
const helpers=(page,touch,cdp)=>{const touchEvent=(type,p)=>cdp.send('Input.dispatchTouchEvent',{type,touchPoints:p?[p]:[]});
 const screen=p=>page.evaluate(p=>{const r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return{x:r.left+p.x*z,y:r.top+p.y*z};},p);
 const tap=async(q,hold=60)=>{if(touch){await touchEvent('touchStart',q);await page.waitForTimeout(hold);await touchEvent('touchEnd');}else await page.mouse.click(q.x,q.y);await page.waitForTimeout(130);};
 const press=async sel=>{for(let i=0;;i++){try{const el=page.locator(sel).first();await el.waitFor({state:'visible',timeout:3000});await el.scrollIntoViewIfNeeded({timeout:1000});const b=await el.boundingBox();if(b){await tap({x:b.x+b.width/2,y:b.y+b.height/2});return;}}catch(e){if(i>=5)throw e;}await page.waitForTimeout(150);}};
 const drag=async(a,z,steps=14)=>{if(touch){await touchEvent('touchStart',a);for(let i=1;i<=steps;i++){await touchEvent('touchMove',{x:a.x+(z.x-a.x)*i/steps,y:a.y+(z.y-a.y)*i/steps});await page.waitForTimeout(16);}await touchEvent('touchEnd');}else{await page.mouse.move(a.x,a.y);await page.mouse.down();await page.mouse.move(z.x,z.y,{steps});await page.mouse.up();}await page.waitForTimeout(150);};
 const field=()=>page.locator('#field').scrollIntoViewIfNeeded();
 const tree=()=>page.evaluate(()=>{const n=S.factory.nodes.find(n=>n.type==='wood'&&n.stock>0),r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return{x:r.left+n.x*z,y:r.top+(n.y-48)*z};});
 const pile=()=>page.evaluate(()=>{const d=S.factory.drops.find(d=>d.type==='wood'&&!d.onConveyor&&!SupplyFactory.isAirborne(d));if(!d)return null;const b=SupplyFactory.pileBounds(d),r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return{x:r.left+(b.left+b.right)*.5*z,y:r.top+(b.top+b.bottom)*.5*z};});
 const harvest=async n=>{await field();for(let i=0;i<400;i++){if(await page.evaluate(()=>S.factory.drops.filter(d=>d.type==='wood'&&!d.worker&&!d.onConveyor).length)>=n)return;await tap(await tree(),40);}throw new Error('harvest stuck');};
 const deliver=async()=>{await field();for(let i=0;i<60;i++){const p=await pile();if(!p)return;await drag(p,await screen({x:100,y:290}));}};
 return {screen,tap,press,drag,field,harvest,deliver};};
async function makeOldSave(browser){
 const ctx=await browser.newContext({viewport:{width:1280,height:900}}),page=await ctx.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));const h=helpers(page,false,null);
 await page.goto(OLD);await page.waitForTimeout(1200);await h.press('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);await page.waitForTimeout(400);
 await h.harvest(10);await h.deliver();await h.press('#onboardingAction');await page.waitForTimeout(400);await h.press('[data-harvest-learn]:not([disabled])');await page.keyboard.press('Escape');await page.waitForTimeout(300);
 await h.harvest(6);await h.deliver();await h.press('[data-recruit="woodcutter"]');await page.waitForTimeout(400);await h.field();const spot=(await page.evaluate(()=>BattleControl.spots()))[0];await h.drag(await h.screen(spot),await h.screen(spot),2);
 const land=await page.evaluate(()=>{const p=ArmyView.sim.soldiers.find(p=>p.id==='woodcutter'),n=S.factory.nodes.filter(n=>n.type==='wood').sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y))[0];return SupplyFactory.outputForWorker(p,n);});
 await h.harvest(8);await h.deliver();await h.press('[data-equipment="belt"]');await page.waitForTimeout(300);await h.field();await h.drag(await h.screen({x:162,y:328}),await h.screen({x:land.x+12,y:land.y+6}),18);
 const before=await page.evaluate(()=>S.factory.delivered);await page.waitForFunction(d=>S.factory.delivered>d,before,{timeout:30000});await page.evaluate(()=>typeof save==='function'&&save());await page.waitForTimeout(500);
 const old={links:await page.evaluate(()=>S.camp.links.map(l=>({nodeKey:l.nodeKey,points:l.points}))),lesson:await page.evaluate(()=>document.body.dataset.lesson),storage:await page.evaluate(()=>{const out={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);out[k]=localStorage[k];}return out;})};
 await page.screenshot({path:path.join(OUT,'old-build-belt.png')});assert.deepEqual(errors,[]);await ctx.close();return old;
}
async function loadNew(browser,old,mode){
 const touch=mode==='touch',ctx=await browser.newContext(touch?{viewport:{width:390,height:844},hasTouch:true,isMobile:true,deviceScaleFactor:2}:{viewport:{width:1280,height:900}}),errors=[],checks=[];
 // Copy the saved keys exactly. The storage hook in playtest-boot prefixes lesson keys, and the raw keys already carry that prefix.
 await ctx.addInitScript(storage=>{if(sessionStorage.getItem('__m3_seeded'))return;for(const [k,v] of Object.entries(storage))localStorage.setItem(k,v);sessionStorage.setItem('__m3_seeded','1');},old.storage);
 const page=await ctx.newPage();page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});const cdp=touch?await ctx.newCDPSession(page):null,h=helpers(page,touch,cdp);
 try{
  await page.goto(NEW);await page.waitForTimeout(1200);if(await page.locator('#titleBattle').isVisible())await h.press('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);await page.waitForTimeout(600);
  const s=await page.evaluate(()=>({links:S.camp.links.map(l=>({nodeKey:l.nodeKey,points:l.points})),v:S.camp.logisticsVersion,legacy:S.camp.legacyBelts,seen:S.camp.newToolsSeen,lesson:document.body.dataset.lesson,note:document.getElementById('campDeliveryNote')?.textContent,cards:[...document.querySelectorAll('[data-equipment]')].map(b=>[b.dataset.equipment,b.disabled])}));
  assert.deepEqual(s.links,old.links);checks.push('belts kept exactly ('+s.links.length+')');assert.equal(s.v,2);assert.equal(s.legacy,true);
  assert.ok(!['blower','blowerDeliver','fence'].includes(s.lesson),'lesson '+s.lesson);checks.push('lesson after load: '+s.lesson+' (old build: '+old.lesson+')');
  assert.deepEqual(s.cards,[['blower',false],['fence',false],['belt',true],['platform',true]]);checks.push('conveyor/platform cards locked before chapter 1');
  assert.match(s.note,/送風機|Blower|鼓风机/);checks.push('one-time notice: '+s.note);await page.screenshot({path:path.join(OUT,mode+'-loaded.png')});
  const d0=await page.evaluate(()=>S.factory.delivered);await page.waitForFunction(d=>S.factory.delivered>d,d0,{timeout:30000});checks.push('the kept belt still delivers worker logs');
  await h.field();const pts=s.links[0].points,mid=pts[Math.floor(pts.length*.5)];await h.tap(await h.screen(mid));assert.equal(await page.evaluate(()=>OutpostCamp.selection?.kind),'belt');const label=await page.locator('[data-pick-action="remove"]').textContent();assert.match(label,/敷き直せません|rebuilt|无法重建/);checks.push('removal card: '+label);await page.screenshot({path:path.join(OUT,mode+'-belt-card.png')});
  await page.evaluate(()=>typeof save==='function'&&save());await page.reload();await page.waitForTimeout(1200);if(await page.locator('#titleBattle').isVisible())await h.press('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready);await page.waitForTimeout(600);
  const again=await page.evaluate(()=>({links:S.camp.links.length,note:document.getElementById('campDeliveryNote')?.textContent,seen:S.camp.newToolsSeen}));assert.equal(again.links,s.links.length);assert.equal(again.seen,true);assert.doesNotMatch(again.note||'',/新しい道具|New tools|新工具/);checks.push('after reload: belts kept, notice not repeated');
  assert.deepEqual(errors,[]);return {mode,status:'passed',checks};
 }catch(e){await page.screenshot({path:path.join(OUT,mode+'-FAIL.png')}).catch(()=>{});return {mode,status:'failed',message:e.stack,errors,checks};}finally{await ctx.close();}
}
(async()=>{const browser=await chromium.launch();const results=[];let old=null;try{old=await makeOldSave(browser);for(const m of (process.env.QA_MODES||'pc,touch').split(','))results.push(await loadNew(browser,old,m));}catch(e){results.push({status:'failed',message:e.stack});}finally{await browser.close();}
 fs.writeFileSync(path.join(OUT,'result.json'),JSON.stringify({fixture:'Save made by visible play on the published M1/M2 build ('+OLD+'), loaded into the M3 build; touch is CDP touch',oldLesson:old?.lesson,oldLinks:old?.links?.length,results},null,2));console.log(JSON.stringify(results,null,1));if(!results.length||results.some(r=>r.status!=='passed'))process.exitCode=1;})();
