// Prepared startup checks. Touch uses CDP-compatible browser emulation, not real hardware.
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium'}),rows=[];
try{for(const config of [{name:'pc',viewport:{width:1280,height:900}},{name:'lesson',lesson:true,viewport:{width:1280,height:900}},{name:'touch',viewport:{width:390,height:844},hasTouch:true,isMobile:true}]){
 const {name,lesson,...options}=config,context=await browser.newContext(options),page=await context.newPage(),errors=[],http=[],failed=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)http.push({url:r.url(),status:r.status()});});page.on('requestfailed',r=>{if(!(r.url().includes('.mp3')&&r.failure()?.errorText.includes('ERR_ABORTED')))failed.push({url:r.url(),error:r.failure()?.errorText});});
 await page.goto((process.env.GAME_URL||'http://127.0.0.1:4451/preview/')+(lesson?'?lesson=1':''));await page.locator('#titleBattle').click();await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);await page.waitForTimeout(2500);
 assert.deepEqual(errors,[]);assert.deepEqual(http,[]);assert.deepEqual(failed,[]);rows.push({name,errors,http,failed,touchEmulation:!!options.hasTouch});await context.close();
}}finally{await browser.close();}fs.writeFileSync('/tmp/spacebar-startup.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));})().catch(e=>{console.error(e);process.exitCode=1;});
