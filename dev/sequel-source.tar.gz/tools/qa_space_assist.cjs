/* Prepared browser regression, not earned progression. Custom delayed rat wave and ample camp
   are prepared through qa_heat.prepare. All Space actions use real browser key events.
   No audio listening is claimed. */
'use strict';
process.env.GAME_URL ||= 'http://127.0.0.1:4451/preview/';
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
const {prepare}=require('./qa_heat.cjs');
const OUT=process.env.SPACE_QA_OUT||'/tmp/qa-space-assist';fs.mkdirSync(OUT,{recursive:true});
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium'}),rows=[];
try{for(const mobile of [false,true]){const {context,page,errors}=await prepare(browser,{wave:4,groups:[],mobile});try{
 await page.evaluate(()=>document.querySelectorAll('.enemy-card').forEach(c=>c.remove()));
 const tree=await page.evaluate(()=>{const n=S.factory.nodes.find(n=>n.type==='wood'&&n.stock>0),r=document.getElementById('battleWorld').getBoundingClientRect(),z=ArmyView.camera.scale;return{x:r.left+n.x*z,y:r.top+(n.y-48)*z,key:n.key};});
 await page.locator('#field').scrollIntoViewIfNeeded();
 // The stock counter and selection are test setup; tree click uses the same screen position as earned QA.
 await page.mouse.click(tree.x,tree.y);assert.ok(await page.evaluate(()=>SupplyFactory.resourceTarget));
 const stock=()=>page.evaluate(key=>S.factory.nodes.find(n=>n.key===key).stock,tree.key);
 const hp=()=>page.evaluate(()=>S.outpost.enemies.reduce((n,e)=>n+e.hp,0));
 let before=await stock();await page.keyboard.press('Space');assert.equal(await stock(),before-1,'preparation Space harvests');
 before=await stock();await page.evaluate(()=>BattleControl.setPlacement(true));assert.ok(await page.evaluate(()=>BattleControl.placement));await page.keyboard.press('Space');assert.equal(await stock(),before,'placement prevents harvesting');await page.evaluate(()=>BattleControl.setPlacement(false));
 await page.evaluate(()=>Outpost.setNextModifiers({replace:true,duration:25,mix:[{kind:'rat',lane:'upper',count:2,at:3,gap:7}]}));
 await page.locator('#raidStart').click();await page.evaluate(()=>document.activeElement?.blur());
 assert.equal(await page.evaluate(()=>S.outpost.phase),'active');assert.equal(await page.evaluate(()=>S.outpost.enemies.length),0);
 before=await stock();await page.keyboard.press('Space');assert.equal(await stock(),before,'no enemy: active Space never harvests');assert.ok(await page.evaluate(()=>SupplyFactory.resourceTarget),'no enemy retains resource selection');
 await page.waitForFunction(()=>S.outpost.enemies.some(e=>e.alive));let hitBefore=await hp();await page.keyboard.press('Space');let hitAfter=await hp();const firstHitDamage=hitBefore-hitAfter;assert.ok(hitAfter<hitBefore,'first Space assists without enemy click');assert.equal(await stock(),before,'first assist did not harvest');
 assert.equal(await page.evaluate(()=>BattleControl.setPlacement(true)),false,'placement cannot begin in raid');
 await page.evaluate(()=>Rework.openTree());assert.ok(await page.evaluate(()=>Rework.paused));hitBefore=await hp();await page.keyboard.press('Space');assert.equal(await hp(),hitBefore,'overlay prevents attack');await page.evaluate(()=>Rework.close());
 await page.evaluate(()=>document.activeElement?.blur());await page.screenshot({path:OUT+'/'+(mobile?'mobile':'pc')+'.png'});assert.deepEqual(errors,[]);
 rows.push({mode:mobile?'mobile viewport / keyboard (not physical touch)':'PC keyboard',prepHarvest:true,noEnemyHarvestBlocked:true,firstAssistWithoutEnemyClick:true,placementBlocked:true,overlayBlocked:true,firstHitDamage,pageErrors:errors});
 console.log(rows.at(-1));
 }finally{await context.close();}}}finally{await browser.close();}
fs.writeFileSync(OUT+'/checks.json',JSON.stringify({kind:'prepared-input-regression',url:process.env.GAME_URL,rows},null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
