/* M4 real play, part 1: a fresh ?lesson=1 save played with visible inputs only (PC mouse 1280x900) through the
   M3 lesson (lumberjack, blower, fence, archers) and the first three raids, until Chapter 1 (Wave 3) is cleared
   and the wooden conveyor / hopper unlock. No grants, no state edits, no time acceleration.
   evaluate() only reads state, screen coordinates and the same predictions the board draws.
   Instrumentation: an init script counts ForestAudio cues (read-only wrapper) to check the unlock cue.
   Output: OUT/wave3-earned.json (Playwright storage state of the earned save) and OUT/journey.json. */
'use strict';
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const BASE=process.env.GAME_URL||'http://127.0.0.1:4451/preview/',URL=BASE+(BASE.includes('?')?'&':'?')+'lesson=1',OUT=process.env.QA_OUT||'/tmp/qa-m4-journey';fs.mkdirSync(OUT,{recursive:true});
const helpers=require('./qa_m4_helpers.cjs');
(async()=>{
 const browser=await chromium.launch(),ctx=await browser.newContext({viewport:{width:1280,height:900}});await ctx.addInitScript(helpers.cueCounter);
 const page=await ctx.newPage();page.on('response',r=>{if(r.status()>=400)console.log('HTTP_ERROR',r.status(),r.url());});const h=helpers.make(page,{touch:false,out:OUT,tag:'journey'}),result={fixture:'Fresh ?lesson=1 save, visible PC inputs only, no grants or time acceleration',waves:[]};
 try{
  await page.goto(URL);await page.waitForTimeout(1200);await h.press('#titleBattle');await page.waitForFunction(()=>window.Outpost?.ready&&SupplyFactory.artReady);await page.waitForTimeout(400);
  result.catalogueStart=await h.cards();assert.deepEqual(result.catalogueStart,[['blower',false],['fence',false],['belt',true],['hopper',true],['platform',true]]);h.note('catalogue at start',{cards:result.catalogueStart});
  await h.lesson();result.lessonDoneAt=h.secs();
  // Raids 1-3: timed waves; between them gather by hand, hire defenders when affordable, start when ready.
  while((await h.read()).cleared<3){
   const s=await h.read();if(h.secs()>2400)throw new Error('time limit before chapter 1');
   if(s.paused){await page.keyboard.press('Escape');await page.waitForTimeout(400);if((await h.read()).paused)await page.evaluate(()=>window.Rework?.close?.());continue;}
   if(s.phase==='active'){await h.assistRaid();const r=await h.read();result.waves.push({wave:r.wave,cleared:r.cleared,win:r.win,at:h.secs()});h.note('raid finished',{cleared:r.cleared,win:r.win});await h.shot('raid-'+r.wave+'-done');continue;}
   if(s.pending)await h.placePending();
   const target=s.cleared<1?2:s.cleared<2?3:4;
   if(s.arch<target){const c=await page.evaluate(()=>OutpostCore.recipe('arch',S.owned.arch||0,1));await h.need('stone',c.stone);await h.need('wood',c.wood);if((await h.read()).phase!=='active'){await h.placeAlly('arch',(s.arch%2)?'p.y>330':'p.y<300');h.note('archer hired',{n:s.arch+1});}continue;}
   if(await h.startRaid())continue;
   await h.harvest('wood',4);await h.deliver('wood');
  }
  // Chapter 1 cleared: close the result, then the unlock milestone appears on the field.
  for(let i=0;i<10&&(await h.read()).paused;i++){await page.keyboard.press('Escape');await page.waitForTimeout(400);}
  await page.waitForFunction(()=>S.camp.conveyorUnlockSeen===true,null,{timeout:15000});await page.waitForTimeout(250);
  result.unlock={at:h.secs(),banner:await page.evaluate(()=>OutpostCamp.unlockBannerActive),cues:await page.evaluate(()=>window.__cues.filter(c=>c==='unlock').length),glow:await page.evaluate(()=>document.querySelectorAll('.equipment-card.just-unlocked').length),cards:await h.cards(),note:await page.evaluate(()=>document.getElementById('campDeliveryNote')?.textContent),shake:await page.evaluate(()=>getComputedStyle(document.body).transform+'|'+getComputedStyle(document.getElementById('field')).transform)};
  h.note('unlock milestone',result.unlock);await h.field();await h.shot('unlock-banner');await page.locator('[data-equipment="hopper"]').scrollIntoViewIfNeeded();await h.shot('unlock-cards');
  assert.equal(result.unlock.banner,true);assert.ok(result.unlock.cues>=1);assert.deepEqual(result.unlock.cards,[['blower',false],['fence',false],['belt',false],['hopper',false],['platform',false]]);
  await page.evaluate(()=>typeof save==='function'&&save());await page.waitForTimeout(300);await ctx.storageState({path:path.join(OUT,'wave3-earned.json')});
  result.state=await h.read();result.camp=await page.evaluate(()=>({blowers:S.camp.blowers,fences:S.camp.fences,links:S.camp.links.length,owned:S.owned,skills:S.harvestSkills}));
  Object.assign(result,{status:'passed',seconds:h.secs(),inputs:h.counts.inputs,carries:h.counts.carries,errors:h.errors});assert.deepEqual(h.errors,[]);
 }catch(e){await h.shot('FAIL').catch(()=>{});Object.assign(result,{status:'failed',message:e.stack,errors:h.errors,seconds:h.secs()});process.exitCode=1;}
 finally{result.log=h.log;fs.writeFileSync(path.join(OUT,'journey.json'),JSON.stringify(result,null,1));await browser.close();console.log(JSON.stringify({...result,log:undefined},null,1));}
})();
