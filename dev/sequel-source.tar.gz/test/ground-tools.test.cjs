const test=require('node:test'),assert=require('node:assert/strict'),plain=v=>JSON.parse(JSON.stringify(v)),vm=require('node:vm'),fs=require('node:fs');
const C=require('../2/conveyor-core.js'),G=require('../2/ground-physics.js'),Core=require('../2/game-core.js'),Supply=require('../2/supply-core.js'),Tutorial=require('../2/outpost-tutorial-core.js');
// A small DOM stand-in: the camp builds its panels, but these tests only read game state.
function el(){return {style:{},dataset:{},classList:{add(){},remove(){},toggle(){},contains(){return false;}},append(){},prepend(){},before(){},after(){},insertBefore(){},replaceChildren(){},querySelector(){return el();},querySelectorAll(){return [];},addEventListener(){},setAttribute(){},removeAttribute(){},getBoundingClientRect(){return {left:0,top:0,width:960,height:540};}};}
function camp(cleared=0){
 const S=Core.fresh(['woodcutter','miner','arch','sword']);S.factory=Supply.fresh(960,540);S.outpost={cleared};S.factory.individualDrops=true;
 const scope={S,LANG:'ja',SupplyCore:Supply,ConveyorCore:C,GroundPhysics:G,RailCore:require('../2/rail-core.js'),Rework:{paused:false,close(){}},document:{getElementById:id=>['field','deckMain'].includes(id)?el():null,createElement:()=>el(),body:el()},ForestAudio:{play(){}},save(){},ArmyView:{sim:{soldiers:[]},camera:{scale:1}},SupplyFactory:{translate(){}},OutpostTutorial:{delivered:(...a)=>Tutorial.delivered(S,...a)}};scope.FieldCore=require('../2/field-core.js');scope.MaterialsCore=require('../2/materials-core.js');scope.window=scope;scope.clearTimeout=clearTimeout;vm.createContext(scope);
 vm.runInContext(fs.readFileSync(require.resolve('../2/outpost-camp.js'),'utf8'),scope);const api=scope.OutpostCamp;api.quote('woodTool');return {S,api,scope};
}

test('before chapter 1 conveyors are locked in the catalogue and cannot be started; blower and fence are open',()=>{
 const {S,api}=camp(0),html=api.catalogHTML();
 assert.match(html,/data-equipment="belt" disabled/);assert.match(html,/data-equipment="platform" disabled/);assert.match(html,/章1クリアで解放/);
 assert.doesNotMatch(html,/data-equipment="blower" disabled/);assert.doesNotMatch(html,/data-equipment="fence" disabled/);
 S.factory.inventory.wood=50;S.factory.inventory.stone=50;assert.equal(api.beginRail(),false);assert.equal(api.buildPlatform(),false);assert.equal(api.buildingKind,null);
 S.outpost.cleared=3;assert.doesNotMatch(api.catalogHTML(),/data-equipment="belt" disabled/);assert.equal(api.beginRail(),true);assert.equal(api.buildingKind,'belt');
});

test('a blower costs 4 wood, keeps clear of trees and the house, and is selected, turned and removed for half',()=>{
 const {S,api}=camp();S.factory.inventory.wood=3;assert.equal(api.buildDevice('blower'),true);assert.equal(api.buildingKind,'blower');
 assert.equal(api.placeBlower({x:400,y:330}),false,'not enough wood');S.factory.inventory.wood=10;
 assert.equal(api.placeBlower({x:340,y:300}),false,'on a tree trunk');assert.equal(api.placeBlower({x:110,y:340}),false,'on the house');
 assert.equal(api.placeBlower({x:400,y:330}),true);assert.equal(S.factory.inventory.wood,6);assert.deepEqual(plain(S.camp.blowers),[{key:1,x:400,y:330,dir:4,costWood:4}]);
 assert.equal(api.placeBlower({x:410,y:335}),false,'too close to another blower');
 api.selectAt({x:404,y:332});assert.deepEqual(plain(api.selection),{kind:'blower',key:1});
 assert.equal(api.removePiece('blower',1),true);assert.equal(S.factory.inventory.wood,8);assert.equal(S.camp.blowers.length,0);
});

test('a blower preview rejects allied feet, hopper bodies and the solid roof without spending wood',()=>{
 const {S,api,scope}=camp();S.factory.inventory.wood=20;api.buildDevice('blower');
 scope.ArmyView.sim.soldiers.push({x:600,y:330,r:10});
 S.camp.hoppers.push({key:1,x:700,y:330,dir:4});
 for(const point of [{x:600,y:330},{x:622,y:330},{x:700,y:330},{x:720,y:330},{x:50,y:250},{x:NaN,y:330}]){
  assert.equal(api.canPlaceBlower(point),false);
  assert.equal(api.placeBlower(point),false);
 }
 assert.equal(S.factory.inventory.wood,20);
 assert.equal(api.canPlaceBlower({x:640,y:330}),true,'space remains between the ally and hopper');
 assert.equal(api.placeBlower({x:640,y:330}),true);
 assert.equal(S.factory.inventory.wood,16);
});

test('a fence is clamped to 24-120, costs 1 wood per 24, can be undone in full, and is selectable on its line',()=>{
 const {S,api}=camp();S.factory.inventory.wood=20;api.buildDevice('fence');
 assert.equal(api.placeFence({a:{x:200,y:300},b:{x:210,y:300}}),false,'too short');
 assert.equal(api.placeFence({a:{x:500,y:200},b:{x:800,y:200}}),true);const f=S.camp.fences[0];assert.equal(G.fenceLength(f),120);assert.equal(f.costWood,5);assert.equal(S.factory.inventory.wood,15);
 api.selectAt({x:560,y:206});assert.deepEqual(plain(api.selection),{kind:'fence',key:1});api.clearSelection();
 api.undoBuild();assert.equal(S.camp.fences.length,0);assert.equal(S.factory.inventory.wood,20);
});

test('tapping a blower gives strong wind on the game clock; ground deliveries count as blown, not belt, wood',()=>{
 const {S,api}=camp();S.factory.inventory.wood=10;api.buildDevice('blower');api.placeBlower({x:400,y:330});S.factory.time=10;
 assert.equal(api.boostBlower(1),true);assert.equal(S.camp.blowers[0].boostUntil,13);api.boostBlower(1);assert.equal(S.camp.blowers[0].boostUntil,14);
 const wood=S.factory.inventory.wood;api.receiveGround([{type:'wood',count:1,worker:true,via:'blower'}]);
 assert.equal(S.factory.inventory.wood,wood+1);assert.equal(S.tutorial.blownWood,1);assert.equal(S.tutorial.automaticWood,0);
});

test('existing belts are kept before chapter 1; their removal note says they cannot be rebuilt yet',()=>{
 const {S,api}=camp(1);S.camp.links.push({nodeKey:1,type:'wood',kind:'conveyor',points:[{x:100,y:340},{x:250,y:340}],costWood:4});
 api.selectAt({x:180,y:342});assert.deepEqual(plain(api.selection),{kind:'belt',key:1});
 assert.equal(api.removePiece('belt',1),true);assert.equal(api.beginRail(),false,'cannot be rebuilt until chapter 1');
});

test('placing has the same limits as loading keeps (40 blowers, 80 fences) and says why',()=>{
 const {S,api}=camp();S.factory.inventory.wood=1000;api.buildDevice('blower');let placed=0;
 for(let x=500;x<=900&&placed<41;x+=34)for(let y=120;y<=520&&placed<41;y+=34)if(api.canPlaceBlower({x,y})&&api.placeBlower({x,y}))placed++,api.buildDevice('blower');
 assert.equal(S.camp.blowers.length,40);assert.equal(placed,40);assert.equal(api.limits.blowers,40);
 const core=Core.migrate(JSON.parse(JSON.stringify({...S,camp:{...S.camp,blowers:Array.from({length:150},(_,i)=>({key:i+1,x:100+i,y:200,dir:0,costWood:4}))}})),['woodcutter']);assert.equal(core.camp.blowers.length,150,'an old save above the placing limit loses nothing');
});

test('blower placement does not depend on the camera zoom; its body wins taps over logs inside its circle',()=>{
 const {S,api,scope}=camp();const p={x:336,y:290};const near=api.canPlaceBlower(p);scope.ArmyView.camera.scale=.4;assert.equal(api.canPlaceBlower(p),near);scope.ArmyView.camera.scale=1;
 S.factory.inventory.wood=10;api.buildDevice('blower');api.placeBlower({x:600,y:450});
 scope.SupplyFactory.pileAt=()=>({key:99});api.selectAt({x:606,y:452});assert.deepEqual(plain(api.selection),{kind:'blower',key:1},'the log under the finger does not steal the blower');
 assert.equal(plain(api.blowerAt({x:600+40,y:450})),null);scope.ArmyView.camera.scale=.4;assert.equal(api.blowerAt({x:640,y:450}).kind,'blower','44 screen px across on a zoomed-out phone');
});

test('the fence preview is exactly the stored shape (same clamp and rounding)',()=>{
 const {S,api}=camp();S.factory.inventory.wood=20;api.buildDevice('fence');const raw={a:{x:500.123,y:200.456},b:{x:801.789,y:233.21}};
 assert.equal(api.placeFence(raw),true);const f=plain(S.camp.fences[0]);
 const want=G.clampFence(raw.a,raw.b),r=v=>Math.round(v*10)/10;assert.deepEqual({a:f.a,b:f.b},{a:{x:r(want.a.x),y:r(want.a.y)},b:{x:r(want.b.x),y:r(want.b.y)}});
});

test('strong wind: the pitch climbs only on presses that add time; at the limit one full note, then it holds; empty fan is a miss',()=>{
 const {S,api,scope}=camp();const played=[];scope.ForestAudio={play:(k,o)=>played.push([k,o?.rate??1])};S.factory.inventory.wood=10;api.buildDevice('blower');api.placeBlower({x:600,y:450});
 S.factory.time=10;api.boostBlower(1);assert.equal(played.at(-1)[0],'gustMiss','nothing in the fan');
 const d=Supply.drop(S.factory,'wood',1,560,450,1,240);d.physical=true;played.length=0;S.camp.blowers[0].boostUntil=-Infinity;
 for(let i=0;i<6;i++){S.factory.time=20+i*.05;api.boostBlower(1);}
 assert.deepEqual(played.map(p=>p[0]),['gust','gust','gust','gustFull','gust','gust']);const rates=played.map(p=>p[1]);
 assert.ok(rates[1]>rates[0]&&rates[2]>rates[1]);assert.equal(rates[4],rates[3]);assert.equal(rates[5],rates[3]);assert.ok(Math.abs(S.camp.blowers[0].boostUntil-(20.25+5))<1e-9);
});

test('the preview counts a belt landing as home only when that belt reaches the house',()=>{
 const S={factory:Supply.fresh(960,540,1),owned:{},camp:{version:1,links:[],platforms:[],blowers:[{key:1,x:610,y:410,dir:1}],fences:[],cargo:[],nextKey:1},harvestSkills:{},outpost:{cleared:0},pending:{},gold:0};Supply.individualize(S.factory);
 const env={__OUTPOST_BUILD__:true,S,LANG:'ja',SupplyCore:Supply,ConveyorCore:C,GroundPhysics:G,HarvestSkillCore:require('../2/harvest-skill-core.js'),Image:class{},performance:{now:()=>0},requestAnimationFrame:()=>0,cancelAnimationFrame(){},save(){},document:{getElementById:()=>null,hidden:false},ArmyView:{sim:{soldiers:[],setObstacles(){}},camera:{scale:1},point:(x,y)=>({x,y})},BattleControl:{reserved:[],neighbors:()=>[]},ForestAudio:{play(){}}};env.FieldCore=require('../2/field-core.js');env.MaterialsCore=require('../2/materials-core.js');env.window=env;vm.createContext(env);
 vm.runInContext(fs.readFileSync(require.resolve('../2/supply-factory.js'),'utf8'),env);const sf=env.SupplyFactory;
 S.camp.links.push({nodeKey:9,type:'wood',kind:'conveyor',points:[{x:600,y:470},{x:700,y:470}],costWood:5});
 const r=sf.groundPredict({x:640,y:440});assert.equal(r.status,'belt');assert.equal(sf.reachesHome(r),false,'a dead-end belt is not home');
 S.camp.links[0].points=[{x:100,y:340},{x:600,y:470},{x:700,y:470}];S.factory.time+=1;const r2=sf.groundPredict({x:640,y:440});assert.equal(r2.status,'belt');assert.equal(sf.reachesHome(r2),true);
});
