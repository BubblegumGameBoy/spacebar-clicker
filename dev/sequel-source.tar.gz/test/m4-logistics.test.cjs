'use strict';
// M4: wooden conveyor (chapter 1 reward, 240 per belt), hopper, delivery preview from a belt graph, save migration.
const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),plain=v=>JSON.parse(JSON.stringify(v));
const C=require('../2/conveyor-core.js'),G=require('../2/ground-physics.js'),Core=require('../2/game-core.js'),Supply=require('../2/supply-core.js'),Tutorial=require('../2/outpost-tutorial-core.js');

function el(){return {style:{},dataset:{},classList:{add(){},remove(){},toggle(){},contains(){return false;}},append(){},prepend(){},before(){},after(){},insertBefore(){},replaceChildren(){},querySelector(){return el();},querySelectorAll(){return [];},addEventListener(){},setAttribute(){},removeAttribute(){},getBoundingClientRect(){return {left:0,top:0,width:960,height:540};}};}
function camp(cleared=0,lang='ja'){
 const S=Core.fresh(['woodcutter','miner','arch','sword']);S.factory=Supply.fresh(960,540);S.outpost={cleared};S.factory.individualDrops=true;const sounds=[];
 const scope={S,LANG:lang,SupplyCore:Supply,ConveyorCore:C,GroundPhysics:G,RailCore:require('../2/rail-core.js'),Rework:{paused:false,close(){},track(){}},document:{getElementById:id=>id==='titleScreen'?{classList:{contains:()=>true}}:['field','deckMain','panels','rxToolbar','supplyInventory'].includes(id)?el():null,createElement:()=>el(),body:el(),addEventListener(){},activeElement:null},ForestAudio:{play(k){sounds.push(k);}},save(){},addEventListener(){},matchMedia:()=>({matches:false}),performance:{now:()=>0},ArmyView:{sim:{soldiers:[]},camera:{scale:1}},SupplyFactory:{translate(){}},OutpostTutorial:{delivered:(...a)=>Tutorial.delivered(S,...a)}};scope.window=scope;vm.createContext(scope);
 vm.runInContext(fs.readFileSync(require.resolve('../2/outpost-camp.js'),'utf8'),scope);const api=scope.OutpostCamp;api.quote('woodTool');return {S,api,scope,sounds};
}

// ---- belt graph preview == stepped preview ----
function rng(seed){return ()=>{seed=(seed*1103515245+12345)%2147483648;return seed/2147483648;};}
function layout(r){
 const ri=(a,b)=>Math.floor(a+r()*(b-a+1)),links=[],platforms=[];let key=1;
 for(let i=0,n=ri(1,12);i<n;i++){
  const mode=r();let start;
  if(mode<.3||!links.length)start={...C.HOME};
  else if(mode<.7){const l=links[ri(0,links.length-1)],ps=C.oriented(l),q=C.at(ps,r()*C.length(ps));start={x:Math.round(q.x)+(r()<.3?ri(-8,8):0),y:Math.round(q.y)+(r()<.3?ri(-8,8):0)};}
  else start={x:ri(60,900),y:ri(130,510)};
  let pts=[start];for(let k=0,m=ri(1,4);k<m;k++){const e=pts.at(-1);pts=C.stretch(pts,{x:Math.max(14,Math.min(946,e.x+ri(-160,160))),y:Math.max(140,Math.min(520,e.y+ri(-120,120)))},r()<.5?C.MAX_LENGTH:Infinity);}
  if(pts.length>1)links.push({nodeKey:key++,type:'wood',kind:'conveyor',points:pts});
 }
 for(let i=0,n=r()<.5?0:ri(1,3);i<n;i++){let x,y;if(r()<.5&&links.length){const ps=links[ri(0,links.length-1)].points,q=r()<.5?ps.at(-1):ps[0];x=Math.round(q.x)+ri(-40,40);y=Math.round(q.y)+ri(-30,30);}else{x=ri(150,850);y=ri(170,500);}platforms.push({key:i+1,x,y,w:96,h:64,dir:ri(0,3)});}
 const points=[];for(const l of links){const ps=C.oriented(l),L=C.length(ps);for(let k=0;k<4;k++){const q=C.at(ps,r()*L);points.push({x:q.x+(r()<.5?ri(-10,10):0),y:q.y+(r()<.5?ri(-10,10):0)});}}
 for(const p of platforms)for(let k=0;k<3;k++)points.push({x:p.x+ri(-50,50),y:p.y+ri(-34,34)});
 return {links,platforms,points,speed:[45,56.25,90,135][ri(0,3)]};
}
test('the belt-graph preview gives exactly the stepped answer (random layouts, platforms, cycles, route-skill speeds)',()=>{
 const r=rng(20261026);let n=0;const seen={};
 for(let c=0;c<120;c++){const {links,platforms,points,speed}=layout(r);for(const p of points){const a=C.deliveryStatusLegacy(links,platforms,p,speed),b=C.deliveryStatus(links,platforms,p,speed);assert.equal(b,a,JSON.stringify({links,platforms,p,speed}).slice(0,400));seen[a]=(seen[a]||0)+1;n++;}}
 assert.ok(n>1500);for(const k of ['warehouse','blocked','unknown','manual'])assert.ok(seen[k]>0,'covers '+k);
});
test('graph preview agrees on the hand-made cases: joints, wrong direction, platforms, loops, long steps, mutated layouts',()=>{
 const home={kind:'conveyor',nodeKey:1,points:[C.HOME,{x:300,y:340}]},branch={kind:'conveyor',nodeKey:2,points:[{x:250,y:340},{x:250,y:470}]},gap={kind:'conveyor',nodeKey:3,points:[{x:300,y:352},{x:420,y:352}]},platform={key:1,x:500,y:300,w:96,h:64,dir:2},fromPlatform={kind:'conveyor',nodeKey:4,points:[{x:300,y:340},{x:500,y:270}]};
 const loopA={kind:'conveyor',nodeKey:5,points:[{x:600,y:200},{x:690,y:200}]},loopB={kind:'conveyor',nodeKey:6,points:[{x:690,y:200},{x:690,y:290}]},loopC={kind:'conveyor',nodeKey:7,points:[{x:690,y:290},{x:600,y:290}]},loopD={kind:'conveyor',nodeKey:8,points:[{x:600,y:290},{x:600,y:200}]};
 const sets=[[home,branch],[home,gap],[home,fromPlatform],[home,branch,gap,fromPlatform],[loopA,loopB,loopC,loopD],[home,loopA,loopB,loopC,loopD]];
 for(const links of sets)for(const platforms of [[],[platform]])for(const speed of [45,90,135])for(let x=120;x<=720;x+=13)for(const y of [200,270,290,300,340,352,400,460]){const p={x,y};assert.equal(C.deliveryStatus(links,platforms,p,speed),C.deliveryStatusLegacy(links,platforms,p,speed),JSON.stringify({x,y,speed,keys:links.map(l=>l.nodeKey),platforms:platforms.length}));}
 // the cache follows edits made in place (same arrays, changed points)
 const links=[home,{kind:'conveyor',nodeKey:2,points:[{x:250,y:340},{x:250,y:470}]}],p={x:250,y:450};assert.equal(C.deliveryStatus(links,[],p),'warehouse');links[1].points[0]={x:250,y:300};assert.equal(C.deliveryStatus(links,[],p),C.deliveryStatusLegacy(links,[],p));links[1].points[0]={x:250,y:372};assert.equal(C.deliveryStatus(links,[],p),'blocked');
});
test('a new point is judged in under 1 ms with 20 belts of 4,000 total length (median, this machine)',()=>{
 const links=[];let cur={...C.HOME},dir=1;
 for(let i=0;i<20;i++){let t={x:cur.x+180*dir,y:cur.y};if(t.x>900||t.x<120){t={x:cur.x,y:cur.y+(cur.y<400?200:-200)};dir=-dir;}let ps=C.stretch([cur],t);if(C.length(ps)<200)ps=C.stretch(ps,{x:t.x,y:t.y+(200-C.length(ps))*(t.y<460?1:-1)});links.push({nodeKey:i+1,type:'wood',kind:'conveyor',points:ps});cur={...ps.at(-1)};}
 const total=links.reduce((n,l)=>n+C.length(l.points),0);assert.ok(Math.abs(total-4000)<1,'total '+total);
 const r=rng(7),pts=links.flatMap(l=>Array.from({length:20},()=>{const q=C.at(l.points,r()*C.length(l.points));return {x:q.x+r()*2-1,y:q.y+r()*2-1};}));
 for(const p of pts.slice(0,50))C.deliveryStatus(links,[],{x:p.x+.5,y:p.y});
 const times=pts.map(p=>{const t=process.hrtime.bigint();assert.equal(C.deliveryStatus(links,[],p),'warehouse');return Number(process.hrtime.bigint()-t)/1e6;}).sort((a,b)=>a-b);
 assert.ok(times[times.length>>1]<1,'median '+times[times.length>>1]+' ms');
});

// ---- wooden conveyor: 240 per belt ----
test('a wooden belt stops growing at 240; a farther route joins a second belt at the end and still reaches home',()=>{
 assert.equal(C.MAX_LENGTH,240);let p=C.stretch([C.HOME],{x:700,y:340},C.MAX_LENGTH);assert.ok(Math.abs(C.length(p)-240)<1e-6);assert.equal(C.cost(p),5);
 assert.deepEqual(C.stretch(p,{x:900,y:340},C.MAX_LENGTH),p,'no growth past the limit');
 const first={kind:'conveyor',nodeKey:1,points:p},second={kind:'conveyor',nodeKey:2,points:C.stretch([{...p.at(-1)}],{x:560,y:340},C.MAX_LENGTH)};
 assert.equal(C.deliveryStatus([first,second],[],{x:540,y:340}),'warehouse');assert.equal(C.deliveryStatus([first],[],{x:540,y:340}),'manual');
});
test('in the camp a dragged belt is capped at 240 and costs 5; grabbing the end of a full belt starts a joined belt',()=>{
 const {S,api}=camp(3);S.factory.inventory.wood=60;assert.equal(api.beginRail(),true);
 assert.equal(api.beltStartAt({x:100,y:340}),true);api.dragBeltTo({x:500,y:340});api.dragBeltTo({x:800,y:340});assert.equal(api.beltCapped,true);
 assert.ok(Math.abs(C.length(api.draftRoute.points)-240)<1e-6);assert.equal(api.draftRoute.cost,5);assert.equal(api.commitRails(),true);assert.equal(S.factory.inventory.wood,55);
 const end=C.oriented(S.camp.links[0]).at(-1);assert.equal(api.beltStartAt(end),true);api.dragBeltTo({x:end.x+150,y:end.y});assert.equal(api.commitRails(),true);
 assert.equal(S.camp.links.length,2,'a second belt, not a longer first one');assert.ok(C.length(S.camp.links[0].points)<=240+1e-6);assert.deepEqual(plain(S.camp.links[1].points[0]),plain(end));
 assert.equal(C.deliveryStatus(S.camp.links,[],{x:end.x+120,y:end.y}),'warehouse');
 // a shorter belt is extended in place, up to the limit
 S.camp.links.length=0;api.beltStartAt({x:100,y:340});api.dragBeltTo({x:200,y:340});api.commitRails();const tail=C.oriented(S.camp.links[0]).at(-1);api.beltStartAt(tail);api.dragBeltTo({x:700,y:340});api.commitRails();
 assert.equal(S.camp.links.length,1);assert.ok(Math.abs(C.length(S.camp.links[0].points)-240)<1e-6);
});

// ---- save migration (logisticsVersion 2) ----
function oldSave(){
 // An M1-era save (before logisticsVersion): a 470-long conveyor, a short one, a platform, cargo on a belt, route skill 3.
 const S=Core.fresh(['woodcutter','miner','arch']);S.factory=Supply.fresh(960,540);Supply.individualize(S.factory);S.outpost={cleared:1};S.harvestSkills={carry:2,hand:1,route:3,yard:1};
 const long=C.stretch([C.HOME],{x:300,y:220});const longer=C.stretch(long,{x:560,y:300});
 S.camp={version:1,links:[{nodeKey:1,type:'wood',kind:'conveyor',points:longer,costWood:10},{nodeKey:2,type:'wood',kind:'conveyor',points:[{x:330,y:440},{x:200,y:420}],costWood:3}],platforms:[{key:1,x:600,y:330,w:96,h:64,dir:2,costWood:8,costStone:4}],cargo:[{key:5,type:'wood',count:1,from:{x:300,y:300},progress:.4,duration:.6,mode:'manual'}],nextKey:6,tools:{wood:1,stone:0},gate:false,beacon:false,cart:true,endingSeen:false};
 const d=Supply.drop(S.factory,'wood',1,longer[8].x,longer[8].y,1);d.onConveyor=true;d.beltId=1;d.physical=true;S.factory.inventory.wood=17;
 return JSON.parse(JSON.stringify(S));
}
test('an older save keeps its belts (even past 240), cargo, platform and route skill; it is marked as legacy logistics v2',()=>{
 const raw=oldSave(),r=Core.migrate(JSON.parse(JSON.stringify(raw)),['woodcutter','miner','arch']);
 assert.deepEqual(plain(r.camp.links.map(l=>({nodeKey:l.nodeKey,kind:l.kind,points:l.points,costWood:l.costWood}))),raw.camp.links.map(l=>({nodeKey:l.nodeKey,kind:l.kind,points:l.points,costWood:l.costWood})));
 assert.ok(C.length(r.camp.links[0].points)>400,'longer than the new limit and kept');
 assert.deepEqual(plain(r.camp.platforms),raw.camp.platforms);assert.deepEqual(plain(r.camp.cargo).map(c=>[c.key,c.type,c.count,c.progress]),[[5,'wood',1,.4]]);
 assert.equal(r.harvestSkills.route,3);assert.equal(r.harvestSkills.carry,2);assert.equal(r.camp.logisticsVersion,2);assert.equal(r.camp.legacyBelts,true);assert.deepEqual(plain(r.camp.hoppers),[]);assert.equal(r.camp.conveyorUnlockSeen,false);
 const drop=r.factory.drops.find(d=>d.beltId===1);assert.ok(drop&&drop.onConveyor,'the item on the belt stays on it');assert.equal(r.factory.inventory.wood,17);
 // the old long belt still delivers
 assert.equal(C.deliveryStatus(r.camp.links,r.camp.platforms,{x:drop.x,y:drop.y},45*Math.min(3,1.5)),'warehouse');
 // hoppers and the unlock flag survive a round trip; bad hoppers are dropped
 r.camp.hoppers=[{key:1,x:420,y:300,dir:3,costWood:10,costStone:4},{key:1,x:1,y:1,dir:0},{key:'x',x:5,y:5},{key:2,x:'a',y:3}];r.camp.conveyorUnlockSeen=true;
 const again=Core.migrate(JSON.parse(JSON.stringify(r)),['woodcutter','miner','arch']);assert.deepEqual(plain(again.camp.hoppers),[{key:1,x:420,y:300,dir:3,costWood:10,costStone:4}]);assert.equal(again.camp.conveyorUnlockSeen,true);assert.equal(again.camp.legacyBelts,true);
});
test('before chapter 1 an older belt keeps working and can be removed, with a 3-language note that it cannot be rebuilt yet',()=>{
 for(const [lang,re] of [['ja',/解放前のため敷き直せません/],['en',/Cannot be rebuilt until unlocked/],['zh',/解锁前无法重建/]]){
  const {S,api}=camp(1,lang);const raw=oldSave();S.camp=Core.migrate(raw,['woodcutter']).camp;
  api.selectAt({x:S.camp.links[1].points[0].x-20,y:(S.camp.links[1].points[0].y+S.camp.links[1].points[1].y)/2+2.5});assert.deepEqual(plain(api.selection),{kind:'belt',key:2});assert.match(api.selectionLabel,re);
  assert.equal(api.beginRail(),false);
 }
 const {S,api}=camp(1,'ja');S.camp=Core.migrate(oldSave(),['woodcutter']).camp;assert.equal(api.removePiece('belt',2),true);assert.equal(S.camp.links.length,1);assert.equal(api.beginRail(),false);
});

// ---- hopper ----
function world(extra={}){return G.normalizeWorld({width:960,height:540,nodes:[],home:C.HOME,blowers:[],fences:[],hoppers:[],...extra});}
function run(w,items,seconds,links=[],platforms=[]){const states=[],out=[],arrived=[];let t=0;
 for(let i=0;i<Math.round(seconds/G.DT);i++){t+=G.DT;
  const skip=d=>d.hopperKey!=null||d.onConveyor;G.stepAll(w,items,t,G.DT,skip);
  const r=G.hopperStep(w,states,items,t,G.DT,d=>!d.onConveyor&&!C.contact(links,d));for(const e of r.emitted)out.push({key:e.item.key,t:+t.toFixed(3)});
  for(const d of items.slice()){if(d.hopperKey!=null)continue;const n=C.step(links,platforms,d,G.DT,45);if(!n.onConveyor)continue;d.onConveyor=true;d.vx=0;d.vy=0;if(n.arrived){items.splice(items.indexOf(d),1);arrived.push(d.key);continue;}d.x=n.x;d.y=n.y;d.beltId=n.beltId;}}
 return {out,arrived,states};}
test('a hopper draws items in one at a time, nearest first, never from its outlet side, and lets one out every 0.6 s',()=>{
 const w=world({hoppers:[{key:1,x:400,y:300,dir:0}]}),items=[{key:3,x:360,y:300},{key:4,x:400,y:255},{key:5,x:430,y:300},{key:6,x:400,y:420}].map(d=>({...d,type:'wood',count:1}));
 const {out}=run(w,items,3);
 assert.deepEqual(out.map(o=>o.key),[3,4],'nearest first; the item in front of the outlet and the far one stay');
 assert.ok(Math.abs(out[1].t-out[0].t-.6)<G.DT+1e-9,'0.6 s apart: '+JSON.stringify(out));
 assert.equal(items.length,4);assert.ok(items.every(d=>d.count===1&&d.hopperKey==null),'still four single items');
 const k5=items.find(d=>d.key===5),k6=items.find(d=>d.key===6);assert.deepEqual([k5.x,k5.y,k6.x,k6.y],[430,300,400,420]);
 for(const k of [3,4]){const d=items.find(d=>d.key===k);assert.ok(d.x>424,'left by the outlet to the right: '+d.x);}
 assert.equal(G.hopperAt(w,{x:440,y:300}),-1);assert.equal(G.hopperAt(w,{x:360,y:300}),0);assert.equal(G.hopperAt(w,{x:400,y:361}),-1);
});
test('a hopper gathers scattered landing spots into one belt entrance; the preview says so and the items arrive',()=>{
 // Hopper at (330,420) facing left (dir 4) feeds a belt that starts at its outlet and runs to the house.
 const belt={kind:'conveyor',nodeKey:1,points:C.stretch([C.HOME],{x:306,y:420},C.MAX_LENGTH)};
 const links=[belt],w=world({hoppers:[{key:1,x:330,y:420,dir:4}],belt:p=>!!C.contact(links,p)});
 const spots=[{x:360,y:400},{x:375,y:430},{x:345,y:455},{x:330,y:372},{x:384,y:395}];
 for(const s of spots){const r=G.predict(w,s);assert.equal(r.status,'belt',JSON.stringify(s));assert.deepEqual(r.via,[0]);assert.equal(C.deliveryStatus(links,[],r.end),'warehouse');}
 const items=spots.map((s,i)=>({key:i+1,type:'wood',count:1,...s}));const {arrived,out}=run(w,items,12,links);
 assert.deepEqual(arrived.slice().sort(),[1,2,3,4,5],'all five reach the house');assert.equal(out.length,5);
 for(let i=1;i<out.length;i++)assert.ok(out[i].t-out[i-1].t>=.6-1e-9,'never faster than 0.6 s');
});
test('items in a hopper are plain items in the save: they come back loose and are drawn in again',()=>{
 const s=Supply.fresh(960,540);Supply.individualize(s);const d=Supply.drop(s,'wood',1,330,420,1);d.hopperKey=1;d.physical=true;
 const r=Supply.migrate(JSON.parse(JSON.stringify(s)));assert.equal(r.drops.length,1);assert.equal(r.drops[0].hopperKey,undefined);
 const w=world({hoppers:[{key:1,x:330,y:420,dir:4}]}),items=[{...r.drops[0]}];const {out}=run(w,items,1);assert.equal(out.length,1);
});
test('hopper in the camp: locked until chapter 1, costs 10 wood + 4 stone, selectable, turns 8 ways, removal refunds 5 + 2 and frees its items',()=>{
 let {S,api,sounds}=camp(0);S.factory.inventory.wood=50;S.factory.inventory.stone=20;
 assert.match(api.catalogHTML(),/data-equipment="hopper" disabled/);assert.equal(api.buildDevice('hopper'),false);assert.equal(api.buildingKind,null);
 ({S,api,sounds}=camp(3));S.factory.inventory.wood=50;S.factory.inventory.stone=20;
 assert.doesNotMatch(api.catalogHTML(),/data-equipment="hopper" disabled/);assert.match(api.catalogHTML(),/集積口/);
 assert.equal(api.buildDevice('hopper'),true);assert.equal(api.buildingKind,'hopper');
 assert.equal(api.canPlaceHopper({x:280,y:300}),false,'not on a tree');assert.equal(api.canPlaceHopper({x:130,y:340}),false,'not at the house');
 assert.equal(api.placeHopper({x:420,y:430}),true);assert.equal(S.factory.inventory.wood,40);assert.equal(S.factory.inventory.stone,16);assert.equal(S.camp.hoppers.length,1);
 assert.equal(api.canPlaceHopper({x:440,y:430}),false,'not on another hopper');
 api.selectAt({x:421,y:431});assert.deepEqual(plain(api.selection),{kind:'hopper',key:1});
 const d=Supply.drop(S.factory,'wood',1,420,430,1);d.hopperKey=1;
 assert.equal(api.removePiece('hopper',1),true);assert.equal(S.factory.inventory.wood,45);assert.equal(S.factory.inventory.stone,18);assert.equal(d.hopperKey,undefined);assert.equal(S.camp.hoppers.length,0);
 assert.equal(api.buildDevice('hopper'),true);api.placeHopper({x:420,y:430});api.undoBuild();assert.equal(S.factory.inventory.wood,45,'undo right after placing returns the full price');assert.equal(S.factory.inventory.stone,18);
 S.factory.inventory.stone=3;api.buildDevice('hopper');assert.equal(api.placeHopper({x:420,y:430}),false);
});
test('chapter 1 clear: the unlock milestone plays once (unlock cue, banner, glowing cards), never during a raid',()=>{
 const {S,api,sounds}=camp(2);api.boot();api.tick(.3);assert.equal(S.camp.conveyorUnlockSeen,undefined);assert.ok(!sounds.includes('unlock'));
 S.outpost.cleared=3;S.outpost.phase='active';api.tick(.3);assert.ok(!sounds.includes('unlock'),'not in the middle of a raid');
 S.outpost.phase='prep';api.tick(.3);assert.equal(S.camp.conveyorUnlockSeen,true);assert.equal(sounds.filter(k=>k==='unlock').length,1);assert.equal(api.unlockBannerActive,true);assert.match(api.catalogHTML(),/just-unlocked/);
 for(let i=0;i<10;i++)api.tick(.3);assert.equal(sounds.filter(k=>k==='unlock').length,1,'once');
 for(let i=0;i<30;i++)api.tick(.3);assert.doesNotMatch(api.catalogHTML(),/just-unlocked/);
});

test('a log directly pressed in a tool tap circle stays grabbable; the tool body still selects the hopper',()=>{
 const {S,api,scope}=camp(3);S.camp.hoppers.push({key:1,x:420,y:430,dir:0});scope.ArmyView.camera.scale=.4;
 const log={key:20,x:458,y:430,type:'wood',count:1};S.factory.drops.push(log);
 // SupplyFactory.pileAt gives direct sprite hits priority outside the actual body (18 world px).
 scope.SupplyFactory.pileAt=p=>Math.hypot(p.x-log.x,p.y-log.y)<6?log:null;
 assert.equal(api.selectAt({x:458,y:430}),false,'do not intercept the log pointerdown in the enlarged 55px tool circle');
 assert.equal(api.selection,null);
 assert.equal(api.selectAt({x:420,y:430}),true);
 assert.deepEqual(plain(api.selection),{kind:'hopper',key:1});
});
test('removing and rebuilding a hopper under the same key cannot pull its old queued item across the field',()=>{
 const items=[{key:1,x:360,y:300,type:'wood',count:1}],states=[];
 const original=world({hoppers:[{key:1,x:400,y:300,dir:0}]});
 G.hopperStep(original,states,items,0);assert.equal(items[0].hopperKey,1);assert.equal(states[0].pull,items[0]);
 // removePiece / undoBuild release the item's hopper tag. A rebuild may reuse key 1 before the next tick.
 delete items[0].hopperKey;
 const rebuilt=world({hoppers:[{key:1,x:700,y:300,dir:0}]});
 G.hopperStep(rebuilt,states,items,G.DT);
 assert.equal(states[0].pull,null);assert.equal(states[0].inside,null);
 assert.deepEqual([items[0].x,items[0].y],[360,300]);assert.equal(items[0].hopperKey,undefined);
 assert.equal(items.length,1);assert.equal(items[0].count,1);
});
test('graph preview rebuilds its object references when an identical saved layout replaces the link objects',()=>{
 let links=[{nodeKey:101,kind:'conveyor',points:[C.HOME,{x:300,y:340}]},{nodeKey:102,kind:'conveyor',points:[{x:280,y:340.2},{x:400,y:340.2}]}];
 assert.equal(C.deliveryStatus(links,[],{x:200,y:340}),'warehouse','prime graph on the home belt only');
 // Loading / restoring a camp can create fresh objects with precisely the same geometric signature.
 links=JSON.parse(JSON.stringify(links));
 assert.equal(C.deliveryStatusLegacy(links,[],{x:390,y:340.2}),'warehouse');
 assert.equal(C.deliveryStatus(links,[],{x:390,y:340.2}),'warehouse');
 // The array itself may also be kept while its contents are replaced.
 links.splice(0,links.length,...JSON.parse(JSON.stringify(links)));
 assert.equal(C.deliveryStatus(links,[],{x:390,y:340.2}),'warehouse');
});
