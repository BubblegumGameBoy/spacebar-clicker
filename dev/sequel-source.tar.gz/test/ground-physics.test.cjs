const test=require('node:test'),assert=require('node:assert/strict'),G=require('../2/ground-physics.js'),Supply=require('../2/supply-core.js');
const NODES=[{key:1,type:'wood',x:280,y:300,radius:16},{key:2,type:'wood',x:470,y:300,radius:16},{key:3,type:'stone',x:330,y:395,radius:19},{key:4,type:'stone',x:490,y:395,radius:19}];
const world=(extra={})=>({width:960,height:540,nodes:NODES,...extra});
const runUntil=(w,item,max=900)=>{let it={...item},status='rest';const path=[{x:it.x,y:it.y}];for(let i=0;i<max;i++){const n=G.step(w,it,-1e9);path.push({x:n.x,y:n.y});status=n.status;it=n;if(status!=='moving')break;}return {status,item:it,path};};

test('same input gives the same result and never uses randomness',()=>{
 const random=Math.random;Math.random=()=>{throw new Error('random used');};
 try{const w=world({blowers:[{x:420,y:330,dir:4}],fences:[{a:{x:200,y:300},b:{x:300,y:290}}]});
  const make=()=>Array.from({length:40},(_,i)=>({x:330+(i%8)*6,y:300+Math.floor(i/8)*12,vx:(i%3)*20,vy:0}));
  const a=make(),b=make();for(let k=0;k<120;k++){G.stepAll(w,a,k*G.DT);G.stepAll(w,b,k*G.DT);}
  assert.deepEqual(a,b);assert.ok(a.some(d=>d.x<330),'the blower moved something');
 }finally{Math.random=random;}
});

test('a resting item outside every fan does not move; friction stops a sliding item',()=>{
 const w=world();assert.equal(G.step(w,{x:600,y:250}).status,'rest');
 const r=runUntil(w,{x:600,y:250,vx:150,vy:0});assert.equal(r.status,'rest');assert.ok(r.item.x>600&&r.item.x<900);assert.equal(r.item.vx,0);
});

test('blower pushes away from itself only inside its 8-direction fan',()=>{
 const w=world({blowers:[{x:600,y:250,dir:4}]});// facing west
 const front=G.accelAt(w,{x:540,y:250}),behind=G.accelAt(w,{x:660,y:250}),side=G.accelAt(w,{x:600,y:200}),far=G.accelAt(w,{x:500,y:250});
 assert.ok(front.x<0&&Math.abs(front.y)<1e-9);assert.deepEqual([behind.x,side.x,far.x],[0,0,0]);
 const edge=G.accelAt(w,{x:540,y:270});assert.ok(edge.x<0&&edge.y>0,'radial push spreads at the fan edge');
 assert.equal(G.DIRS.length,8);assert.deepEqual(G.DIRS[2],{x:0,y:1});
});

test('strong wind: 3 s per press, extended by more presses, never more than 5 s ahead',()=>{
 const b={x:0,y:0,dir:0,boostUntil:-Infinity};b.boostUntil=G.tapBlower(b,10);assert.equal(b.boostUntil,13);
 assert.equal(G.boostFactor(b,12.9),2);assert.equal(G.boostFactor(b,13),1);
 b.boostUntil=G.tapBlower(b,11);assert.equal(b.boostUntil,14);
 for(let i=0;i<10;i++)b.boostUntil=G.tapBlower(b,11.2);assert.equal(b.boostUntil,16.2);
 assert.equal(G.tapBlower(b,20),23);
 const w=world({blowers:[{x:600,y:250,dir:4,boostUntil:5}]});assert.ok(Math.abs(G.accelAt(w,{x:560,y:250},4).x-2*G.accelAt(w,{x:560,y:250},6).x)<1e-9);
});

test('fence: an item slides along it and leaves from its end',()=>{
 const w=world({fences:[{a:{x:500,y:220},b:{x:600,y:220}}]});
 let it={x:510,y:200,vx:160,vy:120},touched=false;
 for(let i=0;i<200;i++){const n=G.step(w,it);if(n.x<600&&Math.abs(n.y-212)<.6)touched=true;assert.ok(!(n.x>500&&n.x<600&&n.y>212.5),'never crosses the fence');it=n;if(n.status!=='moving')break;}
 assert.ok(touched,'rode along the fence');
 // Thrown diagonally onto the fence: keeps its along-fence speed, then passes the end.
 const slick=world({fences:[{a:{x:500,y:220},b:{x:600,y:220}}],params:{dragLinear:.4,dragConstant:30}});
 const r=runUntil(slick,{x:510,y:200,vx:300,vy:120});assert.ok(r.path.some(p=>p.x>560&&p.x<590&&Math.abs(p.y-212)<.5),'slides on the fence');assert.ok(r.item.x>640,'leaves past the end');
 // Pushed by a blower toward a fence end, it goes around the rounded end.
 const around=runUntil(world({fences:[{a:{x:500,y:220},b:{x:600,y:220}}],blowers:[{x:560,y:160,dir:1}]}),{x:590,y:200});assert.ok(around.path.some(p=>p.y>230),'escapes around the end');
});

test('fast items do not tunnel through a thin fence; trees and rocks are solid circles',()=>{
 const w=world({fences:[{a:{x:600,y:150},b:{x:600,y:260}}]});const r=runUntil(w,{x:560,y:200,vx:900,vy:0});assert.ok(r.path.every(p=>p.x<=600));
 const t=runUntil(world(),{x:240,y:300,vx:200,vy:0});assert.ok(t.path.every(p=>Math.hypot(p.x-280,p.y-300)>=21.99));
});

test('warehouse receives inside the 60px circle; prediction says the same as live stepping',()=>{
 const w=world({blowers:[{x:250,y:340,dir:4}]});const p=G.predict(w,{x:225,y:340});assert.equal(p.status,'warehouse');
 const live=runUntil(w,{x:225,y:340});assert.equal(live.status,'delivered');assert.deepEqual(p.path,live.path);
 assert.equal(G.step(w,{x:150,y:340}).status,'delivered');
 const roof=runUntil(world(),{x:100,y:200,vx:0,vy:150});assert.notEqual(roof.status,'delivered','the roof is a wall, not a receiver');
});

test('every predicted delivery is a real delivery (many starts, fences and two blowers)',()=>{
 const w=world({blowers:[{x:420,y:340,dir:4},{x:260,y:420,dir:5}],fences:[{a:{x:200,y:290},b:{x:300,y:282}},{a:{x:180,y:400},b:{x:290,y:405}}]});
 let delivered=0;
 for(let i=0;i<60;i++){const s={x:330+(i%10)*7,y:300+Math.floor(i/10)*14},p=G.predict(w,s);const items=[{...s}];let status='moving';
  for(let k=0;k<p.steps;k++){const r=G.stepAll(w,items,-1e9);if(r.delivered.length){status='warehouse';break;}}
  if(p.status==='warehouse'){delivered++;assert.equal(status,'warehouse');}else assert.notEqual(status,'warehouse');
  assert.ok(Math.hypot(items[0].x-p.end.x,items[0].y-p.end.y)<1e-9);}
 assert.ok(delivered>0);
});

test('preview cache reuses results for the same shape and resets when a device moves',()=>{
 const P=G.createPredictor(),w=world({blowers:[{x:420,y:340,dir:4}]}),s={x:380,y:340};
 const a=P.predict(w,s),b=P.predict(w,s);assert.equal(a,b);assert.equal(P.stats.hits,1);
 const boosted=P.predict({...w,blowers:[{x:420,y:340,dir:4,boostUntil:99}]},s);assert.equal(boosted,a,'boost time is not part of the shape');
 const moved=P.predict({...w,blowers:[{x:420,y:330,dir:4}]},s);assert.notEqual(moved,a);assert.equal(P.stats.size,1);
});

test('hand logs land on 3-5 fixed spots by strike number; woodcutter logs on a fixed small cluster',()=>{
 const node={x:280,y:300};for(const count of [3,4,5]){const pts=Array.from({length:20},(_,i)=>G.handDropPoint(node,i,count));
  assert.equal(new Set(pts.map(p=>p.x+','+p.y)).size,count);for(let i=1;i<pts.length;i++)assert.notDeepEqual([pts[i].x,pts[i].y],[pts[i-1].x,pts[i-1].y]);
  assert.deepEqual(pts,Array.from({length:20},(_,i)=>G.handDropPoint(node,i,count)));assert.deepEqual(pts[0],{x:352,y:328,spot:0});}
 const w=Array.from({length:16},(_,i)=>G.workerDropPoint({x:364,y:332},i));assert.equal(new Set(w.map(p=>p.x+','+p.y)).size,8);
 assert.ok(w.every(p=>Math.hypot(p.x-364,p.y-332)<=30));
});

test('physics neither creates nor deletes ground items; the ground limit is unchanged',()=>{
 const s=Supply.fresh(960,540,1);Supply.individualize(s);for(let i=0;i<12;i++)assert.ok(Supply.drop(s,'wood',1,380+i,340,1,12));
 assert.equal(Supply.drop(s,'wood',1,380,340,1,12),null);
 const w=world({blowers:[{x:420,y:340,dir:4}]});let arrived=[];
 for(let k=0;k<30;k++){const r=G.stepAll(w,s.drops,-1e9);assert.equal(s.drops.length,12-arrived.length);arrived.push(...r.delivered.filter(d=>!arrived.includes(d)));if(arrived.length)break;}
 assert.equal(Supply.drop(s,'wood',1,380,340,1,12),null,'moving items still count as ground items');
 for(const d of arrived)Supply.deliver(s,d);if(arrived.length)assert.ok(Supply.drop(s,'wood',1,380,340,1,12));
 const saved=Supply.migrate(JSON.parse(JSON.stringify(s)));assert.ok(saved.drops.every(d=>d.vx===undefined&&d.vy===undefined),'only positions are saved');
});

test('fence length and price, fixed-step driver independent of frame rate',()=>{
 assert.equal(G.fenceValid({a:{x:0,y:0},b:{x:23,y:0}}),false);assert.equal(G.fenceValid({a:{x:0,y:0},b:{x:120,y:0}}),true);assert.equal(G.fenceValid({a:{x:0,y:0},b:{x:121,y:0}}),false);
 assert.equal(G.fenceCost({a:{x:0,y:0},b:{x:24,y:0}}),1);assert.equal(G.fenceCost({a:{x:0,y:0},b:{x:25,y:0}}),2);assert.equal(G.fenceCost({a:{x:0,y:0},b:{x:120,y:0}}),5);
 assert.equal(G.fenceLength(G.clampFence({x:0,y:0},{x:300,y:0})),120);assert.equal(G.fenceLength(G.clampFence({x:0,y:0},{x:5,y:0})),24);
 const drive=frame=>{const w=world({blowers:[{x:420,y:340,dir:4}]}),items=[{x:385,y:340}];let acc=0;for(let t=0;t<1-1e-9;t+=frame){const f=G.fixedSteps(acc,frame);acc=f.rest;for(let i=0;i<f.steps;i++)G.stepAll(w,items,-1e9);}return items[0];};
 assert.deepEqual(drive(1/60),drive(1/30));assert.deepEqual(drive(1/144),drive(1/30));
});
