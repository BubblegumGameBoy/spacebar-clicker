const test=require('node:test'),assert=require('node:assert/strict');
const {Battle}=require('../2/army-sim.js');
const hero={x:120,y:360,r:13,hp:50,max:100};
const unit=(id,extra={})=>({id,count:1,interval:1,damage:10,heal:2,...extra});
function battle(units){const b=new Battle();b.bounds(1100,500,{x:950,y:350,r:90,alive:true});b.sync(units);return b;}
test('melee has to reach the boss; ranged soldiers can fire from a distance',()=>{const b=battle([unit('sword'),unit('arch',{ranged:true})]);for(const p of b.soldiers){p.x=670;p.y=350;p.cooldown=0;}const e=b.step(.03,hero);assert.equal(e.filter(e=>e.kind==='release'&&e.p.id==='sword').length,0);assert.equal(e.filter(e=>e.kind==='release'&&e.p.id==='arch').length,1)});
test('soldiers of the same company have separate range checks and cooldowns',()=>{const b=battle([unit('arch',{count:2,ranged:true})]);b.soldiers[0].x=700;b.soldiers[1].x=150;for(const p of b.soldiers){p.y=350;p.cooldown=0;}const releases=b.step(.03,hero).filter(e=>e.kind==='release');assert.equal(releases.length,1);assert.equal(releases[0].p.key,b.soldiers[0].key);assert.ok(b.soldiers[0].cooldown>0);assert.ok(b.soldiers[1].cooldown<0)});
test('a shot from a previous encounter cannot damage a newly spawned boss',()=>{const b=battle([unit('arch',{ranged:true})]);const p=b.soldiers[0];p.x=700;p.y=350;p.cooldown=0;b.step(.03,hero);assert.ok(b.pending.length);b.encounter(2);let hits=[];for(let i=0;i<20;i++){p.cooldown=100;hits.push(...b.step(.05,hero).filter(e=>e.kind==='damage'));}assert.equal(hits.length,0)});
test('contact resolution separates overlapping bodies instead of stacking them',()=>{const b=battle([unit('sword',{count:2})]);for(const p of b.soldiers){p.x=450;p.y=300;p.order={x:450,y:300};}for(let i=0;i<12;i++)b.separate();const [a,c]=b.soldiers;assert.ok(Math.hypot(a.x-c.x,a.y-c.y)>=a.r+c.r-.1)});
test('reinforcements enter at different times and positions',()=>{const b=battle([]);b.sync([unit('arch',{count:10,ranged:true})],'arch');assert.ok(new Set(b.soldiers.map(p=>p.enterAt)).size>=9);assert.ok(new Set(b.soldiers.map(p=>p.y)).size>=9);assert.ok(b.soldiers.some(p=>p.enterAt>0))});
test('healing needs an injured captain inside the individual healer range',()=>{const b=battle([unit('healer',{healer:true})]);const p=b.soldiers[0];p.x=500;p.y=350;p.cooldown=0;assert.equal(b.step(.03,hero).filter(e=>e.kind==='release').length,0);p.x=180;p.cooldown=0;assert.equal(b.step(.03,{...hero,hp:100}).filter(e=>e.kind==='release').length,0);p.cooldown=0;assert.equal(b.step(.03,hero).filter(e=>e.kind==='release'&&e.heal).length,1)});
test('five thousand bodies use local neighbour checks, below the all-pairs cost',()=>{const b=battle([unit('arch',{count:5000,ranged:true})]);b.bounds(6000,2800,{x:5400,y:2100,r:450});b.separate();assert.ok(b.stats.pairs<5000*5000/10,`${b.stats.pairs} pairs`)});
test('a worker routes around a static resource collider and reaches the far side',()=>{const b=battle([unit('porter',{worker:'porter'})]);b.setObstacles([{x:450,y:300,radius:25}]);const p=b.soldiers[0];p.x=350;p.y=300;p.order={x:550,y:300};for(let i=0;i<150;i++)b.step(.05,hero);assert.ok(p.x>520,`worker at ${p.x}, ${p.y}`);assert.ok(Math.hypot(p.x-450,p.y-300)>p.r+25)});
test('a ranged hit resolves on the authored impact frame instead of the first animation frame',()=>{const b=battle([unit('arch',{ranged:true,anim:{release:200,impact:650}})]);const p=b.soldiers[0];p.x=700;p.y=350;p.cooldown=0;let hits=[];for(let i=0;i<12;i++)hits.push(...b.step(.05,hero).filter(e=>e.kind==='damage'));assert.equal(hits.length,0);for(let i=0;i<5;i++)hits.push(...b.step(.05,hero).filter(e=>e.kind==='damage'));assert.equal(hits.length,1)});
test('fixed placements keep their positions through attacks and overlaps',()=>{const b=battle([unit('arch',{count:2,ranged:true})]);b.stationary=true;for(const p of b.soldiers){p.x=700;p.y=350;p.cooldown=0;p.order={x:400,y:200};}const positions=b.soldiers.map(p=>[p.x,p.y]);let hits=0;for(let i=0;i<200;i++)hits+=b.step(.05,hero).filter(e=>e.kind==='damage').length;assert.ok(hits>0);assert.deepEqual(b.soldiers.map(p=>[p.x,p.y]),positions)});
test('new boss encounters do not restart worker cooldowns or harvest cycles',()=>{const b=battle([unit('woodcutter',{worker:'woodcutter'}),unit('arch',{ranged:true})]);const worker=b.soldiers.find(p=>p.id==='woodcutter');worker.cooldown=.82;worker.attackAt=b.time;b.encounter(45);assert.equal(worker.cooldown,.82);assert.equal(worker.attackAt,b.time)});

const Outpost=require('../2/outpost-core.js');
function outpostBattle(units=[unit('arch',{count:2,ranged:true,damage:5,interval:1.3})]){
 const state=Outpost.fresh();state.wave=3;Outpost.start(state);Outpost.tick(state,8);
 const b=new Battle();b.fixedWorld=true;b.bounds(960,540,{x:10000,y:10000,r:0,alive:false});b.outpostState=state;b.roundToken=state.round;b.enemies=state.enemies;b.sync(units);
 for(const p of b.soldiers){p.x=700;p.y=185;p.cooldown=0;}
 return {b,state};
}
test('outpost soldiers independently choose enemies on their own road with the shorter authored range',()=>{
 const {b,state}=outpostBattle([unit('arch',{count:3,ranged:true})]);b.soldiers[1].x=800;b.soldiers[1].y=435;b.soldiers[2].y=310;
 const events=b.step(.05,hero).filter(e=>e.kind==='release');assert.equal(events.length,2);assert.equal(b.range(b.soldiers[0]),90);assert.equal(events[0].target,state.enemies[0]);assert.equal(events[1].target,state.enemies[1]);
 for(const event of events){assert.equal(event.targetKey,event.target.key);assert.equal(event.roundToken,state.round);assert.ok(event.p.cooldown>0);}assert.ok(b.soldiers[2].cooldown<0);
});
test('outpost melee and archers acquire by individual effective range rather than the distant boss',()=>{
 const {b,state}=outpostBattle([unit('sword'),unit('arch',{ranged:true})]);for(const p of b.soldiers){p.x=state.enemies[0].x-80;p.y=185;}
 assert.equal(b.range(b.soldiers[0]),28);const events=b.step(.05,hero).filter(e=>e.kind==='release');assert.equal(events.length,1);assert.equal(events[0].p.id,'arch');assert.equal(b.boss.alive,false);
});
test('an outpost shot retains its exact enemy through impact and does not transfer after that enemy dies',()=>{
 const {b,state}=outpostBattle([unit('arch',{ranged:true,anim:{impact:200}})]);const release=b.step(.05,hero).find(e=>e.kind==='release');assert.equal(release.targetKey,state.enemies[0].key);Outpost.hit(state,release.targetKey,1000,'arch');
 state.enemies[2].x=710;for(const p of b.soldiers)p.cooldown=100;const hp=state.enemies[2].hp,events=[];for(let i=0;i<8;i++)events.push(...b.step(.05,hero));assert.equal(events.filter(e=>e.kind==='damage').length,0);assert.equal(state.enemies[2].hp,hp);
});
test('an in-flight arrow follows its same living rat beyond its acquisition range',()=>{
 const {b,state}=outpostBattle([unit('arch',{ranged:true,anim:{impact:200}})]);const release=b.step(.05,hero).find(e=>e.kind==='release');release.target.x=400;b.soldiers[0].cooldown=100;
 let hits=[];for(let i=0;i<5;i++)hits.push(...b.step(.05,hero).filter(e=>e.kind==='damage'));assert.equal(hits.length,1);assert.equal(hits[0].target,state.enemies[0]);assert.equal(hits[0].targetKey,release.targetKey);assert.equal(hits[0].roundToken,state.round);
});
test('round changes and reused keys cannot make old outpost arrows hit new enemy objects',()=>{
 for(const changeRound of [false,true]){const {b,state}=outpostBattle([unit('arch',{ranged:true,anim:{impact:200}})]);const release=b.step(.05,hero).find(e=>e.kind==='release');const replacement={...release.target};state.enemies[state.enemies.indexOf(release.target)]=replacement;if(changeRound)state.round++;b.enemies=state.enemies;b.soldiers[0].cooldown=100;
  let hits=[];for(let i=0;i<6;i++)hits.push(...b.step(.05,hero).filter(e=>e.kind==='damage'));assert.equal(hits.length,0);assert.equal(replacement.hp,replacement.maxHp);}
});
test('outpost encounter cancellation, empty roads and preparation emit no stale damage or boss fallback attacks',()=>{
 const {b,state}=outpostBattle([unit('arch',{ranged:true})]);b.step(.05,hero);assert.ok(b.pending.length);b.encounter(9);state.phase='prep';b.enemies=[];b.boss={x:710,y:185,r:100,alive:true,token:9};b.soldiers[0].cooldown=0;
 assert.equal(b.canHit(b.soldiers[0]),false);assert.equal(b.step(.1,hero).length,0);assert.equal(b.pending.length,0);
});
test('outpost mode never moves or separates allies, including workers with old movement orders',()=>{
 const {b}=outpostBattle([unit('arch',{count:2,ranged:true}),unit('woodcutter',{worker:'woodcutter'})]);b.stationary=false;for(const p of b.soldiers){p.x=700;p.y=185;p.order={x:400,y:300};}const positions=b.soldiers.map(p=>[p.x,p.y]);for(let i=0;i<30;i++)b.step(.05,hero);assert.deepEqual(b.soldiers.map(p=>[p.x,p.y]),positions);assert.ok(b.soldiers.every(p=>p.moving===false));
});
test('fixed logical world layout preserves boundary placements and orders through repeated fit updates',()=>{
 const {b}=outpostBattle();b.soldiers[0].x=15;b.soldiers[0].y=185;b.soldiers[1].x=940;b.soldiers[1].y=510;const before=b.soldiers.map(p=>[p.x,p.y]);for(let i=0;i<5;i++)b.bounds(960,540,{x:10000,y:10000,r:0,alive:false});assert.deepEqual(b.soldiers.map(p=>[p.x,p.y]),before);
});
test('every outpost hit remains separate even with many simultaneous attacks against one rat',()=>{
 const {b,state}=outpostBattle([unit('arch',{count:30,ranged:true,damage:5,anim:{impact:100}})]);for(const p of b.soldiers){p.x=700;p.y=185;p.cooldown=0;}const release=b.step(.05,hero);assert.equal(release.filter(e=>e.kind==='release').length,30);for(const p of b.soldiers)p.cooldown=100;const hits=[...b.step(.05,hero),...b.step(.05,hero)].filter(e=>e.kind==='damage');assert.equal(hits.length,30);
 for(const hit of hits)Outpost.hit(state,hit.targetKey,hit.amount,hit.p.id);assert.equal(state.kills,1);assert.equal(state.enemies[0].hp,0);assert.equal(state.enemies[1].hp,state.enemies[1].maxHp);
});

test('army view integrates fixed world, depth drawing, real round ticks, individual damage and capped projectiles',()=>{
 const fs=require('node:fs'),vm=require('node:vm'),trace=[],frames=[],elements=new Map(),state=Outpost.fresh();Outpost.start(state);Outpost.tick(state,0);
 const mainContext=new Proxy({drawImage(){trace.push('soldier');}},{get(object,key){if(key in object)return object[key];return ()=>{};}});
 function element(id=''){
  return {id,style:{},dataset:{},clientWidth:960,clientHeight:540,scrollLeft:0,scrollTop:0,querySelector:()=>null,querySelectorAll:()=>[],appendChild(){},addEventListener(){},scrollTo(){},remove(){},getBoundingClientRect:()=>({left:0,top:0,width:960,height:540}),getContext:()=>id==='armyCanvas'?mainContext:new Proxy({},{get:()=>()=>{}})};
 }
 for(const id of ['field','battleViewport','battleWorld','worldStage','battleGround','armyCanvas','armyCount','armyRoster','zoomIn','zoomOut','zoomFit'])elements.set(id,element(id));
 class ImageStub{
  constructor(){this.complete=true;this.naturalWidth=160;this.naturalHeight=100;this.crop={x:0,y:0,w:40,h:100};this.geometry={bodyHeight:100,left:-20,right:20,top:-100,bottom:0,boxes:Array.from({length:4},()=>({x:0,y:0,w:40,h:100,footX:20,footY:100}))};}
 }
 const actors=[{id:'arch',name:'Archer',ranged:true,sprite:'arch.png',iv:.01,dmg:999,anim:{frames:4,impact:200,release:0,frameMs:50}}],s={owned:{arch:2},pending:{arch:0},ulvl:{arch:500},bossWave:1,outpost:state};
 const hitCalls=[],scope={__OUTPOST_BUILD__:true,ArmySim:{Battle},OutpostCore:Outpost,S:s,UNITS:actors,encounterId:1,bossDead:false,bossEl:element('boss'),devicePixelRatio:1,performance:{now:()=>100},Image:ImageStub,ResizeObserver:class{observe(){}},requestAnimationFrame:cb=>(frames.push(cb),frames.length),cancelAnimationFrame(){},matchMedia:()=>({matches:false}),document:{hidden:false,getElementById:id=>elements.get(id),createElement:tag=>element(tag)},Core:{tier:()=>3,healPower:()=>999},L:x=>x,unitOwned:u=>s.owned[u.id]>0,unitIv:()=>.01,unitDmg:()=>999,Rework:{paused:false},SupplyFactory:{resize(){},boot(){},tick(){trace.push('supplyTick');},draw(){trace.push('supplyDraw');}},BattleControl:{resize(){},boot(){},restore(){},tick(){},selected:()=>false,draw(){trace.push('placement');},hero:{x:0,y:0,hp:1,max:1}},OutpostCamp:{drawUnder(){trace.push('campUnder');},drawOver(){trace.push('campOver');}},sndUnitHit(){},renderCards(){}};
 scope.Outpost={ready:true,state:()=>state,tick:dt=>{trace.push('outpostTick');Outpost.tick(state,dt);},hit:(amount,id,key)=>{hitCalls.push({amount,id,key});return Outpost.hit(state,key,amount,id).applied;},drawGround(){trace.push('roads');scope.OutpostCamp.drawUnder();},enemies:()=>state.enemies.filter(e=>e.alive),drawEnemy(){trace.push('enemy');}};
 scope.ArmySim=require('../2/army-sim.js');scope.window=scope;vm.createContext(scope);vm.runInContext(fs.readFileSync(require.resolve('../2/army-view.js'),'utf8'),scope);const view=scope.ArmyView;view.boot();
 assert.equal(view.camera.w,960);assert.equal(view.camera.h,540);assert.equal(view.bodyHeight(actors[0]),44);assert.equal(view.bodyHeight({id:'woodcutter'}),44);assert.equal(view.bodyHeight({id:'ballista'}),60);assert.equal(view.sim.soldiers[0].interval,1.3);assert.equal(view.sim.soldiers[0].u.damage,5);assert.equal(view.sim.range(view.sim.soldiers[0]),90);
 const [a,b]=view.sim.soldiers;a.x=900;a.y=170;b.x=900;b.y=200;const positions=view.sim.soldiers.map(p=>[p.x,p.y]);elements.get('battleViewport').clientWidth=390;view.layout();assert.deepEqual(view.sim.soldiers.map(p=>[p.x,p.y]),positions);assert.equal(view.camera.w,960);
 elements.get('battleViewport').clientWidth=960;view.layout();trace.length=0;frames[0](100);assert.deepEqual(trace,['roads','campUnder','supplyDraw','soldier','enemy','soldier','placement','campOver']);
 for(const p of view.sim.soldiers){p.x=900;p.y=185;p.cooldown=0;}const originalStep=view.sim.step.bind(view.sim);view.sim.step=(...args)=>{trace.push('simStep');return originalStep(...args);};trace.length=0;
 view.tick(.1);view.tick(.1);view.tick(.1);assert.ok(Math.abs(state.elapsed-.3)<1e-9);assert.equal(hitCalls.length,2);assert.ok(hitCalls.every(hit=>hit.amount===5&&hit.id==='arch'&&hit.key===state.enemies[0].key));assert.equal(state.enemies[0].hp,4);
 for(let i=0;i<trace.length;i++)if(trace[i]==='simStep')assert.equal(trace[i-1],'outpostTick');
 s.owned.arch=30;view.render();for(const p of view.sim.soldiers){p.x=900;p.y=185;p.cooldown=0;}view.tick(.1);assert.equal(view.stats.projectiles,24);assert.equal(view.stats.soldiers,30);assert.equal(view.sim.boss.alive,false);
 view.sim.soldiers[0].y=120;scope.S={...s,battle:view.snapshot()};view.render();assert.equal(view.sim.soldiers[0].y,120);assert.equal(view.stats.projectiles,0);
});
