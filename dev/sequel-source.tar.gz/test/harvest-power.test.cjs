const test=require('node:test'),assert=require('node:assert/strict');
const Supply=require('../2/supply-core.js'),Skills=require('../2/harvest-skill-core.js');

function tap(node,power,room=100){const q=Supply.strikePlan(node,power,room);if(q.applied){node.stock-=q.produced;node.work=q.work;}return q;}

test('base wood takes three distinct strikes and stone takes five; partial work belongs to each site',()=>{
 const wood={type:'wood',stock:20,work:0},stone={type:'stone',stock:20,work:0};
 assert.equal(tap(wood,1).produced,0);assert.equal(wood.work,1);
 assert.equal(tap(stone,1).produced,0);assert.equal(stone.work,1);
 assert.equal(tap(wood,1).produced,0);assert.equal(wood.work,2);
 assert.equal(tap(wood,1).produced,1);assert.equal(wood.work,0);assert.equal(wood.stock,19);
 for(let i=0;i<3;i++)assert.equal(tap(stone,1).produced,0);
 assert.equal(tap(stone,1).produced,1);assert.equal(stone.stock,19);
});

test('each actual gathering rank reduces work or increases sustained individual production',()=>{
 const expected=[1,2,3,5,8,12,18];
 for(let hand=0;hand<=6;hand++){
  const power=Skills.effects({hand}).manualPower;assert.equal(power,expected[hand]);
  for(const type of ['wood','stone']){
   const p=Skills.harvestProfile({hand},type),n={type,stock:1000,work:0};let total=0;
   assert.equal(p.hits,Math.ceil(p.required/power));
   for(let i=0;i<30;i++)total+=tap(n,power).produced;
   assert.equal(total,Math.floor(30*power/p.required));
   assert.equal(n.work,30*power%p.required);
  }
 }
 assert.equal(tap({type:'food',stock:1,work:0},1).produced,1,'ripe wheat remains a single harvesting action');
});

test('ground full refuses work and stock changes; huge power cannot bank a hidden full-ground payout',()=>{
 const n={type:'wood',stock:10,work:2};const before=structuredClone(n);
 for(let i=0;i<50;i++){const q=tap(n,18,0);assert.equal(q.applied,false);assert.equal(q.blocked,'full');}
 assert.deepEqual(n,before);
 const q=tap(n,18,1);assert.equal(q.produced,1);assert.equal(n.stock,9);assert.equal(n.work,2,'only legitimate sub-piece remainder survives');
 assert.equal(tap(n,1,0).applied,false);assert.equal(tap(n,1,1).produced,1);assert.equal(n.work,0);
});

test('a depleted site cannot receive work and consuming the final piece clears its remainder',()=>{
 const n={type:'stone',stock:1,work:4};assert.equal(tap(n,18).produced,1);assert.equal(n.stock,0);assert.equal(n.work,0);
 const q=tap(n,18);assert.equal(q.applied,false);assert.equal(q.blocked,'depleted');
});

test('partial work survives reload without moving authored nodes; hostile work is bounded',()=>{
 const s=Supply.fresh(960,540,7);s.nodes=[{key:1,type:'wood',x:515,y:301,stock:20,work:2},{key:2,type:'stone',x:730,y:402,stock:20,work:4}];
 const load=Supply.migrate(JSON.parse(JSON.stringify(s)));
 assert.deepEqual(load.nodes.map(n=>[n.x,n.y,n.work]),[[515,301,2],[730,402,4]]);
 assert.equal(tap(load.nodes[0],1).produced,1);assert.equal(tap(load.nodes[1],1).produced,1);
 for(const work of [-5,NaN,Infinity,1e10]){s.nodes[0].work=work;const n=Supply.migrate(s).nodes[0];assert.ok(n.work>=0&&n.work<3);}
});
