const test=require('node:test'),assert=require('node:assert/strict'),C=require('../2/conveyor-core.js'),O=require('../2/outpost-core.js');
const belt=(nodeKey,points,costWood=4)=>({nodeKey,kind:'conveyor',points,costWood});

test('hitLink selects a belt near its polyline, including segment ends and bent corners',()=>{
 const l=belt(1,[{x:100,y:340},{x:200,y:340},{x:200,y:440}]);
 assert.equal(C.hitLink([l],[],{x:150,y:349},10)?.key,1);
 assert.equal(C.hitLink([l],[],{x:94,y:344},10)?.key,1,'segment start');
 assert.equal(C.hitLink([l],[],{x:200,y:448},10)?.key,1,'segment end');
 assert.equal(C.hitLink([l],[],{x:207,y:334},10)?.key,1,'outside of the bend');
 assert.equal(C.hitLink([l],[],{x:150,y:352},10),null,'beyond tolerance');
 assert.equal(C.hitLink([l],[],{x:150,y:352},22)?.kind,'belt','zoomed-out touch tolerance');
 assert.equal(C.hitLink([l],[],{x:200,y:460},10),null,'past the open end');
 assert.equal(C.hitLink([l],[],{x:NaN,y:1},10),null);
});

test('overlapping belts pick the newest one drawn on top; separate belts pick the nearer',()=>{
 const old=belt(1,[{x:100,y:300},{x:300,y:300}]),fresh=belt(2,[{x:200,y:200},{x:200,y:400}]);
 assert.equal(C.hitLink([old,fresh],[],{x:203,y:302},10).key,2,'crossing: newest on top');
 assert.equal(C.hitLink([fresh,old],[],{x:203,y:302},10).key,1,'order, not key, decides what is on top');
 const parallel=belt(3,[{x:100,y:330},{x:300,y:330}]);
 assert.equal(C.hitLink([old,parallel],[],{x:150,y:306},22).key,1,'a nearer older belt is not stolen by a newer neighbour');
 assert.equal(C.hitLink([old,parallel],[],{x:150,y:326},22).key,3);
});

test('a receiving platform is hit by its rectangle and wins over a belt under it',()=>{
 const l=belt(1,[{x:100,y:300},{x:400,y:300}]),p={key:7,x:300,y:300,w:96,h:64,dir:0,costWood:8,costStone:4};
 const hit=C.hitLink([l],[p],{x:340,y:325},10);assert.equal(hit.kind,'platform');assert.equal(hit.key,7);
 assert.equal(C.hitLink([],[p],{x:349,y:333},10),null,'outside the rectangle');
 assert.equal(C.hitLink([l],[p],{x:150,y:302},10).kind,'belt');
});

test('removal refunds stay half price for belts and platforms',()=>{
 assert.deepEqual(C.removalRefund({kind:'belt',link:belt(1,[],5)}),{wood:2,stone:0});
 assert.deepEqual(C.removalRefund({kind:'belt',link:belt(1,[],4)}),{wood:2,stone:0});
 assert.deepEqual(C.removalRefund({kind:'platform',platform:{costWood:8,costStone:4}}),{wood:4,stone:2});
 assert.deepEqual(C.removalRefund({kind:'platform',platform:{}}),{wood:4,stone:2},'old saves without stored cost');
 assert.deepEqual(C.removalRefund({kind:'platform',platform:{costWood:0,costStone:0}}),{wood:4,stone:2},'a normalized save that lost its cost still gets the old fixed refund');
});

test('items riding a removed belt drop as separate ground items in place; other belts keep theirs',()=>{
 const gone=belt(1,[{x:100,y:340},{x:300,y:340}]),kept=belt(2,[{x:300,y:340},{x:300,y:500}]);
 const drops=[
  {key:1,type:'wood',count:1,x:150,y:340,onConveyor:true,beltId:1},
  {key:2,type:'wood',count:1,x:200,y:341,onConveyor:true,beltId:1,conveyorBlocked:true},
  {key:3,type:'stone',count:1,x:300,y:420,onConveyor:true,beltId:2},
  {key:4,type:'wood',count:1,x:300,y:342,onConveyor:true,beltId:1},
  {key:5,type:'wood',count:1,x:600,y:200}
 ];
 const before=drops.map(d=>({key:d.key,x:d.x,y:d.y,count:d.count}));
 const released=C.releaseItems(drops,{kind:'belt',key:1,link:gone},[kept],[]);
 assert.deepEqual(released.map(d=>d.key),[1,2]);
 assert.equal(drops.length,5,'nothing deleted');
 assert.deepEqual(drops.map(d=>({key:d.key,x:d.x,y:d.y,count:d.count})),before,'positions and single counts unchanged');
 for(const d of released){assert.equal(d.onConveyor,undefined);assert.equal(d.beltId,undefined);assert.equal(d.conveyorBlocked,undefined);assert.equal(d.physical,true);}
 assert.equal(drops[2].beltId,2,'other belt untouched');
 assert.equal(drops[3].beltId,undefined,'item at the junction is handed to the remaining belt');assert.equal(drops[3].onConveyor,true);
 assert.equal(drops[4].physical,undefined);
});

test('items on a removed platform are released too',()=>{
 const p={key:3,x:400,y:300,w:96,h:64,dir:0};
 const drops=[{key:1,type:'stone',count:1,x:410,y:300,onConveyor:true,platformKey:3},{key:2,type:'wood',count:1,x:700,y:300}];
 const released=C.releaseItems(drops,{kind:'platform',key:3,platform:p},[],[]);
 assert.deepEqual(released.map(d=>d.key),[1]);assert.equal(drops[0].physical,true);assert.equal(drops[0].platformKey,undefined);
});

test('road coverage returns only the reachable parts of each road',()=>{
 const W=O.WORLD;
 assert.deepEqual(O.roadPath('upper'),[{x:W.entryX,y:W.upper},{x:W.turnX,y:W.upper},{x:W.home.x,y:W.home.y}]);
 const spans=O.roadCoverage({x:500,y:250},100);
 assert.equal(spans.length,1);assert.equal(spans[0].lane,'upper');
 const half=Math.sqrt(100*100-65*65);
 assert.ok(Math.abs(spans[0].length-2*half)<1e-6);
 assert.ok(Math.abs(Math.min(spans[0].from.x,spans[0].to.x)-(500-half))<1e-6);
 assert.deepEqual(O.roadCoverage({x:500,y:310},40),[],'between roads and out of reach');
 const both=O.roadCoverage({x:500,y:310},140);assert.deepEqual([...new Set(both.map(s=>s.lane))].sort(),['lower','upper']);
});

test('road coverage merges across the bend and leaves out a minimum-range hole',()=>{
 const corner=O.coveredSpans([{x:0,y:0},{x:100,y:0},{x:100,y:100}],{x:100,y:0},50);
 assert.equal(corner.length,1,'one continuous span around the bend');assert.deepEqual(corner[0].points,[{x:50,y:0},{x:100,y:0},{x:100,y:50}]);assert.ok(Math.abs(corner[0].length-100)<1e-9);
 const hole=O.coveredSpans([{x:0,y:0},{x:400,y:0}],{x:200,y:0},160,60);
 assert.deepEqual(hole.map(s=>[s.from.x,s.to.x]),[[40,140],[260,360]]);
 assert.deepEqual(O.coveredSpans([{x:0,y:0},{x:400,y:0}],{x:200,y:300},160),[]);
});

test('removing a belt from the board refunds half, keeps riding items as single ground pieces, keeps legacy cargo, and clears undo for it',()=>{
 const vm=require('node:vm'),fs=require('node:fs'),Core=require('../2/game-core.js'),Supply=require('../2/supply-core.js');
 const S=Core.fresh(['woodcutter','miner','arch','sword']);S.factory=Supply.fresh(960,540);S.outpost={cleared:0};S.factory.individualDrops=true;
 const scope={S,LANG:'ja',SupplyCore:Supply,ConveyorCore:C,RailCore:require('../2/rail-core.js'),document:{getElementById:()=>null},ForestAudio:{play(){}},save(){},ArmyView:{sim:{soldiers:[]},camera:{scale:1}},SupplyFactory:{translate(){}}};scope.FieldCore=require('../2/field-core.js');scope.MaterialsCore=require('../2/materials-core.js');scope.window=scope;scope.clearTimeout=clearTimeout;vm.createContext(scope);
 vm.runInContext(fs.readFileSync(require.resolve('../2/outpost-camp.js'),'utf8'),scope);const api=scope.OutpostCamp;api.quote('woodTool');
 S.camp.links.push(belt(1,[{x:100,y:340},{x:300,y:340}],5),belt(2,[{x:300,y:450},{x:500,y:450}],4));
 S.camp.cargo.push({key:9,type:'stone',count:1,from:{x:300,y:340},progress:.5,duration:2,mode:'rail',path:[{x:300,y:340},{x:100,y:340}]});
 const a=Supply.drop(S.factory,'wood',1,200,340,1),b=Supply.drop(S.factory,'wood',1,230,340,1),c=Supply.drop(S.factory,'stone',1,400,450,3);a.onConveyor=b.onConveyor=c.onConveyor=true;a.beltId=b.beltId=1;c.beltId=2;
 const wood=S.factory.inventory.wood,count=S.factory.drops.length;
 assert.equal(api.removePiece('belt',1),true);
 assert.equal(S.factory.inventory.wood,wood+2,'half of 5 wood, rounded down');
 assert.deepEqual([...S.camp.links].map(l=>l.nodeKey),[2]);
 assert.equal(S.factory.drops.length,count,'no item deleted or merged');
 for(const d of [a,b]){assert.equal(d.count,1);assert.equal(d.physical,true);assert.equal(d.onConveyor,undefined);assert.equal(d.y,340);}
 assert.equal(a.x,200);assert.equal(b.x,230);assert.equal(c.beltId,2);assert.equal(c.onConveyor,true);
 assert.equal(S.camp.cargo.length,1,'legacy rail cargo already in transit still arrives');
 assert.equal(S.camp.removeLearned,true);
 assert.equal(api.removePiece('belt',1),false,'second removal of the same belt does nothing');
 S.camp.platforms.push({key:4,x:600,y:300,w:96,h:64,dir:0,costWood:8,costStone:4});const stone=S.factory.inventory.stone;
 assert.equal(api.removePiece('platform',4),true);assert.equal(S.camp.platforms.length,0);assert.equal(S.factory.inventory.stone,stone+2);
});
